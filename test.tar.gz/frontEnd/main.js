(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/_services/AuthenticationService.ts":
/*!****************************************************!*\
  !*** ./src/app/_services/AuthenticationService.ts ***!
  \****************************************************/
/*! exports provided: AuthenticationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthenticationService", function() { return AuthenticationService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ConfigurationService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ConfigurationService */ "./src/app/_services/ConfigurationService.ts");
/* harmony import */ var _GraphQLService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./GraphQLService */ "./src/app/_services/GraphQLService.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");





class AuthenticationService {
    constructor(rest, api, router) {
        this.rest = rest;
        this.api = api;
        this.router = router;
    }
    login(login, password) {
        return new Promise((resolve, reject) => this.rest.getApiEndpoint()
            .then((endpoint) => this.api.login(endpoint.toString(), login, password))
            .then((auth) => {
            if (auth.success === true) {
                localStorage.setItem('token', auth.token.toString());
                resolve(auth.token);
                this.router.navigateByUrl('person/' + this.getConnectedProfile());
                return;
            }
            throw new Error('Login failed.');
        })
            .catch((err) => {
            reject(Error(err));
        }));
    }
    register(id, login, email, password) {
        return new Promise((resolve, reject) => this.rest.getApiEndpoint()
            .then((endpoint) => this.api.register(endpoint.toString(), id, login, email, password))
            .then((res) => {
            resolve(res);
        })
            .catch((err) => {
            reject(Error(err));
        }));
    }
    logout() {
        localStorage.removeItem('token');
        //this.router.navigateByUrl('login');
    }
    isConnected() {
        const token = this.getToken();
        if (token == null) {
            return false;
        }
        const data = this.parseJwt(token);
        const hasExpired = new Date(data.exp * 1000) <= new Date();
        if (hasExpired) {
            localStorage.removeItem('token');
            return false;
        }
        return true;
    }
    getToken() {
        return localStorage.getItem('token');
    }
    getConnectedLogin() {
        if (this.isConnected) {
            const token = this.getToken();
            const data = this.parseJwt(token);
            return data.login;
        }
        return '';
    }
    getConnectedProfile() {
        if (this.isConnected) {
            const token = this.getToken();
            const data = this.parseJwt(token);
            return data.profile;
        }
        return '';
    }
    parseJwt(token) {
        if (token == null) {
            return {};
        }
        let base64Url = token.split('.')[1];
        let base64 = base64Url.replace('-', '+').replace('_', '/');
        return JSON.parse(atob(base64));
    }
}
AuthenticationService.ɵfac = function AuthenticationService_Factory(t) { return new (t || AuthenticationService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__["ConfigurationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_GraphQLService__WEBPACK_IMPORTED_MODULE_2__["GraphQLService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"])); };
AuthenticationService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: AuthenticationService, factory: AuthenticationService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AuthenticationService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root',
            }]
    }], function () { return [{ type: _ConfigurationService__WEBPACK_IMPORTED_MODULE_1__["ConfigurationService"] }, { type: _GraphQLService__WEBPACK_IMPORTED_MODULE_2__["GraphQLService"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }]; }, null); })();


/***/ }),

/***/ "./src/app/_services/ClientCacheService.ts":
/*!*************************************************!*\
  !*** ./src/app/_services/ClientCacheService.ts ***!
  \*************************************************/
/*! exports provided: ClientCacheService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientCacheService", function() { return ClientCacheService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _logger_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./logger_service */ "./src/app/_services/logger_service.ts");



class ClientCacheService {
    constructor() {
        this.logger = new _logger_service__WEBPACK_IMPORTED_MODULE_1__["default"]('clientCacheService');
        this.personListKey = 'PersonList';
        this.personListStorage = localStorage;
    }
    getPersonListFromCache() {
        const fileCache = __webpack_require__(/*! ../data/cache/personList.json */ "./src/app/data/cache/personList.json");
        if (!this.isPersonListInCache()) {
            this.logger.info('Cache from file');
            this.personsList = this.createCacheObject(fileCache.data);
            return fileCache;
        }
        else {
            const cache = Object.assign(this.personsList);
            if (cache.timestamp < fileCache.timestamp) {
                this.logger.info('Cache in storage too old => Cache from file');
                this.personsList = this.createCacheObject(fileCache.data);
                return fileCache;
            }
            else {
                this.logger.info('Cache from storage');
                return cache;
            }
        }
    }
    isPersonListInCache() {
        return this.personListStorage.getItem('PersonList') != null;
    }
    clearPersonsList() {
        localStorage.removeItem("PersonList");
    }
    set personsList(data) {
        localStorage.setItem('PersonList', JSON.stringify(data));
    }
    get personsList() {
        return JSON.parse(localStorage.getItem('PersonList'));
    }
    set endpoint(name) {
        sessionStorage.setItem('GENEALOGY_API', name);
    }
    get endpoint() {
        return sessionStorage.getItem('GENEALOGY_API');
    }
    set environnement(name) {
        sessionStorage.setItem('Environnement', name);
    }
    get environnement() {
        return sessionStorage.getItem('Environnement');
    }
    createCacheObject(data, timestamp = new Date()) {
        return { "data": data, "timestamp": timestamp.toISOString() };
    }
}
ClientCacheService.ɵfac = function ClientCacheService_Factory(t) { return new (t || ClientCacheService)(); };
ClientCacheService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: ClientCacheService, factory: ClientCacheService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ClientCacheService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/_services/ConfigurationService.ts":
/*!***************************************************!*\
  !*** ./src/app/_services/ConfigurationService.ts ***!
  \***************************************************/
/*! exports provided: ConfigurationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfigurationService", function() { return ConfigurationService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ClientCacheService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ClientCacheService */ "./src/app/_services/ClientCacheService.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");




class ConfigurationService {
    constructor(cacheService, http) {
        this.cacheService = cacheService;
        this.http = http;
    }
    getApiEndpoint() {
        return new Promise((resolve, reject) => {
            const cachedEndpoint = this.cacheService.endpoint;
            if (cachedEndpoint != null) {
                resolve(cachedEndpoint);
            }
            const url = window.location.origin + '/env';
            fetch(url)
                .then((resp) => resp.json())
                .then(res => {
                const endpoint = res.GENEALOGY_API;
                this.cacheService.endpoint = endpoint;
                resolve(endpoint);
                return endpoint;
            }).catch(err => {
                reject(Error(err));
            });
        });
    }
    getEnvironnement() {
        return new Promise((resolve, reject) => {
            const cachedEnv = this.cacheService.environnement;
            if (cachedEnv != null) {
                resolve(cachedEnv);
            }
            const url = window.location.origin + '/env';
            fetch(url)
                .then((resp) => resp.json())
                .then(res => {
                const env = res.Environnement;
                this.cacheService.environnement = env;
                resolve(env);
                return env;
            }).catch(err => {
                reject(Error(err));
            });
        });
    }
}
ConfigurationService.ɵfac = function ConfigurationService_Factory(t) { return new (t || ConfigurationService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_ClientCacheService__WEBPACK_IMPORTED_MODULE_1__["ClientCacheService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"])); };
ConfigurationService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: ConfigurationService, factory: ConfigurationService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ConfigurationService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _ClientCacheService__WEBPACK_IMPORTED_MODULE_1__["ClientCacheService"] }, { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }]; }, null); })();


/***/ }),

/***/ "./src/app/_services/EncryptionService.ts":
/*!************************************************!*\
  !*** ./src/app/_services/EncryptionService.ts ***!
  \************************************************/
/*! exports provided: EncryptionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EncryptionService", function() { return EncryptionService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class EncryptionService {
    encryptPassword(password) {
        return password;
    }
}
EncryptionService.ɵfac = function EncryptionService_Factory(t) { return new (t || EncryptionService)(); };
EncryptionService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: EncryptionService, factory: EncryptionService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](EncryptionService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/_services/GraphQLService.ts":
/*!*********************************************!*\
  !*** ./src/app/_services/GraphQLService.ts ***!
  \*********************************************/
/*! exports provided: GraphQLService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GraphQLService", function() { return GraphQLService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var apollo_fetch__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-fetch */ "./node_modules/apollo-fetch/dist/index.js");
/* harmony import */ var _ClientCacheService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ClientCacheService */ "./src/app/_services/ClientCacheService.ts");
/* harmony import */ var _EncryptionService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./EncryptionService */ "./src/app/_services/EncryptionService.ts");





class GraphQLService {
    constructor(cacheService, encryptionService) {
        this.cacheService = cacheService;
        this.encryptionService = encryptionService;
    }
    addPhoto(endpoint, link, deletehash, persons) {
        const token = localStorage.getItem('token');
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        fetch.use(addToken(token));
        return fetch({
            query: `mutation addPhoto($link: String!, $deleteHash: String, $persons: [String] ) {
  addPhoto( url : $link, deleteHash :$deleteHash, persons:$persons)
          }
          `,
            variables: { link, deleteHash: deletehash, persons }
        }).then(res => {
            return res.data.addPhoto;
        });
    }
    login(endpoint, login, password) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        const encrypted = this.encryptionService.encryptPassword(password);
        return fetch({
            query: `
query Login {
  login(login: "${login}", password: "${encrypted}"){
    success
    token
    error
  }
}`
        })
            .then(res => res.data.login);
    }
    register(endpoint, id, login, email, password) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        const encrypted = this.encryptionService.encryptPassword(password);
        return fetch({
            query: `
query Register {
  register(id: "${id}", login: "${login}", email: "${email}" password: "${encrypted}")
}`
        }).then(res => {
            return res.data;
        });
    }
    getPersonList(endpoint, itemCount, cacheDate) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        return fetch({
            query: `query SearchAllPersons($cacheCount: Int, $cacheDate: String) {
            data: getPersonList(cacheCount: $cacheCount, cacheDate: $cacheDate) {
              users{
                _id
                firstName
                lastName
                maidenName,
                gender,
                yearOfBirth,
                yearOfDeath,
                isDead,
                profileId
              },
              isUpToDate
            }
          }
          `,
            variables: { cacheCount: itemCount, cacheDate: cacheDate }
        }).then(res => {
            if (!res.data.data.isUpToDate) {
                this.cacheService.personsList = this.cacheService.createCacheObject(res.data.data.users);
            }
            return res.data.data;
        });
    }
    getConnectedUser(endpoint) {
        const token = localStorage.getItem('token');
        if (token == null) {
            return null;
        }
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint
        });
        fetch.use(({ request, options }, next) => {
            if (!options.headers) {
                options.headers = {};
            }
            options.headers['authorization'] = `Bearer ${token}`;
            next();
        });
        return fetch({
            query: `query me {
        me{
          id
          login
        }
      }
      `
        })
            .catch(err => {
            throw Error(err);
        })
            .then(res => {
            return res.data.me;
        });
    }
    getPrivateInfo(endpoint, id) {
        const token = localStorage.getItem('token');
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint
        });
        fetch.use(({ request, options }, next) => {
            if (!options.headers) {
                options.headers = {};
            }
            options.headers['authorization'] = `Bearer ${token}`;
            next();
        });
        return fetch({
            query: `query getPrivateProfile($_id: String!) {
        profile: getPrivateProfile( profileId : $_id) {
          birthDate
          deathDate
          isDead
          currentLocation
          birthLocation
          deathLocation
          email
          phone
          _id
        }
      }
      `,
            variables: { _id: id }
        })
            .catch(err => {
            throw Error(err);
        })
            .then(res => {
            return res.data.profile;
        });
    }
    getProfile(endpoint, id) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        return fetch({
            query: `query GetProfile($id: String!) {
        profile: getProfile( profileId : $id) {
          currentPerson{
            ...PersonInfo
          }
          mother{
            ...PersonInfo
          }
          father{
            ...PersonInfo
          }
          siblings{
            ...PersonInfo
          }
          spouses{
            ...PersonInfo
          }
          children{
            ...PersonInfo
          }
          photos{
            url
            _id
            persons{
              ...PhotoTag
            }
          }
      }
    }
    
    fragment PhotoTag on User {
                  _id
                  firstName
                  lastName
                  profileId
                }
       fragment PersonInfo on User {
                  _id
                  firstName
                  lastName
                  maidenName
                  gender
                  yearOfBirth
                  yearOfDeath
                  isDead,
                  profileId
                }
            `,
            variables: { id }
        })
            .then(res => {
            let profile = res.data.profile;
            let cacheObject = this.cacheService.createCacheObject(profile);
            localStorage.setItem("profile_" + id, JSON.stringify(cacheObject));
            return profile;
        });
    }
    getProfileId(endpoint, id) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        return fetch({
            query: `query GetProfileId($id: String!) {
              getProfileId(_id: $id)
            }
            `,
            variables: { id }
        })
            .then(res => {
            var _a, _b, _c;
            console.log(JSON.stringify(res));
            return _c = (_b = (_a = res) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.getProfileId, (_c !== null && _c !== void 0 ? _c : id);
        })
            .catch(err => {
            return id;
        });
    }
    deleteProfile(endpoint, id) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        return fetch({
            query: `mutation RemoveProfile($id: String!) {
              removeProfile(_id: $id)
            }
            `,
            variables: {
                id,
            }
        });
    }
    updateProfile(endpoint, id, changes, privateChange, updateUser) {
        const token = localStorage.getItem('token');
        if (changes != {}) {
            changes['updatedBy'] = updateUser;
        }
        if (privateChange != {}) {
            privateChange['updatedBy'] = updateUser;
        }
        const patchString = this.generatePatch(changes);
        const privatePatchString = this.generatePatch(privateChange);
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        fetch.use(addToken(token));
        return fetch({
            query: `mutation UpdatePerson($_id:String!) {
              updatePerson(_id: $_id, patch: ${patchString} ) {
                _id
                firstName
                lastName
                maidenName
                gender
                isDead
              },
              updatePersonPrivateInfo(_id: $_id, patch: ${privatePatchString} ) {
                _id
                birthDate
                deathDate
                currentLocation
                birthLocation
                deathLocation
                email
                phone
              },
            }
            `,
            variables: {
                _id: id,
            }
        });
    }
    generatePatch(changes) {
        const objectKeys = Object.keys(changes);
        let patchString = '{';
        objectKeys.forEach(i => {
            patchString += i;
            patchString += ':';
            patchString += '"' + changes[i] + '"';
            patchString += ',';
        });
        patchString += '}';
        return patchString;
    }
    createPerson(endpoint, changes) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint.toString(),
        });
        const objectKeys = Object.keys(changes);
        let patchString = '{';
        objectKeys.forEach(i => {
            patchString += i;
            patchString += ':';
            patchString += '"' + changes[i] + '"';
            patchString += ',';
        });
        patchString += '}';
        return fetch({
            query: `mutation createPerson {
          createPerson(person: ${patchString} ) {
            _id
            firstName
            lastName
            maidenName
            gender
            yearOfBirth
          }
        }
        `
        }).then(res => {
            return res.data.createPerson._id;
        });
    }
    getPhotos(endpoint, person) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        return fetch({
            query: `query getPhotosById($_id: String!) {
        getPhotosById(_id: $_id) {
          _id
          url
          persons{
            firstName
            lastName
            _id
          }
        }
      }
          `,
            variables: { _id: person }
        })
            .catch(err => {
            throw Error(err);
        }).then(res => {
            var _a;
            return (_a = res.data) === null || _a === void 0 ? void 0 : _a.getPhotosById;
        });
    }
    getProfilePhoto(endpoint, person) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        return fetch({
            query: `query getPhotoProfile($_id: String!) {
  getPhotoProfile( _id : $_id) {
              url
              _id
            }
          }
          `,
            variables: { _id: person }
        })
            .catch(err => {
            throw Error(err);
        }).then(res => {
            var _a;
            return (_a = res.data) === null || _a === void 0 ? void 0 : _a.getPhotoProfile;
        });
    }
    getPhotosRandom(endpoint) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        return fetch({
            query: `query GetPhotos {
        photos: getPhotosRandom(number: 5) {
          url
          _id
        }
      }`
        }).then(res => {
            return res.data.photos;
        });
    }
    getTodaysEvents(endpoint) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        return fetch({
            query: `query getTodayMarriagedays {
        birthday: getTodayBirthdays{
         ...usr
        },
        deathday: getTodayDeathdays{
         ...usr
        },
        marriage: getTodayMarriagedays{
         ...usr
        }
      }
      fragment usr on User{
           _id
          firstName
          lastName
      }
      `
        }).then(res => {
            return res.data;
        });
    }
    getAuditLastEntries(endpoint) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        return fetch({
            query: `query GetAudit {
        audit: getAuditLastEntries(number: 10) {
          timestamp
          type
          id
          user
          action
        }
      }
      `
        }).then(res => {
            return res.data.audit;
        });
    }
    removeLink(endpoint, person1, person2) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        return fetch({
            query: `mutation RemoveLink($id: String!, $id2: String!) {
          removeLink(_id1: $id, _id2: $id2)
        }
        `,
            variables: {
                id: person1,
                id2: person2
            }
        }).then(res => {
            return res.data.removeLink;
        });
    }
    removeSiblingLink(endpoint, person1, person2) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        return fetch({
            query: `mutation RemoveSiblingLink($id: String!, $id2: String!) {
        removeSiblingLink(_id1: $id, _id2: $id2)
      }
      `,
            variables: {
                id: person1,
                id2: person2
            }
        }).then(res => {
            return res.data.removeSiblingLink;
        });
    }
    linkParent(endpoint, person1, person2) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint.toString(),
        });
        return fetch({
            query: `mutation addParentLink($id: String!, $id2: String!) {
          addParentLink(_id: $id, _parentId: $id2)
        }
        `,
            variables: {
                id: person1,
                id2: person2
            }
        })
            .then(res => {
            return res.data.addParentLink;
        });
    }
    linkChild(endpoint, person1, person2) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint,
        });
        return fetch({
            query: `mutation addChildLink($id: String!, $id2: String!) {
          addChildLink(_id: $id, _childId: $id2)
        }
        `,
            variables: {
                id: person1,
                id2: person2
            }
        })
            .then(res => {
            return res.data.addChildLink;
        });
    }
    deletePhoto(endpoint, image) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint.toString(),
        });
        return fetch({
            query: `mutation deletePhoto($image: String!) {
        deletePhoto(image: $image)
        }
        `,
            variables: {
                image: image
            }
        })
            .then(res => {
            return res.data.deletePhoto;
        });
    }
    setProfilePicture(endpoint, person, image) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint.toString(),
        });
        return fetch({
            query: `mutation setProfilePicture($person: String!, $image: String!) {
        setProfilePicture(person: $person, image: $image)
        }
        `,
            variables: {
                person: person,
                image: image
            }
        })
            .then(res => {
            return res.data.setProfilePicture;
        });
    }
    addPhotoTag(endpoint, person, image) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint.toString(),
        });
        return fetch({
            query: `mutation addPhotoTag($person: String!, $image: String!) {
        addPhotoTag(image: $image, tag: $person)
        }
        `,
            variables: {
                person: person,
                image: image
            }
        })
            .then(res => {
            return res.data.addPhotoTag;
        });
    }
    removePhotoTag(endpoint, person, image) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint.toString(),
        });
        return fetch({
            query: `mutation removePhotoTag($person: String!, $image: String!) {
        removePhotoTag(image: $image, tag: $person)
        }
        `,
            variables: {
                person: person,
                image: image
            }
        })
            .then(res => {
            return res.data.removePhotoTag;
        });
    }
    linkSpouse(endpoint, person1, person2) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint.toString(),
        });
        return fetch({
            query: `mutation addSpouseLink($id: String!, $id2: String!) {
          addSpouseLink(_id1: $id, _id2: $id2)
        }
        `,
            variables: {
                id: person1,
                id2: person2
            }
        })
            .then(res => {
            return res.data.addSpouseLink;
        });
    }
    linkSibling(endpoint, person1, person2) {
        const fetch = Object(apollo_fetch__WEBPACK_IMPORTED_MODULE_1__["createApolloFetch"])({
            uri: endpoint.toString(),
        });
        return fetch({
            query: `mutation addSiblingLink($id: String!, $id2: String!) {
          addSiblingLink(_id1: $id, _id2: $id2)
        }
        `,
            variables: {
                id: person1,
                id2: person2
            }
        })
            .then(res => {
            return res.data.addSiblingLink;
        });
    }
}
GraphQLService.ɵfac = function GraphQLService_Factory(t) { return new (t || GraphQLService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_ClientCacheService__WEBPACK_IMPORTED_MODULE_2__["ClientCacheService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_EncryptionService__WEBPACK_IMPORTED_MODULE_3__["EncryptionService"])); };
GraphQLService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: GraphQLService, factory: GraphQLService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](GraphQLService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _ClientCacheService__WEBPACK_IMPORTED_MODULE_2__["ClientCacheService"] }, { type: _EncryptionService__WEBPACK_IMPORTED_MODULE_3__["EncryptionService"] }]; }, null); })();
function addToken(token) {
    return ({ request, options }, next) => {
        if (!options.headers) {
            options.headers = {};
        }
        options.headers.authorization = `Bearer ${token}`;
        next();
    };
}


/***/ }),

/***/ "./src/app/_services/NotificationService.ts":
/*!**************************************************!*\
  !*** ./src/app/_services/NotificationService.ts ***!
  \**************************************************/
/*! exports provided: NotificationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationService", function() { return NotificationService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/snack-bar */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/snack-bar.js");



class NotificationService {
    constructor(snackBar) {
        this.snackBar = snackBar;
        this.duration = 3000;
    }
    showInfo(text) {
        this.snackBar.open(text, 'close', { duration: this.duration, panelClass: ['info-snackbar'] });
    }
    showSuccess(text) {
        this.snackBar.open(text, 'close', { duration: this.duration, panelClass: ['success-snackbar'] });
    }
    showError(text) {
        this.snackBar.open(text, 'close', { duration: this.duration, panelClass: ['error-snackbar'] });
    }
    showWarning(text) {
        this.snackBar.open(text, 'close', { duration: this.duration, panelClass: ['warn-snackbar'] });
    }
}
NotificationService.ɵfac = function NotificationService_Factory(t) { return new (t || NotificationService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_1__["MatSnackBar"])); };
NotificationService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: NotificationService, factory: NotificationService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NotificationService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_1__["MatSnackBar"] }]; }, null); })();


/***/ }),

/***/ "./src/app/_services/logger_service.ts":
/*!*********************************************!*\
  !*** ./src/app/_services/logger_service.ts ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return LoggerService; });
const dateFormat = () => new Date(Date.now()).toISOString();
class LoggerService {
    constructor(cls) {
        this.cls = cls;
    }
    logToConsole(message, level) {
        console.log(`${dateFormat()} - ${this.cls} - ${level} - ${message}`);
    }
    info(message, obj = null) {
        this.logToConsole(`${message} ${obj == null ? '' : JSON.stringify(obj)}`, 'info');
    }
    debug(message, obj = null) {
        this.logToConsole(`${message} ${obj == null ? '' : JSON.stringify(obj)}`, 'debug');
    }
    error(message, obj = null) {
        this.logToConsole(`${message} ${obj == null ? '' : JSON.stringify(obj)}`, 'error');
    }
}


/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _components_person_component_person_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/person-component/person.component */ "./src/app/components/person-component/person.component.ts");
/* harmony import */ var _components_main_component_main_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/main-component/main.component */ "./src/app/components/main-component/main.component.ts");
/* harmony import */ var _components_admin_component_admin_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/admin-component/admin.component */ "./src/app/components/admin-component/admin.component.ts");
/* harmony import */ var _components_help_component_help_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/help-component/help.component */ "./src/app/components/help-component/help.component.ts");
/* harmony import */ var _components_login_component_login_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/login-component/login.component */ "./src/app/components/login-component/login.component.ts");









const routes = [
    {
        path: 'admin', component: _components_admin_component_admin_component__WEBPACK_IMPORTED_MODULE_4__["AdminComponent"]
    },
    {
        path: 'help', component: _components_help_component_help_component__WEBPACK_IMPORTED_MODULE_5__["HelpComponent"]
    },
    {
        path: 'login', component: _components_login_component_login_component__WEBPACK_IMPORTED_MODULE_6__["LoginComponent"]
    },
    {
        path: 'person/:profile', component: _components_person_component_person_component__WEBPACK_IMPORTED_MODULE_2__["PersonComponentComponent"]
    },
    {
        path: '**', component: _components_main_component_main_component__WEBPACK_IMPORTED_MODULE_3__["MainComponent"]
    }
];
class AppRoutingModule {
}
AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ factory: function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); }, imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
        _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppRoutingModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
                exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _components_nav_component_nav_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/nav-component/nav.component */ "./src/app/components/nav-component/nav.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _components_footer_component_footer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/footer-component/footer.component */ "./src/app/components/footer-component/footer.component.ts");






class AppComponent {
    constructor(titleService, metaService) {
        this.titleService = titleService;
        this.metaService = metaService;
        this.title = 'Res01 - Family Tree';
    }
    ngOnInit() {
        this.titleService.setTitle(this.title);
        this.metaService.addTags([
            { name: 'keywords', content: 'Angular, Universal, Example' },
            { name: 'description', content: 'Angular Universal Example' },
            { name: 'robots', content: 'index, follow' }
        ]);
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["Title"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["Meta"])); };
AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 6, vars: 0, consts: [["role", "main", 1, "content"], ["id", "clouds", "alt", "Gray Clouds Background", "xmlns", "http://www.w3.org/2000/svg", "width", "2611.084", "height", "485.677", "viewBox", "0 0 2611.084 485.677"], ["id", "Path_39", "data-name", "Path 39", "d", "M2379.709,863.793c10-93-77-171-168-149-52-114-225-105-264,15-75,3-140,59-152,133-30,2.83-66.725,9.829-93.5,26.25-26.771-16.421-63.5-23.42-93.5-26.25-12-74-77-130-152-133-39-120-212-129-264-15-54.084-13.075-106.753,9.173-138.488,48.9-31.734-39.726-84.4-61.974-138.487-48.9-52-114-225-105-264,15a162.027,162.027,0,0,0-103.147,43.044c-30.633-45.365-87.1-72.091-145.206-58.044-52-114-225-105-264,15-75,3-140,59-152,133-53,5-127,23-130,83-2,42,35,72,70,86,49,20,106,18,157,5a165.625,165.625,0,0,0,120,0c47,94,178,113,251,33,61.112,8.015,113.854-5.72,150.492-29.764a165.62,165.62,0,0,0,110.861-3.236c47,94,178,113,251,33,31.385,4.116,60.563,2.495,86.487-3.311,25.924,5.806,55.1,7.427,86.488,3.311,73,80,204,61,251-33a165.625,165.625,0,0,0,120,0c51,13,108,15,157-5a147.188,147.188,0,0,0,33.5-18.694,147.217,147.217,0,0,0,33.5,18.694c49,20,106,18,157,5a165.625,165.625,0,0,0,120,0c47,94,178,113,251,33C2446.709,1093.793,2554.709,922.793,2379.709,863.793Z", "transform", "translate(142.69 -634.312)", "fill", "#eee"]], template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-nav");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "svg", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "path", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "router-outlet");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "app-footer");
    } }, directives: [_components_nav_component_nav_component__WEBPACK_IMPORTED_MODULE_2__["NavComponent"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterOutlet"], _components_footer_component_footer_component__WEBPACK_IMPORTED_MODULE_4__["FooterComponent"]], styles: ["[_nghost-%COMP%] {\r\n    font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\";\r\n    font-size: 14px;\r\n    color: #333;\r\n    box-sizing: border-box;\r\n    -webkit-font-smoothing: antialiased;\r\n    -moz-osx-font-smoothing: grayscale;\r\n  }\r\n\r\n  h1[_ngcontent-%COMP%], h2[_ngcontent-%COMP%], h3[_ngcontent-%COMP%], h4[_ngcontent-%COMP%], h5[_ngcontent-%COMP%], h6[_ngcontent-%COMP%] {\r\n    margin: 8px 0;\r\n  }\r\n\r\n  p[_ngcontent-%COMP%] {\r\n    margin: 0;\r\n  }\r\n\r\n  .spacer[_ngcontent-%COMP%] {\r\n    flex: 1;\r\n  }\r\n\r\n  .content[_ngcontent-%COMP%] {\r\n    display: flex;\r\n    \r\n    \r\n    flex-direction: column;\r\n    align-items: center;\r\n  }\r\n\r\n  svg.material-icons[_ngcontent-%COMP%] {\r\n    height: 24px;\r\n    width: auto;\r\n  }\r\n\r\n  svg.material-icons[_ngcontent-%COMP%]:not(:last-child) {\r\n    margin-right: 8px;\r\n  }\r\n\r\n  .card[_ngcontent-%COMP%]   svg.material-icons[_ngcontent-%COMP%]   path[_ngcontent-%COMP%] {\r\n    fill: #888;\r\n  }\r\n\r\n  .card-container[_ngcontent-%COMP%] {\r\n    display: flex;\r\n    flex-wrap: wrap;\r\n    justify-content: center;\r\n    margin-top: 16px;\r\n  }\r\n\r\n  .card[_ngcontent-%COMP%] {\r\n    border-radius: 4px;\r\n    border: 1px solid #eee;\r\n    background-color: #fafafa;\r\n    height: 40px;\r\n    width: 200px;\r\n    margin: 0 8px 16px;\r\n    padding: 16px;\r\n    display: flex;\r\n    flex-direction: row;\r\n    justify-content: center;\r\n    align-items: center;\r\n    transition: all 0.2s ease-in-out;\r\n    line-height: 24px;\r\n  }\r\n\r\n  .card-container[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]:not(:last-child) {\r\n    margin-right: 0;\r\n  }\r\n\r\n  .card.card-small[_ngcontent-%COMP%] {\r\n    height: 16px;\r\n    width: 168px;\r\n  }\r\n\r\n  .card-container[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]:not(.highlight-card) {\r\n    cursor: pointer;\r\n  }\r\n\r\n  .card-container[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]:not(.highlight-card):hover {\r\n    transform: translateY(-3px);\r\n    box-shadow: 0 4px 17px rgba(black, 0.35);\r\n  }\r\n\r\n  .card-container[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]:not(.highlight-card):hover   .material-icons[_ngcontent-%COMP%]   path[_ngcontent-%COMP%] {\r\n    fill: rgb(105, 103, 103);\r\n  }\r\n\r\n  .card.highlight-card[_ngcontent-%COMP%] {\r\n    background-color: #1976d2;\r\n    color: white;\r\n    font-weight: 600;\r\n    border: none;\r\n    width: auto;\r\n    min-width: 30%;\r\n    position: relative;\r\n  }\r\n\r\n  .card.card.highlight-card[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\r\n    margin-left: 60px;\r\n  }\r\n\r\n  svg#rocket[_ngcontent-%COMP%] {\r\n    width: 80px;\r\n    position: absolute;\r\n    left: -10px;\r\n    top: -24px;\r\n  }\r\n\r\n  svg#rocket-smoke[_ngcontent-%COMP%] {\r\n    height: calc(100vh - 95px);\r\n    position: absolute;\r\n    top: 10px;\r\n    right: 180px;\r\n    z-index: -10;\r\n  }\r\n\r\n  a[_ngcontent-%COMP%], a[_ngcontent-%COMP%]:visited, a[_ngcontent-%COMP%]:hover {\r\n    color: #1976d2;\r\n    text-decoration: none;\r\n  }\r\n\r\n  a[_ngcontent-%COMP%]:hover {\r\n    color: #125699;\r\n  }\r\n\r\n  .terminal[_ngcontent-%COMP%] {\r\n    position: relative;\r\n    width: 80%;\r\n    max-width: 600px;\r\n    border-radius: 6px;\r\n    padding-top: 45px;\r\n    margin-top: 8px;\r\n    overflow: hidden;\r\n    background-color: rgb(15, 15, 16);\r\n  }\r\n\r\n  .terminal[_ngcontent-%COMP%]::before {\r\n    content: \"\\2022 \\2022 \\2022\";\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    height: 4px;\r\n    background: rgb(58, 58, 58);\r\n    color: #c2c3c4;\r\n    width: 100%;\r\n    font-size: 2rem;\r\n    line-height: 0;\r\n    padding: 14px 0;\r\n    text-indent: 4px;\r\n  }\r\n\r\n  .terminal[_ngcontent-%COMP%]   pre[_ngcontent-%COMP%] {\r\n    font-family: SFMono-Regular,Consolas,Liberation Mono,Menlo,monospace;\r\n    color: white;\r\n    padding: 0 1rem 1rem;\r\n    margin: 0;\r\n  }\r\n\r\n  .circle-link[_ngcontent-%COMP%] {\r\n    height: 40px;\r\n    width: 40px;\r\n    border-radius: 40px;\r\n    margin: 8px;\r\n    background-color: white;\r\n    border: 1px solid #eeeeee;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    cursor: pointer;\r\n    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);\r\n    transition: 1s ease-out;\r\n  }\r\n\r\n  .circle-link[_ngcontent-%COMP%]:hover {\r\n    transform: translateY(-0.25rem);\r\n    box-shadow: 0px 3px 15px rgba(0, 0, 0, 0.2);\r\n  }\r\n\r\n  footer[_ngcontent-%COMP%] {\r\n    margin-top: 8px;\r\n    display: flex;\r\n    align-items: center;\r\n    line-height: 20px;\r\n  }\r\n\r\n  footer[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\r\n    display: flex;\r\n    align-items: center;\r\n  }\r\n\r\n  .github-star-badge[_ngcontent-%COMP%] {\r\n    color: #24292e;\r\n    display: flex;\r\n    align-items: center;\r\n    font-size: 12px;\r\n    padding: 3px 10px;\r\n    border: 1px solid rgba(27,31,35,.2);\r\n    border-radius: 3px;\r\n    background-image: linear-gradient(-180deg,#fafbfc,#eff3f6 90%);\r\n    margin-left: 4px;\r\n    font-weight: 600;\r\n    font-family: -apple-system,BlinkMacSystemFont,Segoe UI,Helvetica,Arial,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol;\r\n  }\r\n\r\n  .github-star-badge[_ngcontent-%COMP%]:hover {\r\n    background-image: linear-gradient(-180deg,#f0f3f6,#e6ebf1 90%);\r\n    border-color: rgba(27,31,35,.35);\r\n    background-position: -.5em;\r\n  }\r\n\r\n  .github-star-badge[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%] {\r\n    height: 16px;\r\n    width: 16px;\r\n    margin-right: 4px;\r\n  }\r\n\r\n  svg#clouds[_ngcontent-%COMP%] {\r\n    position: fixed;\r\n    bottom: -160px;\r\n    left: -230px;\r\n    z-index: -10;\r\n    width: 1920px;\r\n  }\r\n\r\n  \r\n\r\n  @media screen and (max-width: 767px) {\r\n\r\n    .card-container[_ngcontent-%COMP%]    > *[_ngcontent-%COMP%]:not(.circle-link), .terminal[_ngcontent-%COMP%] {\r\n      width: 100%;\r\n    }\r\n\r\n    .card[_ngcontent-%COMP%]:not(.highlight-card) {\r\n      height: 16px;\r\n      margin: 8px 0;\r\n    }\r\n\r\n    .card.highlight-card[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\r\n      margin-left: 72px;\r\n    }\r\n\r\n    svg#rocket-smoke[_ngcontent-%COMP%] {\r\n      right: 120px;\r\n      transform: rotate(-5deg);\r\n    }\r\n  }\r\n\r\n  @media screen and (max-width: 575px) {\r\n    svg#rocket-smoke[_ngcontent-%COMP%] {\r\n      display: none;\r\n      visibility: hidden;\r\n    }\r\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSwwSkFBMEo7SUFDMUosZUFBZTtJQUNmLFdBQVc7SUFDWCxzQkFBc0I7SUFDdEIsbUNBQW1DO0lBQ25DLGtDQUFrQztFQUNwQzs7RUFFQTs7Ozs7O0lBTUUsYUFBYTtFQUNmOztFQUVBO0lBQ0UsU0FBUztFQUNYOztFQUVBO0lBQ0UsT0FBTztFQUNUOztFQUVBO0lBQ0UsYUFBYTtJQUNiLHFCQUFxQjtJQUNyQixzQkFBc0I7SUFDdEIsc0JBQXNCO0lBQ3RCLG1CQUFtQjtFQUNyQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixXQUFXO0VBQ2I7O0VBRUE7SUFDRSxpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxVQUFVO0VBQ1o7O0VBRUE7SUFDRSxhQUFhO0lBQ2IsZUFBZTtJQUNmLHVCQUF1QjtJQUN2QixnQkFBZ0I7RUFDbEI7O0VBRUE7SUFDRSxrQkFBa0I7SUFDbEIsc0JBQXNCO0lBQ3RCLHlCQUF5QjtJQUN6QixZQUFZO0lBQ1osWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixhQUFhO0lBQ2IsYUFBYTtJQUNiLG1CQUFtQjtJQUNuQix1QkFBdUI7SUFDdkIsbUJBQW1CO0lBQ25CLGdDQUFnQztJQUNoQyxpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxlQUFlO0VBQ2pCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7RUFDZDs7RUFFQTtJQUNFLGVBQWU7RUFDakI7O0VBRUE7SUFDRSwyQkFBMkI7SUFDM0Isd0NBQXdDO0VBQzFDOztFQUVBO0lBQ0Usd0JBQXdCO0VBQzFCOztFQUVBO0lBQ0UseUJBQXlCO0lBQ3pCLFlBQVk7SUFDWixnQkFBZ0I7SUFDaEIsWUFBWTtJQUNaLFdBQVc7SUFDWCxjQUFjO0lBQ2Qsa0JBQWtCO0VBQ3BCOztFQUVBO0lBQ0UsaUJBQWlCO0VBQ25COztFQUVBO0lBQ0UsV0FBVztJQUNYLGtCQUFrQjtJQUNsQixXQUFXO0lBQ1gsVUFBVTtFQUNaOztFQUVBO0lBQ0UsMEJBQTBCO0lBQzFCLGtCQUFrQjtJQUNsQixTQUFTO0lBQ1QsWUFBWTtJQUNaLFlBQVk7RUFDZDs7RUFFQTs7O0lBR0UsY0FBYztJQUNkLHFCQUFxQjtFQUN2Qjs7RUFFQTtJQUNFLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxrQkFBa0I7SUFDbEIsVUFBVTtJQUNWLGdCQUFnQjtJQUNoQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsaUNBQWlDO0VBQ25DOztFQUVBO0lBQ0UsNEJBQTRCO0lBQzVCLGtCQUFrQjtJQUNsQixNQUFNO0lBQ04sT0FBTztJQUNQLFdBQVc7SUFDWCwyQkFBMkI7SUFDM0IsY0FBYztJQUNkLFdBQVc7SUFDWCxlQUFlO0lBQ2YsY0FBYztJQUNkLGVBQWU7SUFDZixnQkFBZ0I7RUFDbEI7O0VBRUE7SUFDRSxvRUFBb0U7SUFDcEUsWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixTQUFTO0VBQ1g7O0VBRUE7SUFDRSxZQUFZO0lBQ1osV0FBVztJQUNYLG1CQUFtQjtJQUNuQixXQUFXO0lBQ1gsdUJBQXVCO0lBQ3ZCLHlCQUF5QjtJQUN6QixhQUFhO0lBQ2IsdUJBQXVCO0lBQ3ZCLG1CQUFtQjtJQUNuQixlQUFlO0lBQ2Ysd0VBQXdFO0lBQ3hFLHVCQUF1QjtFQUN6Qjs7RUFFQTtJQUNFLCtCQUErQjtJQUMvQiwyQ0FBMkM7RUFDN0M7O0VBRUE7SUFDRSxlQUFlO0lBQ2YsYUFBYTtJQUNiLG1CQUFtQjtJQUNuQixpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxhQUFhO0lBQ2IsbUJBQW1CO0VBQ3JCOztFQUVBO0lBQ0UsY0FBYztJQUNkLGFBQWE7SUFDYixtQkFBbUI7SUFDbkIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixtQ0FBbUM7SUFDbkMsa0JBQWtCO0lBQ2xCLDhEQUE4RDtJQUM5RCxnQkFBZ0I7SUFDaEIsZ0JBQWdCO0lBQ2hCLGtJQUFrSTtFQUNwSTs7RUFFQTtJQUNFLDhEQUE4RDtJQUM5RCxnQ0FBZ0M7SUFDaEMsMEJBQTBCO0VBQzVCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLFdBQVc7SUFDWCxpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxlQUFlO0lBQ2YsY0FBYztJQUNkLFlBQVk7SUFDWixZQUFZO0lBQ1osYUFBYTtFQUNmOztFQUdBLHNCQUFzQjs7RUFDdEI7O0lBRUU7O01BRUUsV0FBVztJQUNiOztJQUVBO01BQ0UsWUFBWTtNQUNaLGFBQWE7SUFDZjs7SUFFQTtNQUNFLGlCQUFpQjtJQUNuQjs7SUFFQTtNQUNFLFlBQVk7TUFDWix3QkFBd0I7SUFDMUI7RUFDRjs7RUFFQTtJQUNFO01BQ0UsYUFBYTtNQUNiLGtCQUFrQjtJQUNwQjtFQUNGIiwiZmlsZSI6Ii4uL3NyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XHJcbiAgICBmb250LWZhbWlseTogLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcIlNlZ29lIFVJXCIsIFJvYm90bywgSGVsdmV0aWNhLCBBcmlhbCwgc2Fucy1zZXJpZiwgXCJBcHBsZSBDb2xvciBFbW9qaVwiLCBcIlNlZ29lIFVJIEVtb2ppXCIsIFwiU2Vnb2UgVUkgU3ltYm9sXCI7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBjb2xvcjogIzMzMztcclxuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICAtd2Via2l0LWZvbnQtc21vb3RoaW5nOiBhbnRpYWxpYXNlZDtcclxuICAgIC1tb3otb3N4LWZvbnQtc21vb3RoaW5nOiBncmF5c2NhbGU7XHJcbiAgfVxyXG5cclxuICBoMSxcclxuICBoMixcclxuICBoMyxcclxuICBoNCxcclxuICBoNSxcclxuICBoNiB7XHJcbiAgICBtYXJnaW46IDhweCAwO1xyXG4gIH1cclxuXHJcbiAgcCB7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgfVxyXG5cclxuICAuc3BhY2VyIHtcclxuICAgIGZsZXg6IDE7XHJcbiAgfVxyXG5cclxuICAuY29udGVudCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgLyogcGFkZGluZzogMCAxNnB4OyAqL1xyXG4gICAgLyogbWF4LXdpZHRoOiA5NjBweDsgKi9cclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIH1cclxuXHJcbiAgc3ZnLm1hdGVyaWFsLWljb25zIHtcclxuICAgIGhlaWdodDogMjRweDtcclxuICAgIHdpZHRoOiBhdXRvO1xyXG4gIH1cclxuXHJcbiAgc3ZnLm1hdGVyaWFsLWljb25zOm5vdCg6bGFzdC1jaGlsZCkge1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA4cHg7XHJcbiAgfVxyXG5cclxuICAuY2FyZCBzdmcubWF0ZXJpYWwtaWNvbnMgcGF0aCB7XHJcbiAgICBmaWxsOiAjODg4O1xyXG4gIH1cclxuXHJcbiAgLmNhcmQtY29udGFpbmVyIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIG1hcmdpbi10b3A6IDE2cHg7XHJcbiAgfVxyXG5cclxuICAuY2FyZCB7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZWVlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZhZmFmYTtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIHdpZHRoOiAyMDBweDtcclxuICAgIG1hcmdpbjogMCA4cHggMTZweDtcclxuICAgIHBhZGRpbmc6IDE2cHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IHJvdztcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHRyYW5zaXRpb246IGFsbCAwLjJzIGVhc2UtaW4tb3V0O1xyXG4gICAgbGluZS1oZWlnaHQ6IDI0cHg7XHJcbiAgfVxyXG5cclxuICAuY2FyZC1jb250YWluZXIgLmNhcmQ6bm90KDpsYXN0LWNoaWxkKSB7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDA7XHJcbiAgfVxyXG5cclxuICAuY2FyZC5jYXJkLXNtYWxsIHtcclxuICAgIGhlaWdodDogMTZweDtcclxuICAgIHdpZHRoOiAxNjhweDtcclxuICB9XHJcblxyXG4gIC5jYXJkLWNvbnRhaW5lciAuY2FyZDpub3QoLmhpZ2hsaWdodC1jYXJkKSB7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgfVxyXG5cclxuICAuY2FyZC1jb250YWluZXIgLmNhcmQ6bm90KC5oaWdobGlnaHQtY2FyZCk6aG92ZXIge1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0zcHgpO1xyXG4gICAgYm94LXNoYWRvdzogMCA0cHggMTdweCByZ2JhKGJsYWNrLCAwLjM1KTtcclxuICB9XHJcblxyXG4gIC5jYXJkLWNvbnRhaW5lciAuY2FyZDpub3QoLmhpZ2hsaWdodC1jYXJkKTpob3ZlciAubWF0ZXJpYWwtaWNvbnMgcGF0aCB7XHJcbiAgICBmaWxsOiByZ2IoMTA1LCAxMDMsIDEwMyk7XHJcbiAgfVxyXG5cclxuICAuY2FyZC5oaWdobGlnaHQtY2FyZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTk3NmQyO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIHdpZHRoOiBhdXRvO1xyXG4gICAgbWluLXdpZHRoOiAzMCU7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgfVxyXG5cclxuICAuY2FyZC5jYXJkLmhpZ2hsaWdodC1jYXJkIHNwYW4ge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDYwcHg7XHJcbiAgfVxyXG5cclxuICBzdmcjcm9ja2V0IHtcclxuICAgIHdpZHRoOiA4MHB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgbGVmdDogLTEwcHg7XHJcbiAgICB0b3A6IC0yNHB4O1xyXG4gIH1cclxuXHJcbiAgc3ZnI3JvY2tldC1zbW9rZSB7XHJcbiAgICBoZWlnaHQ6IGNhbGMoMTAwdmggLSA5NXB4KTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMTBweDtcclxuICAgIHJpZ2h0OiAxODBweDtcclxuICAgIHotaW5kZXg6IC0xMDtcclxuICB9XHJcblxyXG4gIGEsXHJcbiAgYTp2aXNpdGVkLFxyXG4gIGE6aG92ZXIge1xyXG4gICAgY29sb3I6ICMxOTc2ZDI7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgfVxyXG5cclxuICBhOmhvdmVyIHtcclxuICAgIGNvbG9yOiAjMTI1Njk5O1xyXG4gIH1cclxuXHJcbiAgLnRlcm1pbmFsIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHdpZHRoOiA4MCU7XHJcbiAgICBtYXgtd2lkdGg6IDYwMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gICAgcGFkZGluZy10b3A6IDQ1cHg7XHJcbiAgICBtYXJnaW4tdG9wOiA4cHg7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE1LCAxNSwgMTYpO1xyXG4gIH1cclxuXHJcbiAgLnRlcm1pbmFsOjpiZWZvcmUge1xyXG4gICAgY29udGVudDogXCJcXDIwMjIgXFwyMDIyIFxcMjAyMlwiO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgbGVmdDogMDtcclxuICAgIGhlaWdodDogNHB4O1xyXG4gICAgYmFja2dyb3VuZDogcmdiKDU4LCA1OCwgNTgpO1xyXG4gICAgY29sb3I6ICNjMmMzYzQ7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGZvbnQtc2l6ZTogMnJlbTtcclxuICAgIGxpbmUtaGVpZ2h0OiAwO1xyXG4gICAgcGFkZGluZzogMTRweCAwO1xyXG4gICAgdGV4dC1pbmRlbnQ6IDRweDtcclxuICB9XHJcblxyXG4gIC50ZXJtaW5hbCBwcmUge1xyXG4gICAgZm9udC1mYW1pbHk6IFNGTW9uby1SZWd1bGFyLENvbnNvbGFzLExpYmVyYXRpb24gTW9ubyxNZW5sbyxtb25vc3BhY2U7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBwYWRkaW5nOiAwIDFyZW0gMXJlbTtcclxuICAgIG1hcmdpbjogMDtcclxuICB9XHJcblxyXG4gIC5jaXJjbGUtbGluayB7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICB3aWR0aDogNDBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDQwcHg7XHJcbiAgICBtYXJnaW46IDhweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2VlZWVlZTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBib3gtc2hhZG93OiAwIDFweCAzcHggcmdiYSgwLCAwLCAwLCAwLjEyKSwgMCAxcHggMnB4IHJnYmEoMCwgMCwgMCwgMC4yNCk7XHJcbiAgICB0cmFuc2l0aW9uOiAxcyBlYXNlLW91dDtcclxuICB9XHJcblxyXG4gIC5jaXJjbGUtbGluazpob3ZlciB7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTAuMjVyZW0pO1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDNweCAxNXB4IHJnYmEoMCwgMCwgMCwgMC4yKTtcclxuICB9XHJcblxyXG4gIGZvb3RlciB7XHJcbiAgICBtYXJnaW4tdG9wOiA4cHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGxpbmUtaGVpZ2h0OiAyMHB4O1xyXG4gIH1cclxuXHJcbiAgZm9vdGVyIGEge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgfVxyXG5cclxuICAuZ2l0aHViLXN0YXItYmFkZ2Uge1xyXG4gICAgY29sb3I6ICMyNDI5MmU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIHBhZGRpbmc6IDNweCAxMHB4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgyNywzMSwzNSwuMik7XHJcbiAgICBib3JkZXItcmFkaXVzOiAzcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQoLTE4MGRlZywjZmFmYmZjLCNlZmYzZjYgOTAlKTtcclxuICAgIG1hcmdpbi1sZWZ0OiA0cHg7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgZm9udC1mYW1pbHk6IC1hcHBsZS1zeXN0ZW0sQmxpbmtNYWNTeXN0ZW1Gb250LFNlZ29lIFVJLEhlbHZldGljYSxBcmlhbCxzYW5zLXNlcmlmLEFwcGxlIENvbG9yIEVtb2ppLFNlZ29lIFVJIEVtb2ppLFNlZ29lIFVJIFN5bWJvbDtcclxuICB9XHJcblxyXG4gIC5naXRodWItc3Rhci1iYWRnZTpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQoLTE4MGRlZywjZjBmM2Y2LCNlNmViZjEgOTAlKTtcclxuICAgIGJvcmRlci1jb2xvcjogcmdiYSgyNywzMSwzNSwuMzUpO1xyXG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogLS41ZW07XHJcbiAgfVxyXG5cclxuICAuZ2l0aHViLXN0YXItYmFkZ2UgLm1hdGVyaWFsLWljb25zIHtcclxuICAgIGhlaWdodDogMTZweDtcclxuICAgIHdpZHRoOiAxNnB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA0cHg7XHJcbiAgfVxyXG5cclxuICBzdmcjY2xvdWRzIHtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIGJvdHRvbTogLTE2MHB4O1xyXG4gICAgbGVmdDogLTIzMHB4O1xyXG4gICAgei1pbmRleDogLTEwO1xyXG4gICAgd2lkdGg6IDE5MjBweDtcclxuICB9XHJcblxyXG5cclxuICAvKiBSZXNwb25zaXZlIFN0eWxlcyAqL1xyXG4gIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDc2N3B4KSB7XHJcblxyXG4gICAgLmNhcmQtY29udGFpbmVyID4gKjpub3QoLmNpcmNsZS1saW5rKSAsXHJcbiAgICAudGVybWluYWwge1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICAgIH1cclxuXHJcbiAgICAuY2FyZDpub3QoLmhpZ2hsaWdodC1jYXJkKSB7XHJcbiAgICAgIGhlaWdodDogMTZweDtcclxuICAgICAgbWFyZ2luOiA4cHggMDtcclxuICAgIH1cclxuXHJcbiAgICAuY2FyZC5oaWdobGlnaHQtY2FyZCBzcGFuIHtcclxuICAgICAgbWFyZ2luLWxlZnQ6IDcycHg7XHJcbiAgICB9XHJcblxyXG4gICAgc3ZnI3JvY2tldC1zbW9rZSB7XHJcbiAgICAgIHJpZ2h0OiAxMjBweDtcclxuICAgICAgdHJhbnNmb3JtOiByb3RhdGUoLTVkZWcpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTc1cHgpIHtcclxuICAgIHN2ZyNyb2NrZXQtc21va2Uge1xyXG4gICAgICBkaXNwbGF5OiBub25lO1xyXG4gICAgICB2aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgICB9XHJcbiAgfSJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-root',
                templateUrl: './app.component.html',
                styleUrls: ['./app.component.css']
            }]
    }], function () { return [{ type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["Title"] }, { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["Meta"] }]; }, null); })();


/***/ }),

/***/ "./src/app/app.module.custom.ts":
/*!**************************************!*\
  !*** ./src/app/app.module.custom.ts ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_login_component_login_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/login-component/login.component */ "./src/app/components/login-component/login.component.ts");
/* harmony import */ var _components_admin_component_admin_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/admin-component/admin.component */ "./src/app/components/admin-component/admin.component.ts");
/* harmony import */ var _components_footer_component_footer_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/footer-component/footer.component */ "./src/app/components/footer-component/footer.component.ts");
/* harmony import */ var _components_person_link_component_person_link_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/person-link-component/person-link.component */ "./src/app/components/person-link-component/person-link.component.ts");
/* harmony import */ var _components_person_links_component_person_links_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/person-links-component/person-links.component */ "./src/app/components/person-links-component/person-links.component.ts");
/* harmony import */ var _components_main_component_main_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/main-component/main.component */ "./src/app/components/main-component/main.component.ts");
/* harmony import */ var _components_nav_component_nav_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/nav-component/nav.component */ "./src/app/components/nav-component/nav.component.ts");
/* harmony import */ var _components_help_component_help_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/help-component/help.component */ "./src/app/components/help-component/help.component.ts");
/* harmony import */ var _components_person_component_person_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/person-component/person.component */ "./src/app/components/person-component/person.component.ts");
/* harmony import */ var _components_tree_component_tree_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/tree-component/tree.component */ "./src/app/components/tree-component/tree.component.ts");
/* harmony import */ var _components_person_profile_component_person_profile_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/person-profile-component/person-profile.component */ "./src/app/components/person-profile-component/person-profile.component.ts");
/* harmony import */ var _components_login_register_component_login_register_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/login-register-component/login-register.component */ "./src/app/components/login-register-component/login-register.component.ts");
/* harmony import */ var _components_photo_component_photo_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/photo-component/photo.component */ "./src/app/components/photo-component/photo.component.ts");
/* harmony import */ var _components_person_profile_detail_component_person_profile_detail_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./components/person-profile-detail-component/person-profile-detail.component */ "./src/app/components/person-profile-detail-component/person-profile-detail.component.ts");
/* harmony import */ var _components_person_search_component_person_search_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components/person-search-component/person-search.component */ "./src/app/components/person-search-component/person-search.component.ts");


;













/* harmony default export */ __webpack_exports__["default"] = ([
    _components_person_component_person_component__WEBPACK_IMPORTED_MODULE_8__["PersonComponentComponent"],
    _components_main_component_main_component__WEBPACK_IMPORTED_MODULE_5__["MainComponent"],
    _components_admin_component_admin_component__WEBPACK_IMPORTED_MODULE_1__["AdminComponent"],
    _components_nav_component_nav_component__WEBPACK_IMPORTED_MODULE_6__["NavComponent"],
    _components_help_component_help_component__WEBPACK_IMPORTED_MODULE_7__["HelpComponent"],
    _components_login_component_login_component__WEBPACK_IMPORTED_MODULE_0__["LoginComponent"],
    _components_login_register_component_login_register_component__WEBPACK_IMPORTED_MODULE_11__["LoginRegisterComponent"],
    _components_footer_component_footer_component__WEBPACK_IMPORTED_MODULE_2__["FooterComponent"],
    _components_person_links_component_person_links_component__WEBPACK_IMPORTED_MODULE_4__["PersonLinksComponent"],
    _components_person_link_component_person_link_component__WEBPACK_IMPORTED_MODULE_3__["PersonLinkComponent"],
    _components_tree_component_tree_component__WEBPACK_IMPORTED_MODULE_9__["TreeComponent"],
    _components_person_profile_component_person_profile_component__WEBPACK_IMPORTED_MODULE_10__["PersonProfileComponent"],
    _components_person_profile_detail_component_person_profile_detail_component__WEBPACK_IMPORTED_MODULE_13__["PersonProfileDetailComponent"],
    _components_photo_component_photo_component__WEBPACK_IMPORTED_MODULE_12__["PhotoComponent"],
    _components_person_search_component_person_search_component__WEBPACK_IMPORTED_MODULE_14__["PersonSearchComponent"]
]);


/***/ }),

/***/ "./src/app/app.module.material.ts":
/*!****************************************!*\
  !*** ./src/app/app.module.material.ts ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/material/toolbar */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/toolbar.js");
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/menu */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/menu.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
/* harmony import */ var _angular_material_list__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/list */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/list.js");
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/select */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/select.js");
/* harmony import */ var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/tabs */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/tabs.js");
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/snack-bar */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/snack-bar.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/sort */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/sort.js");
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/paginator */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/paginator.js");
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/tooltip */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/tooltip.js");
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/expansion */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/expansion.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/icon.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/table.js");
/* harmony import */ var _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/slide-toggle */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/slide-toggle.js");
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/card */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/card.js");
/* harmony import */ var _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/grid-list */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/grid-list.js");
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/datepicker */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/datepicker.js");
/* harmony import */ var _angular_material_chips__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/material/chips */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/chips.js");
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/material/checkbox */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/checkbox.js");
/* harmony import */ var _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/material/autocomplete */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/autocomplete.js");






















/* harmony default export */ __webpack_exports__["default"] = ([
    _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_20__["MatCheckboxModule"],
    _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_21__["MatAutocompleteModule"],
    _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_18__["MatDatepickerModule"],
    _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_17__["MatGridListModule"],
    _angular_material_input__WEBPACK_IMPORTED_MODULE_7__["MatInputModule"],
    _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_0__["MatToolbarModule"],
    _angular_material_menu__WEBPACK_IMPORTED_MODULE_1__["MatMenuModule"],
    _angular_material_form_field__WEBPACK_IMPORTED_MODULE_2__["MatFormFieldModule"],
    _angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__["MatTabsModule"],
    _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_6__["MatSnackBarModule"],
    _angular_material_table__WEBPACK_IMPORTED_MODULE_14__["MatTableModule"],
    _angular_material_sort__WEBPACK_IMPORTED_MODULE_8__["MatSortModule"],
    _angular_material_paginator__WEBPACK_IMPORTED_MODULE_9__["MatPaginatorModule"],
    _angular_material_list__WEBPACK_IMPORTED_MODULE_3__["MatListModule"],
    _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_15__["MatSlideToggleModule"],
    _angular_material_select__WEBPACK_IMPORTED_MODULE_4__["MatSelectModule"],
    _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_10__["MatTooltipModule"],
    _angular_material_expansion__WEBPACK_IMPORTED_MODULE_11__["MatExpansionModule"],
    _angular_material_button__WEBPACK_IMPORTED_MODULE_12__["MatButtonModule"],
    _angular_material_icon__WEBPACK_IMPORTED_MODULE_13__["MatIconModule"],
    _angular_material_card__WEBPACK_IMPORTED_MODULE_16__["MatCardModule"],
    _angular_material_chips__WEBPACK_IMPORTED_MODULE_19__["MatChipsModule"]
]);


/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/animations.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_cdk_table__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/table */ "./node_modules/@angular/cdk/__ivy_ngcc__/fesm2015/table.js");
/* harmony import */ var _app_module_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app.module.material */ "./src/app/app.module.material.ts");
/* harmony import */ var _app_module_custom__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./app.module.custom */ "./src/app/app.module.custom.ts");
/* harmony import */ var _components_share_component_share_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/share-component/share.component */ "./src/app/components/share-component/share.component.ts");
/* harmony import */ var _components_person_component_person_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/person-component/person.component */ "./src/app/components/person-component/person.component.ts");
/* harmony import */ var _components_main_component_main_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/main-component/main.component */ "./src/app/components/main-component/main.component.ts");
/* harmony import */ var _components_admin_component_admin_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./components/admin-component/admin.component */ "./src/app/components/admin-component/admin.component.ts");
/* harmony import */ var _components_nav_component_nav_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components/nav-component/nav.component */ "./src/app/components/nav-component/nav.component.ts");
/* harmony import */ var _components_help_component_help_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./components/help-component/help.component */ "./src/app/components/help-component/help.component.ts");
/* harmony import */ var _components_login_component_login_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./components/login-component/login.component */ "./src/app/components/login-component/login.component.ts");
/* harmony import */ var _components_login_register_component_login_register_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./components/login-register-component/login-register.component */ "./src/app/components/login-register-component/login-register.component.ts");
/* harmony import */ var _components_footer_component_footer_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./components/footer-component/footer.component */ "./src/app/components/footer-component/footer.component.ts");
/* harmony import */ var _components_person_links_component_person_links_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./components/person-links-component/person-links.component */ "./src/app/components/person-links-component/person-links.component.ts");
/* harmony import */ var _components_person_link_component_person_link_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./components/person-link-component/person-link.component */ "./src/app/components/person-link-component/person-link.component.ts");
/* harmony import */ var _components_tree_component_tree_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./components/tree-component/tree.component */ "./src/app/components/tree-component/tree.component.ts");
/* harmony import */ var _components_person_profile_component_person_profile_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./components/person-profile-component/person-profile.component */ "./src/app/components/person-profile-component/person-profile.component.ts");
/* harmony import */ var _components_person_profile_detail_component_person_profile_detail_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./components/person-profile-detail-component/person-profile-detail.component */ "./src/app/components/person-profile-detail-component/person-profile-detail.component.ts");
/* harmony import */ var _components_photo_component_photo_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./components/photo-component/photo.component */ "./src/app/components/photo-component/photo.component.ts");
/* harmony import */ var _components_person_search_component_person_search_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./components/person-search-component/person-search.component */ "./src/app/components/person-search-component/person-search.component.ts");
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/material/checkbox */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/checkbox.js");
/* harmony import */ var _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/material/autocomplete */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/autocomplete.js");
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/material/datepicker */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/datepicker.js");
/* harmony import */ var _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/material/grid-list */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/grid-list.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @angular/material/toolbar */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/toolbar.js");
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @angular/material/menu */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/menu.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
/* harmony import */ var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @angular/material/tabs */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/tabs.js");
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @angular/material/snack-bar */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/snack-bar.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/table.js");
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @angular/material/sort */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/sort.js");
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @angular/material/paginator */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/paginator.js");
/* harmony import */ var _angular_material_list__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @angular/material/list */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/list.js");
/* harmony import */ var _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! @angular/material/slide-toggle */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/slide-toggle.js");
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! @angular/material/select */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/select.js");
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! @angular/material/tooltip */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/tooltip.js");
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! @angular/material/expansion */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/expansion.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/icon.js");
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! @angular/material/card */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/card.js");
/* harmony import */ var _angular_material_chips__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! @angular/material/chips */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/chips.js");

















































class AppModule {
}
AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]] });
AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ factory: function AppModule_Factory(t) { return new (t || AppModule)(); }, providers: [], imports: [[
            ..._app_module_material__WEBPACK_IMPORTED_MODULE_8__["default"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"],
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__["NoopAnimationsModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
            _angular_cdk_table__WEBPACK_IMPORTED_MODULE_7__["CdkTableModule"],
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"], _components_person_component_person_component__WEBPACK_IMPORTED_MODULE_11__["PersonComponentComponent"], _components_main_component_main_component__WEBPACK_IMPORTED_MODULE_12__["MainComponent"], _components_admin_component_admin_component__WEBPACK_IMPORTED_MODULE_13__["AdminComponent"], _components_nav_component_nav_component__WEBPACK_IMPORTED_MODULE_14__["NavComponent"], _components_help_component_help_component__WEBPACK_IMPORTED_MODULE_15__["HelpComponent"], _components_login_component_login_component__WEBPACK_IMPORTED_MODULE_16__["LoginComponent"], _components_login_register_component_login_register_component__WEBPACK_IMPORTED_MODULE_17__["LoginRegisterComponent"], _components_footer_component_footer_component__WEBPACK_IMPORTED_MODULE_18__["FooterComponent"], _components_person_links_component_person_links_component__WEBPACK_IMPORTED_MODULE_19__["PersonLinksComponent"], _components_person_link_component_person_link_component__WEBPACK_IMPORTED_MODULE_20__["PersonLinkComponent"], _components_tree_component_tree_component__WEBPACK_IMPORTED_MODULE_21__["TreeComponent"], _components_person_profile_component_person_profile_component__WEBPACK_IMPORTED_MODULE_22__["PersonProfileComponent"], _components_person_profile_detail_component_person_profile_detail_component__WEBPACK_IMPORTED_MODULE_23__["PersonProfileDetailComponent"], _components_photo_component_photo_component__WEBPACK_IMPORTED_MODULE_24__["PhotoComponent"], _components_person_search_component_person_search_component__WEBPACK_IMPORTED_MODULE_25__["PersonSearchComponent"]], imports: [_angular_material_checkbox__WEBPACK_IMPORTED_MODULE_26__["MatCheckboxModule"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_27__["MatAutocompleteModule"], _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_28__["MatDatepickerModule"], _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_29__["MatGridListModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_30__["MatInputModule"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_31__["MatToolbarModule"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_32__["MatMenuModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_33__["MatFormFieldModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_34__["MatTabsModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_35__["MatSnackBarModule"], _angular_material_table__WEBPACK_IMPORTED_MODULE_36__["MatTableModule"], _angular_material_sort__WEBPACK_IMPORTED_MODULE_37__["MatSortModule"], _angular_material_paginator__WEBPACK_IMPORTED_MODULE_38__["MatPaginatorModule"], _angular_material_list__WEBPACK_IMPORTED_MODULE_39__["MatListModule"], _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_40__["MatSlideToggleModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_41__["MatSelectModule"], _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_42__["MatTooltipModule"], _angular_material_expansion__WEBPACK_IMPORTED_MODULE_43__["MatExpansionModule"], _angular_material_button__WEBPACK_IMPORTED_MODULE_44__["MatButtonModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_45__["MatIconModule"], _angular_material_card__WEBPACK_IMPORTED_MODULE_46__["MatCardModule"], _angular_material_chips__WEBPACK_IMPORTED_MODULE_47__["MatChipsModule"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
        _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"],
        _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__["NoopAnimationsModule"],
        _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
        _angular_cdk_table__WEBPACK_IMPORTED_MODULE_7__["CdkTableModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](AppModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"],
        args: [{
                declarations: [
                    _app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"],
                    ..._app_module_custom__WEBPACK_IMPORTED_MODULE_9__["default"],
                ],
                imports: [
                    ..._app_module_material__WEBPACK_IMPORTED_MODULE_8__["default"],
                    _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                    _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"],
                    _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__["NoopAnimationsModule"],
                    _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"],
                    _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"],
                    _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
                    _angular_cdk_table__WEBPACK_IMPORTED_MODULE_7__["CdkTableModule"],
                ],
                entryComponents: [
                    _components_share_component_share_component__WEBPACK_IMPORTED_MODULE_10__["BottomSheetOverviewExampleSheet"]
                ],
                providers: [],
                bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]]
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/components/admin-component/admin.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/components/admin-component/admin.component.ts ***!
  \***************************************************************/
/*! exports provided: AdminComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminComponent", function() { return AdminComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/_services/ConfigurationService */ "./src/app/_services/ConfigurationService.ts");
/* harmony import */ var src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/_services/AuthenticationService */ "./src/app/_services/AuthenticationService.ts");
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/card */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/card.js");
/* harmony import */ var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/tabs */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/tabs.js");






class AdminComponent {
    constructor(configurationService, auth) {
        this.configurationService = configurationService;
        this.auth = auth;
        this.onSetTitle = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.configurationService.getEnvironnement()
            .then(env => {
            this.environnement = env;
        });
        this.configurationService.getApiEndpoint()
            .then(endpoint => {
            this.endpoint = endpoint;
        });
    }
    setTitle() {
        this.onSetTitle.emit('Admin Area');
    }
    isConnected() {
        return this.auth.isConnected();
    }
    connectedLogin() {
        return this.auth.getConnectedLogin();
    }
    connectedProfile() {
        return this.auth.getConnectedProfile();
    }
    ngOnInit() {
    }
    ngAfterContentInit() {
    }
}
AdminComponent.ɵfac = function AdminComponent_Factory(t) { return new (t || AdminComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__["ConfigurationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"])); };
AdminComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AdminComponent, selectors: [["app-admin"]], outputs: { onSetTitle: "onSetTitle" }, decls: 25, vars: 5, consts: [["label", "Info"]], template: function AdminComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-card");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-card-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Admin area");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "mat-tab-group");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mat-tab", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "Env:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "Endpoint:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](13, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "IsConnected:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "Login:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](21, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23, "Profile:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx.environnement, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx.endpoint, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx.isConnected(), "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx.connectedLogin(), "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx.connectedProfile(), " ");
    } }, directives: [_angular_material_card__WEBPACK_IMPORTED_MODULE_3__["MatCard"], _angular_material_card__WEBPACK_IMPORTED_MODULE_3__["MatCardHeader"], _angular_material_card__WEBPACK_IMPORTED_MODULE_3__["MatCardTitle"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_4__["MatTabGroup"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_4__["MatTab"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiIuLi9zcmMvYXBwL2NvbXBvbmVudHMvYWRtaW4tY29tcG9uZW50L2FkbWluLmNvbXBvbmVudC5jc3MifQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AdminComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-admin',
                templateUrl: './admin.component.html',
                styleUrls: ['./admin.component.css']
            }]
    }], function () { return [{ type: src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__["ConfigurationService"] }, { type: src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] }]; }, { onSetTitle: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }] }); })();


/***/ }),

/***/ "./src/app/components/footer-component/footer.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/components/footer-component/footer.component.ts ***!
  \*****************************************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/_services/ConfigurationService */ "./src/app/_services/ConfigurationService.ts");
/* harmony import */ var src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/_services/AuthenticationService */ "./src/app/_services/AuthenticationService.ts");
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/toolbar */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/toolbar.js");





class FooterComponent {
    constructor(configurationService, auth) {
        this.configurationService = configurationService;
        this.auth = auth;
        this.configurationService.getEnvironnement()
            .then(env => {
            this.environnement = env;
        });
        this.configurationService.getApiEndpoint()
            .then(endpoint => {
            this.endpoint = endpoint;
        });
    }
    isConnected() {
        return this.auth.isConnected();
    }
    connectedLogin() {
        return this.auth.getConnectedLogin();
    }
    connectedProfile() {
        return this.auth.getConnectedProfile();
    }
    ngOnInit() {
    }
    ngAfterContentInit() {
    }
}
FooterComponent.ɵfac = function FooterComponent_Factory(t) { return new (t || FooterComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__["ConfigurationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"])); };
FooterComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FooterComponent, selectors: [["app-footer"]], decls: 5, vars: 0, consts: [["color", "primary"]], template: function FooterComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "footer");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-toolbar", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "small");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "\u00A9 Copyright 2020 , Res01.com");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, directives: [_angular_material_toolbar__WEBPACK_IMPORTED_MODULE_3__["MatToolbar"]], styles: ["mat-toolbar[_ngcontent-%COMP%] {\r\n   \r\n    left: 0;\r\n    bottom: 0;\r\n    width: 100%;\r\n    text-align: center;\r\n    max-height: 30px;\r\n    min-height: 30px;\r\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9hcHAvY29tcG9uZW50cy9mb290ZXItY29tcG9uZW50L2Zvb3Rlci5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztJQUVJLE9BQU87SUFDUCxTQUFTO0lBQ1QsV0FBVztJQUNYLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsZ0JBQWdCO0VBQ2xCIiwiZmlsZSI6Ii4uL3NyYy9hcHAvY29tcG9uZW50cy9mb290ZXItY29tcG9uZW50L2Zvb3Rlci5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsibWF0LXRvb2xiYXIge1xyXG4gICBcclxuICAgIGxlZnQ6IDA7XHJcbiAgICBib3R0b206IDA7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIG1heC1oZWlnaHQ6IDMwcHg7XHJcbiAgICBtaW4taGVpZ2h0OiAzMHB4O1xyXG4gIH0iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](FooterComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-footer',
                templateUrl: './footer.component.html',
                styleUrls: ['./footer.component.css']
            }]
    }], function () { return [{ type: src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__["ConfigurationService"] }, { type: src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/components/help-component/help.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/components/help-component/help.component.ts ***!
  \*************************************************************/
/*! exports provided: HelpComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HelpComponent", function() { return HelpComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/card */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/card.js");
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/expansion */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/expansion.js");




class HelpComponent {
    constructor() {
        this.panelOpenState = false;
    }
    ngOnInit() {
    }
    ngAfterContentInit() {
    }
}
HelpComponent.ɵfac = function HelpComponent_Factory(t) { return new (t || HelpComponent)(); };
HelpComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: HelpComponent, selectors: [["app-help"]], decls: 46, vars: 0, consts: [["href", "https://github.com/daniel83fr/genealogy-api"], ["href", "https://github.com/daniel83fr/genealogy-web"], ["href", "https://genealogy-api-staging.herokuapp.com/"], ["href", "https://genealogy-web-staging.herokuapp.com/"], ["href", "https://travis-ci.com/github/daniel83fr/genealogy-api"], ["href", "https://travis-ci.com/github/daniel83fr/genealogy-web"], ["href", "http://www.res01.com"], ["href", "https://genealogy-api.herokuapp.com/"], ["href", "http://www.heroku.com", "target", "_blank"]], template: function HelpComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-card");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-card-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Help");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "mat-accordion");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mat-expansion-panel");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-expansion-panel-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "mat-panel-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, " Technical Info ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "pre");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "\nThe site is composed of two components:\n- an API\n- a frontEnd\n\nBoth are available on github : \n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "a", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "genealogy-api");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "a", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "genealogy-web");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "\n\nFeel free to contribute.\n\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "\n\nSTAGING Env:\nWhen a commit is done on staging environnment,\na build is triggered using heroku and binaries are deployed to :\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "a", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "genealogy-api-staging");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, "\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "a", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23, "genealogy-web-staging");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24, "\n\nPROD:\nWhen a commit is done on prod environnment,\na build is triggered using travis-ci \n\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "a", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "travis - genealogy-api");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "a", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, "travis - genealogy-web");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "\n\nOnce tests executed successfully, it is deployed to \n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "a", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, " Res01.com");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, "\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "a", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, "Api");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](36, "\n\n\nNote both services are hosted for free on ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "a", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](38, "Heroku");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](39, ".\nAfter 30 mins of inactivity, the server is sleeping, and takes a while to restart.\nI may switch to paid hosting if needed.\n\n\n\n  ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "mat-expansion-panel");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "mat-expansion-panel-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "mat-panel-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](43, " Personal Data ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "pre");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, "    By default, names and year of birth/death are visible to everyone.\n    Other informations are only visible logged users.\n\n    To register, you should find your profile first (if it exists) and then\n    claim the profile.\n\n    Roles will be implemented later to avoid sharing all the informations with\n    everyone.\n\n  ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, directives: [_angular_material_card__WEBPACK_IMPORTED_MODULE_1__["MatCard"], _angular_material_card__WEBPACK_IMPORTED_MODULE_1__["MatCardHeader"], _angular_material_card__WEBPACK_IMPORTED_MODULE_1__["MatCardTitle"], _angular_material_expansion__WEBPACK_IMPORTED_MODULE_2__["MatAccordion"], _angular_material_expansion__WEBPACK_IMPORTED_MODULE_2__["MatExpansionPanel"], _angular_material_expansion__WEBPACK_IMPORTED_MODULE_2__["MatExpansionPanelHeader"], _angular_material_expansion__WEBPACK_IMPORTED_MODULE_2__["MatExpansionPanelTitle"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiIuLi9zcmMvYXBwL2NvbXBvbmVudHMvaGVscC1jb21wb25lbnQvaGVscC5jb21wb25lbnQuY3NzIn0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](HelpComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-help',
                templateUrl: './help.component.html',
                styleUrls: ['./help.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/components/login-component/login.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/components/login-component/login.component.ts ***!
  \***************************************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/_services/AuthenticationService */ "./src/app/_services/AuthenticationService.ts");
/* harmony import */ var src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/_services/NotificationService */ "./src/app/_services/NotificationService.ts");
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/card */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/card.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");









function LoginComponent_form_4_Template(rf, ctx) { if (rf & 1) {
    const _r35 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "form", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngSubmit", function LoginComponent_form_4_Template_form_ngSubmit_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r35); const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r34.onSubmit(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Login");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "input", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "Password");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "input", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Login");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, " To create an account, find your profile ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, " then choose claim profile.\n");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx_r32.loginForm);
} }
function LoginComponent_form_5_Template(rf, ctx) { if (rf & 1) {
    const _r37 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "form", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngSubmit", function LoginComponent_form_5_Template_form_ngSubmit_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r37); const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r36.onSubmit(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Login");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "input", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "Password");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "input", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "Password");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "input", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "Password");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](16, "input", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "button", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "Change");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, " To create an account, find your profile ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](20, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, " then choose claim profile.\n");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx_r33.changePasswordForm);
} }
class LoginComponent {
    constructor(fb, auth, notif) {
        this.fb = fb;
        this.auth = auth;
        this.notif = notif;
        this.changePasswordForm = null;
        this.loginForm = null;
        this.loginForm = this.fb.group({
            login: '',
            password: ''
        });
        this.changePasswordForm = this.fb.group({
            login: '',
            password: ''
        });
    }
    onSubmit() {
        const login = this.loginForm.controls.login.value;
        const password = this.loginForm.controls.password.value;
        if (login && password) {
            this.auth.login(login, password)
                .catch(err => {
                this.notif.showError('Login failed');
            });
        }
    }
    ngOnInit() {
    }
    isConnected() {
        return this.auth.isConnected();
    }
    ngAfterContentInit() {
    }
}
LoginComponent.ɵfac = function LoginComponent_Factory(t) { return new (t || LoginComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_3__["NotificationService"])); };
LoginComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: LoginComponent, selectors: [["app-login"]], decls: 6, vars: 2, consts: [["style", "margin: 10px;", 3, "formGroup", "ngSubmit", 4, "ngIf"], [2, "margin", "10px", 3, "formGroup", "ngSubmit"], ["matInput", "", "placeholder", "Login", "formControlName", "login", "type", "text"], ["matInput", "", "placeholder", "Password", "type", "password", "formControlName", "password"], ["matInput", "", "placeholder", "Login", "formControlName", "login", "type", "email"], ["matInput", "", "placeholder", "Old Password", "type", "password", "formControlName", "password"], ["matInput", "", "placeholder", "confirm", "type", "password", "formControlName", "confirm"], ["disabled", ""]], template: function LoginComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-card");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-card-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Credentials");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, LoginComponent_form_4_Template, 14, 1, "form", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, LoginComponent_form_5_Template, 22, 1, "form", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.isConnected());
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.isConnected());
    } }, directives: [_angular_material_card__WEBPACK_IMPORTED_MODULE_4__["MatCard"], _angular_material_card__WEBPACK_IMPORTED_MODULE_4__["MatCardHeader"], _angular_material_card__WEBPACK_IMPORTED_MODULE_4__["MatCardTitle"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgIf"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormGroupDirective"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__["MatFormField"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__["MatLabel"], _angular_material_input__WEBPACK_IMPORTED_MODULE_7__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControlName"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiIuLi9zcmMvYXBwL2NvbXBvbmVudHMvbG9naW4tY29tcG9uZW50L2xvZ2luLmNvbXBvbmVudC5jc3MifQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](LoginComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-login',
                templateUrl: './login.component.html',
                styleUrls: ['./login.component.css']
            }]
    }], function () { return [{ type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"] }, { type: src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] }, { type: src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_3__["NotificationService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/components/login-register-component/login-register.component.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/components/login-register-component/login-register.component.ts ***!
  \*********************************************************************************/
/*! exports provided: LoginRegisterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginRegisterComponent", function() { return LoginRegisterComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/_services/AuthenticationService */ "./src/app/_services/AuthenticationService.ts");
/* harmony import */ var src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/_services/NotificationService */ "./src/app/_services/NotificationService.ts");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");









function LoginRegisterComponent_form_4_Template(rf, ctx) { if (rf & 1) {
    const _r72 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "form", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngSubmit", function LoginRegisterComponent_form_4_Template_form_ngSubmit_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r72); const ctx_r71 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r71.onSubmit(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Profile Id");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "input", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "Login");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "input", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "Email");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](14, "input", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "Password");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](19, "input", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "Confirm");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "input", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "button");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "Claim");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r70 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx_r70.registerForm);
} }
class LoginRegisterComponent {
    constructor(fb, authService, notif) {
        this.fb = fb;
        this.authService = authService;
        this.notif = notif;
        this.id = '';
        this.edit = false;
        this.registerForm = null;
        this.registerForm = this.fb.group({
            id: '',
            login: '',
            password: '',
            confirm: ''
        });
    }
    onSubmit() {
        const id = this.registerForm.controls.id.value;
        const login = this.registerForm.controls.login.value;
        const password = this.registerForm.controls.password.value;
        const confirm = this.registerForm.controls.confirm.value;
        const email = this.registerForm.controls.email.value;
        if (password != confirm) {
            this.notif.showError('Password/confirmation not matching');
            return;
        }
        if (login && password) {
            this.authService.register(id, login, email, password)
                .then(res => {
                this.notif.showSuccess('Registrated');
                window.location.reload();
            }).catch(err => {
                this.notif.showError(err);
            });
        }
    }
    ngOnInit() {
        var _a;
        this.registerForm = this.fb.group({
            id: (_a = this) === null || _a === void 0 ? void 0 : _a.id,
            login: '',
            email: '',
            password: '',
            confirm: ''
        });
    }
    ngAfterContentInit() {
    }
    onChange(value) {
        this.edit = value.checked;
    }
    click() {
        this.edit = !this.edit;
    }
}
LoginRegisterComponent.ɵfac = function LoginRegisterComponent_Factory(t) { return new (t || LoginRegisterComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_3__["NotificationService"])); };
LoginRegisterComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: LoginRegisterComponent, selectors: [["app-login-register"]], inputs: { id: "id" }, decls: 5, vars: 1, consts: [["mat-stroked-button", "", "color", "primary", 3, "click"], ["style", "margin: 10px;", 3, "formGroup", "ngSubmit", 4, "ngIf"], [2, "margin", "10px", 3, "formGroup", "ngSubmit"], ["matInput", "", "placeholder", "ProfileId", "formControlName", "id", "readonly", ""], ["matInput", "", "placeholder", "Login", "formControlName", "login"], ["matInput", "", "placeholder", "Email", "type", "email", "formControlName", "email"], ["matInput", "", "placeholder", "Password", "type", "password", "formControlName", "password"], ["matInput", "", "placeholder", "Confirm", "type", "password", "formControlName", "confirm"]], template: function LoginRegisterComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LoginRegisterComponent_Template_button_click_0_listener() { return ctx.click(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Claim profile");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "\n(This is your profile? Please claim the profile.) ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, LoginRegisterComponent_form_4_Template, 26, 1, "form", 1);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.edit);
    } }, directives: [_angular_material_button__WEBPACK_IMPORTED_MODULE_4__["MatButton"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgIf"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormGroupDirective"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__["MatFormField"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__["MatLabel"], _angular_material_input__WEBPACK_IMPORTED_MODULE_7__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControlName"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiIuLi9zcmMvYXBwL2NvbXBvbmVudHMvbG9naW4tcmVnaXN0ZXItY29tcG9uZW50L2xvZ2luLXJlZ2lzdGVyLmNvbXBvbmVudC5jc3MifQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](LoginRegisterComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-login-register',
                templateUrl: './login-register.component.html',
                styleUrls: ['./login-register.component.css']
            }]
    }], function () { return [{ type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"] }, { type: src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] }, { type: src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_3__["NotificationService"] }]; }, { id: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"],
            args: ['id']
        }] }); })();


/***/ }),

/***/ "./src/app/components/main-component/main.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/components/main-component/main.component.ts ***!
  \*************************************************************/
/*! exports provided: MainComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainComponent", function() { return MainComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/sort */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/sort.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/table.js");
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/paginator */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/paginator.js");
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! socket.io-client */ "./node_modules/socket.io-client/lib/index.js");
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(socket_io_client__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var src_app_services_logger_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/_services/logger_service */ "./src/app/_services/logger_service.ts");
/* harmony import */ var src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/_services/ConfigurationService */ "./src/app/_services/ConfigurationService.ts");
/* harmony import */ var src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/_services/GraphQLService */ "./src/app/_services/GraphQLService.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/_services/AuthenticationService */ "./src/app/_services/AuthenticationService.ts");
/* harmony import */ var src_app_services_ClientCacheService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/_services/ClientCacheService */ "./src/app/_services/ClientCacheService.ts");
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/card */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/card.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/icon.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");






















function MainComponent_th_46_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " FirstName ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function MainComponent_td_47_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r21.firstName, " ");
} }
function MainComponent_th_49_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " LastName ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function MainComponent_td_50_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "td", 32);
} if (rf & 2) {
    const element_r22 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHTML", element_r22.lastName + (element_r22.maidenName == "" ? "" : " (") + element_r22.maidenName + (element_r22.maidenName == "" ? "" : ")"), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
} }
function MainComponent_th_52_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Gender ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function MainComponent_td_53_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r23 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r23.gender, " ");
} }
function MainComponent_th_55_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Year ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function MainComponent_td_56_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r24 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"](" ", element_r24.yearOfBirth, " - ", element_r24.yearOfDeath, "");
} }
function MainComponent_th_58_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Link ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function MainComponent_td_59_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "a", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, " view");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r25 = ctx.$implicit;
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("routerLink", "person/" + element_r25.profileId)("title", ctx_r10.getTitle(element_r25));
} }
function MainComponent_tr_60_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 37);
} }
function MainComponent_tr_61_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 38);
} }
function MainComponent_img_70_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "img", 39);
} if (rf & 2) {
    const image_r27 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", image_r27.url, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
} }
function MainComponent_div_80_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Birthday:");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function MainComponent_div_81_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const b_r28 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"](" ", b_r28.firstName, " ", b_r28.lastName, " ");
} }
function MainComponent_div_82_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Dead Anniversary:");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function MainComponent_div_83_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const b_r29 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"](" ", b_r29.firstName, " ", b_r29.lastName, " ");
} }
function MainComponent_div_84_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Wedding Anniversary:");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function MainComponent_div_85_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const b_r30 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"](" ", b_r30.firstName, " ", b_r30.lastName, " ");
} }
function MainComponent_div_93_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const auditEntry_r31 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](2, 4, auditEntry_r31.timestamp, "short"), " - ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](auditEntry_r31.user);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"](" ", auditEntry_r31.action, " \"", auditEntry_r31.id, "\" ");
} }
const _c0 = function () { return [5, 10, 25]; };
class MainComponent {
    constructor(configurationService, graphQLService, router, auth, cacheService) {
        this.configurationService = configurationService;
        this.graphQLService = graphQLService;
        this.router = router;
        this.auth = auth;
        this.cacheService = cacheService;
        this.logger = new src_app_services_logger_service__WEBPACK_IMPORTED_MODULE_5__["default"]('main');
        this.displayedColumns = [];
        this.inputMessage = '';
        this.messages = '';
        this.date = Date();
    }
    ngOnInit() {
        this.ioClient = socket_io_client__WEBPACK_IMPORTED_MODULE_4___default.a.connect();
        this.ioClient.on('message-received', (msg) => {
            const message = msg + '\r\n';
            this.messages = this.messages + message;
        });
    }
    randomPhotos() {
        const fileCache = __webpack_require__(/*! ../../data/cache/randomPhotos.json */ "./src/app/data/cache/randomPhotos.json");
        this.images = fileCache;
        this.configurationService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQLService.getPhotosRandom(endpoint);
        })
            .then(res => this.images = res);
    }
    ngAfterContentInit() {
        this.search();
        this.randomPhotos();
        this.configurationService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQLService.getAuditLastEntries(endpoint);
        })
            .then(res => this.audit = res);
        this.configurationService.getApiEndpoint()
            .then(endpoint => {
            const res = this.graphQLService.getTodaysEvents(endpoint);
            console.log(JSON.stringify(res));
            return res;
        })
            .then(res => this.events = res);
    }
    search() {
        let cachedItems = this.cacheService.getPersonListFromCache();
        this.fillGrid(cachedItems.data);
        this.configurationService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQLService.getPersonList(endpoint, cachedItems.data.length, cachedItems.timestamp);
        })
            .then(res => {
            console.log(JSON.stringify(res));
            if (!res.isUpToDate) {
                this.logger.info('cache updated');
                this.fillGrid(res.users);
                this.logger.info('search refreshed');
            }
        });
    }
    fillGrid(data) {
        this.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        // if(window.screen.availWidth < 400 ){
        //   this.displayedColumns = ['firstName', 'lastName', 'link'];
        // } else{
        //   this.displayedColumns = ['firstName', 'lastName', 'gender', 'year', 'link'];
        // }
        this.displayedColumns = ['firstName', 'lastName', 'link', 'gender'];
    }
    getTitle(element) {
        var _a, _b;
        const birth = (_a = element.yearOfBirth, (_a !== null && _a !== void 0 ? _a : ''));
        const death = (_b = element.yearOfDeath, (_b !== null && _b !== void 0 ? _b : ''));
        return `${element._id}:
    ${element.firstName} ${element.lastName}
    ${birth}-${death}`;
    }
    navigateTo(url) {
        this.router.navigateByUrl(url);
    }
    applyFilter(event) {
        const filterValue = event.target.value;
        this.dataSource.filter = filterValue.trim().toLowerCase();
    }
    sendMessage(txt) {
        if (txt !== '') {
            this.ioClient.emit('message', this.auth.getConnectedLogin() + ': ' + txt.replace('<', ''));
            this.inputMessage = '';
        }
    }
}
MainComponent.ɵfac = function MainComponent_Factory(t) { return new (t || MainComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_6__["ConfigurationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_7__["GraphQLService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_9__["AuthenticationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_ClientCacheService__WEBPACK_IMPORTED_MODULE_10__["ClientCacheService"])); };
MainComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: MainComponent, selectors: [["app-main"]], viewQuery: function MainComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstaticViewQuery"](_angular_material_sort__WEBPACK_IMPORTED_MODULE_1__["MatSort"], true);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstaticViewQuery"](_angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"], true);
    } if (rf & 2) {
        var _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.sort = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.paginator = _t.first);
    } }, decls: 113, vars: 15, consts: [[1, "splashContent", 2, "width", "auto", "margin-left", "0px", "margin-right", "0px", "justify-content", "center"], ["src", "../../assets/img/main.jpg", "loading", "lazy", "alt", "Photo of Genealogy", "height", "200", 1, "hidden-on-mobile", 2, "border-style", "solid", "border-color", "white", "border-width", "1px"], [1, "hidden-on-desktop", 2, "font-size", "50px", "color", "white"], [1, "main-div", 2, "display", "flex", "flex-direction", "row", "flex-wrap", "wrap", "flex-shrink", "0", "justify-content", "center"], [2, "width", "400px", "margin", "5px"], ["mat-card-avatar", "", 1, "example-header-image"], ["matInput", "", "placeholder", "Ex. Daniel", 3, "keyup"], ["mat-table", "", "matSort", "", "matSortActive", "FirstName", "matSortDirection", "asc", 2, "display", "block", 3, "dataSource"], ["matColumnDef", "firstName"], ["mat-header-cell", "", "mat-sort-header", "", 4, "matHeaderCellDef"], ["mat-cell", "", 4, "matCellDef"], ["matColumnDef", "lastName"], ["mat-cell", "", 3, "innerHTML", 4, "matCellDef"], ["matColumnDef", "gender", 2, "display", "none"], ["mat-header-cell", "", "mat-sort-header", "", "style", "visibility:hidden;", 4, "matHeaderCellDef"], ["mat-cell", "", "style", "visibility:hidden;", 4, "matCellDef"], ["matColumnDef", "year"], ["matColumnDef", "link"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-header-row", "", 4, "matHeaderRowDef"], ["mat-row", "", 4, "matRowDef", "matRowDefColumns"], ["showFirstLastButtons", "", 3, "pageSizeOptions"], ["loading", "lazy", "height", "200", "width", "170", "style", "margin:5px", 3, "src", 4, "ngFor", "ngForOf"], ["style", "font-weight: bold;", 4, "ngIf"], [4, "ngFor", "ngForOf"], ["appearance", "fill"], ["matInput", "", "readonly", "", 2, "height", "200px", "overflow", "scroll", 3, "ngModel", "ngModelChange"], ["matInput", "", "autocomplete", "off", 3, "ngModel", "ngModelChange", "keyup.enter"], [3, "click"], [2, "color", "grey"], ["mat-header-cell", "", "mat-sort-header", ""], ["mat-cell", ""], ["mat-cell", "", 3, "innerHTML"], ["mat-header-cell", "", "mat-sort-header", "", 2, "visibility", "hidden"], ["mat-cell", "", 2, "visibility", "hidden"], ["mat-header-cell", ""], ["mat-button", "", 3, "routerLink", "title"], ["mat-header-row", ""], ["mat-row", ""], ["loading", "lazy", "height", "200", "width", "170", 2, "margin", "5px", 3, "src"], [2, "font-weight", "bold"]], template: function MainComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-card", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Family Tree");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mat-card", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-card-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "Welcome to Family Tree");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "mat-card-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, " A simple website to view/edit family tree and share some photos. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](13, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "Features:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "ul");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "li");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "Family Tree");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "li");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "Photos");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "li");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "Chat");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "li");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24, "... And more");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](25, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, " Note: It's a first version of the site,");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](27, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, " Improvements will come little by little.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](29, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, " Feel free to add content and raise any bugs. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "mat-card", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "mat-card-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](34, "people");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](36, "Search");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "mat-card-subtitle");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](38, "Find a person by name.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "mat-card-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "mat-form-field");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](42, "Filter");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "input", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup", function MainComponent_Template_input_keyup_43_listener($event) { return ctx.applyFilter($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "table", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](45, 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](46, MainComponent_th_46_Template, 2, 0, "th", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](47, MainComponent_td_47_Template, 2, 1, "td", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](48, 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](49, MainComponent_th_49_Template, 2, 0, "th", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](50, MainComponent_td_50_Template, 1, 1, "td", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](51, 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](52, MainComponent_th_52_Template, 2, 0, "th", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](53, MainComponent_td_53_Template, 2, 1, "td", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](54, 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](55, MainComponent_th_55_Template, 2, 0, "th", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](56, MainComponent_td_56_Template, 2, 2, "td", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](57, 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](58, MainComponent_th_58_Template, 2, 0, "th", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](59, MainComponent_td_59_Template, 3, 2, "td", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](60, MainComponent_tr_60_Template, 1, 0, "tr", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](61, MainComponent_tr_61_Template, 1, 0, "tr", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](62, "mat-paginator", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "mat-card", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](64, "mat-card-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](65, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](66, "camera_alt");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](67, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](68, "Random Photos");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](69, "mat-card-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](70, MainComponent_img_70_Template, 1, 1, "img", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "mat-card", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](72, "mat-card-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](73, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](74, "calendar_today");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](75, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](76, "Events");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](77, "mat-card-subtitle");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](78, "TODAY's events2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](79, "mat-card-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](80, MainComponent_div_80_Template, 2, 0, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](81, MainComponent_div_81_Template, 2, 2, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](82, MainComponent_div_82_Template, 2, 0, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](83, MainComponent_div_83_Template, 2, 2, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](84, MainComponent_div_84_Template, 2, 0, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](85, MainComponent_div_85_Template, 2, 2, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](86, "mat-card", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](87, "mat-card-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](88, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](89, "assignment");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](90, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](91, "Recent Activities");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](92, "mat-card-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](93, MainComponent_div_93_Template, 6, 7, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](94, "mat-card", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](95, "mat-card-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](96, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](97, "chat");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](98, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](99, "Messages");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](100, "mat-card-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](101, "mat-form-field", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](102, "textarea", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function MainComponent_Template_textarea_ngModelChange_102_listener($event) { return ctx.messages = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](103, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](104, "mat-form-field", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](105, "input", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function MainComponent_Template_input_ngModelChange_105_listener($event) { return ctx.inputMessage = $event; })("keyup.enter", function MainComponent_Template_input_keyup_enter_105_listener() { return ctx.sendMessage(ctx.inputMessage); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](106, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](107, "button", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MainComponent_Template_button_click_107_listener() { return ctx.sendMessage(ctx.inputMessage); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](108, "Send");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](109, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](110, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](111, " Keywords:\nancestry, genetics, lineage, descent, generation, heredity, history, line, parentage\nblood line, progeniture, clan, folk, group, house, household, people, tribe, ancestors, birth, children, descendants, descent, dynasty, genealogy, generations, in-laws, network,\npedigree, progenitors, progeny, relations, relationship, relatives, siblings,\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](112, "br");
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](44);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("dataSource", ctx.dataSource);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matHeaderRowDef", ctx.displayedColumns);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matRowDefColumns", ctx.displayedColumns);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("pageSizeOptions", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](14, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.images);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx.events == null ? null : ctx.events.birthday == null ? null : ctx.events.birthday.length) > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.events == null ? null : ctx.events.birthday);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx.events == null ? null : ctx.events.deathday == null ? null : ctx.events.deathday.length) > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.events == null ? null : ctx.events.deathday);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx.events == null ? null : ctx.events.marriage == null ? null : ctx.events.marriage.length) > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.events == null ? null : ctx.events.marriage);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.audit);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.messages);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.inputMessage);
    } }, directives: [_angular_material_card__WEBPACK_IMPORTED_MODULE_11__["MatCard"], _angular_material_card__WEBPACK_IMPORTED_MODULE_11__["MatCardHeader"], _angular_material_card__WEBPACK_IMPORTED_MODULE_11__["MatCardAvatar"], _angular_material_card__WEBPACK_IMPORTED_MODULE_11__["MatCardTitle"], _angular_material_card__WEBPACK_IMPORTED_MODULE_11__["MatCardContent"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_12__["MatIcon"], _angular_material_card__WEBPACK_IMPORTED_MODULE_11__["MatCardSubtitle"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_13__["MatFormField"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_13__["MatLabel"], _angular_material_input__WEBPACK_IMPORTED_MODULE_14__["MatInput"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatTable"], _angular_material_sort__WEBPACK_IMPORTED_MODULE_1__["MatSort"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatColumnDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatHeaderCellDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatCellDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatHeaderRowDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatRowDef"], _angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"], _angular_common__WEBPACK_IMPORTED_MODULE_15__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_15__["NgIf"], _angular_forms__WEBPACK_IMPORTED_MODULE_16__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_16__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_16__["NgModel"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatHeaderCell"], _angular_material_sort__WEBPACK_IMPORTED_MODULE_1__["MatSortHeader"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatCell"], _angular_material_button__WEBPACK_IMPORTED_MODULE_17__["MatAnchor"], _angular_router__WEBPACK_IMPORTED_MODULE_8__["RouterLinkWithHref"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatHeaderRow"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatRow"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_15__["DatePipe"]], styles: [".splashContent[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  background-color: #131754;\r\n  flex-direction: row\r\n}\r\n\r\n\r\n\r\n\r\n  .example-header-image[_ngcontent-%COMP%] {\r\n    background-image: url('logo.png');\r\n\r\n    background-size: cover;\r\n  }\r\n\r\n\r\n\r\n\r\n  .main-div[_ngcontent-%COMP%]{\r\n    min-width: 400;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: left;\r\n    vertical-align: top;\r\n  }\r\n\r\n\r\n\r\n\r\n  table[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n  }\r\n\r\n\r\n\r\n\r\n  .mat-form-field[_ngcontent-%COMP%] {\r\n    font-size: 14px;\r\n    width: 100%;\r\n  }\r\n\r\n\r\n\r\n\r\n  td[_ngcontent-%COMP%], th[_ngcontent-%COMP%] {\r\n    width: 25%;\r\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9hcHAvY29tcG9uZW50cy9tYWluLWNvbXBvbmVudC9tYWluLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFhO0VBQ2IseUJBQXlCO0VBQ3pCO0FBQ0Y7Ozs7O0VBS0U7SUFDRSxpQ0FBcUQ7O0lBRXJELHNCQUFzQjtFQUN4Qjs7Ozs7RUFFQTtJQUNFLGNBQWM7SUFDZCxhQUFhO0lBQ2IsdUJBQXVCO0lBQ3ZCLGlCQUFpQjtJQUNqQixtQkFBbUI7RUFDckI7Ozs7O0VBRUE7SUFDRSxXQUFXO0VBQ2I7Ozs7O0VBRUE7SUFDRSxlQUFlO0lBQ2YsV0FBVztFQUNiOzs7OztFQUVBO0lBQ0UsVUFBVTtFQUNaIiwiZmlsZSI6Ii4uL3NyYy9hcHAvY29tcG9uZW50cy9tYWluLWNvbXBvbmVudC9tYWluLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3BsYXNoQ29udGVudCB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTMxNzU0O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiByb3dcclxufVxyXG5cclxuXHJcblxyXG5cclxuICAuZXhhbXBsZS1oZWFkZXItaW1hZ2Uge1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi8uLi9hc3NldHMvaW1nL2xvZ28ucG5nJyk7XHJcblxyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICB9XHJcblxyXG4gIC5tYWluLWRpdntcclxuICAgIG1pbi13aWR0aDogNDAwO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGxlZnQ7XHJcbiAgICB2ZXJ0aWNhbC1hbGlnbjogdG9wO1xyXG4gIH1cclxuXHJcbiAgdGFibGUge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgfVxyXG4gIFxyXG4gIC5tYXQtZm9ybS1maWVsZCB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICB9XHJcbiAgXHJcbiAgdGQsIHRoIHtcclxuICAgIHdpZHRoOiAyNSU7XHJcbiAgfSJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MainComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-main',
                templateUrl: './main.component.html',
                styleUrls: ['./main.component.css']
            }]
    }], function () { return [{ type: src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_6__["ConfigurationService"] }, { type: src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_7__["GraphQLService"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"] }, { type: src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_9__["AuthenticationService"] }, { type: src_app_services_ClientCacheService__WEBPACK_IMPORTED_MODULE_10__["ClientCacheService"] }]; }, { sort: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: [_angular_material_sort__WEBPACK_IMPORTED_MODULE_1__["MatSort"], { static: true }]
        }], paginator: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: [_angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"], { static: true }]
        }] }); })();


/***/ }),

/***/ "./src/app/components/nav-component/nav.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/components/nav-component/nav.component.ts ***!
  \***********************************************************/
/*! exports provided: NavComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavComponent", function() { return NavComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/_services/ConfigurationService */ "./src/app/_services/ConfigurationService.ts");
/* harmony import */ var src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/_services/GraphQLService */ "./src/app/_services/GraphQLService.ts");
/* harmony import */ var src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/_services/AuthenticationService */ "./src/app/_services/AuthenticationService.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/toolbar */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/toolbar.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/menu */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/menu.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/icon.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");












function NavComponent_button_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Login");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function NavComponent_button_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "person");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    const _r62 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matMenuTriggerFor", _r62);
} }
function NavComponent_mat_label_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-label", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Connected as ", ctx_r61.getConnectedLogin(), "");
} }
function NavComponent_button_23_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r63.environnement);
} }
class NavComponent {
    constructor(configurationService, graphQLService, auth, router) {
        this.configurationService = configurationService;
        this.graphQLService = graphQLService;
        this.auth = auth;
        this.router = router;
        this.environnement = '';
        this.connectedUser = '';
        this.profileLink = '/';
    }
    ngOnInit() {
    }
    logout() {
        this.auth.logout();
    }
    isConnected() {
        return this.auth.isConnected();
    }
    getConnectedLogin() {
        return this.auth.getConnectedLogin();
    }
    getConnectedProfile() {
        this.router.navigateByUrl('/person/' + this.getConnectedLogin());
    }
    ngAfterContentInit() {
    }
}
NavComponent.ɵfac = function NavComponent_Factory(t) { return new (t || NavComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__["ConfigurationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_2__["GraphQLService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"])); };
NavComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: NavComponent, selectors: [["app-nav"]], decls: 24, vars: 4, consts: [["color", "primary"], ["mat-flat-button", "", "color", "primary", "routerLink", "/"], ["width", "40", "alt", "Angular Logo", "src", "../../../assets/img/logo.png"], [1, "hidden-on-mobile"], [2, "flex", "auto"], ["mat-raised-button", "", "color", "primary", "routerLink", "/login", 4, "ngIf"], ["mat-icon-button", "", "aria-label", "my profile", 3, "matMenuTriggerFor", 4, "ngIf"], ["style", "font-size:10px", 4, "ngIf"], ["menu", "matMenu"], ["mat-menu-item", "", 3, "click"], ["mat-menu-item", "", "routerLink", "/admin"], ["mat-menu-item", "", "routerLink", "/login"], ["mat-icon-button", "", "routerLink", "/help"], ["mat-raised-button", "", "color", "warn", 4, "ngIf"], ["mat-raised-button", "", "color", "primary", "routerLink", "/login"], ["mat-icon-button", "", "aria-label", "my profile", 3, "matMenuTriggerFor"], [2, "font-size", "10px"], ["mat-raised-button", "", "color", "warn"]], template: function NavComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-toolbar", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-toolbar-row");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "button", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "img", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "www.res01.com");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "span", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, NavComponent_button_7_Template, 2, 0, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, NavComponent_button_8_Template, 3, 1, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, NavComponent_mat_label_9_Template, 2, 1, "mat-label", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "mat-menu", null, 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function NavComponent_Template_button_click_12_listener() { return ctx.getConnectedProfile(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "Profile");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "Admin");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17, "Change credentials");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function NavComponent_Template_button_click_18_listener() { return ctx.logout(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "Logout");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "help_outline");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](23, NavComponent_button_23_Template, 2, 1, "button", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.isConnected());
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.isConnected());
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.isConnected());
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.environnement != "production");
    } }, directives: [_angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__["MatToolbar"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__["MatToolbarRow"], _angular_material_button__WEBPACK_IMPORTED_MODULE_6__["MatButton"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterLink"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["NgIf"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_8__["_MatMenu"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_8__["MatMenuItem"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_9__["MatIcon"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_8__["MatMenuTrigger"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__["MatLabel"]], styles: ["mat-toolbar[_ngcontent-%COMP%] {\r\n    max-height: 50px;\r\n    min-height: 50px;\r\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9hcHAvY29tcG9uZW50cy9uYXYtY29tcG9uZW50L25hdi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksZ0JBQWdCO0lBQ2hCLGdCQUFnQjtFQUNsQiIsImZpbGUiOiIuLi9zcmMvYXBwL2NvbXBvbmVudHMvbmF2LWNvbXBvbmVudC9uYXYuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIm1hdC10b29sYmFyIHtcclxuICAgIG1heC1oZWlnaHQ6IDUwcHg7XHJcbiAgICBtaW4taGVpZ2h0OiA1MHB4O1xyXG4gIH1cclxuXHJcblxyXG4gIl19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NavComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-nav',
                templateUrl: './nav.component.html',
                styleUrls: ['./nav.component.css']
            }]
    }], function () { return [{ type: src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__["ConfigurationService"] }, { type: src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_2__["GraphQLService"] }, { type: src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }]; }, null); })();


/***/ }),

/***/ "./src/app/components/person-component/person.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/components/person-component/person.component.ts ***!
  \*****************************************************************/
/*! exports provided: PersonComponentComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PersonComponentComponent", function() { return PersonComponentComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var d3__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! d3 */ "./node_modules/d3/index.js");
/* harmony import */ var _treeDraw__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../treeDraw */ "./src/app/treeDraw.ts");
/* harmony import */ var src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/_services/ConfigurationService */ "./src/app/_services/ConfigurationService.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/_services/AuthenticationService */ "./src/app/_services/AuthenticationService.ts");
/* harmony import */ var src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/_services/GraphQLService */ "./src/app/_services/GraphQLService.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/expansion */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/expansion.js");
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/card */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/card.js");
/* harmony import */ var _person_profile_component_person_profile_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../person-profile-component/person-profile.component */ "./src/app/components/person-profile-component/person-profile.component.ts");
/* harmony import */ var _person_profile_detail_component_person_profile_detail_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../person-profile-detail-component/person-profile-detail.component */ "./src/app/components/person-profile-detail-component/person-profile-detail.component.ts");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/icon.js");
/* harmony import */ var _person_links_component_person_links_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../person-links-component/person-links.component */ "./src/app/components/person-links-component/person-links.component.ts");
/* harmony import */ var _tree_component_tree_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../tree-component/tree.component */ "./src/app/components/tree-component/tree.component.ts");
/* harmony import */ var _photo_component_photo_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../photo-component/photo.component */ "./src/app/components/photo-component/photo.component.ts");


















function PersonComponentComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-card");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-card-content");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "app-person-profile", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "mat-card");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mat-card-content");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "app-person-profile-detail", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "mat-card");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "mat-card-header");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "mat-card-content", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "mat-card-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "Family Members ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "people_alt");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](14, "app-person-links", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](16, "app-person-links", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](18, "app-person-links", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](19, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](20, "app-person-links", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](21, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](22, "app-person-links", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "mat-card", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](24, "mat-card-header");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "mat-card-content", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](26, "app-tree", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "mat-card");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](28, "mat-card-header");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "mat-card-content", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](30, "app-photo", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("id", ctx_r0.id)("editable", ctx_r0.isConnected())("data", ctx_r0.data.currentPerson);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("id", ctx_r0.id)("editable", ctx_r0.isConnected())("data", ctx_r0.data.currentPerson)("privateData", ctx_r0.privateData);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("id", ctx_r0.id)("person", ctx_r0.data.father)("editable", ctx_r0.isConnected());
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("id", ctx_r0.id)("person", ctx_r0.data.mother)("editable", ctx_r0.isConnected());
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("id", ctx_r0.id)("persons", ctx_r0.data.children)("editable", ctx_r0.isConnected());
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("id", ctx_r0.id)("persons", ctx_r0.data.spouses)("editable", ctx_r0.isConnected());
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("id", ctx_r0.id)("persons", ctx_r0.data.siblings)("editable", ctx_r0.isConnected());
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("data", ctx_r0.data);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("id", ctx_r0.id)("editable", ctx_r0.isConnected());
} }
class PersonComponentComponent {
    constructor(rest, route, router, auth, api, titleService, metaService) {
        this.rest = rest;
        this.route = route;
        this.router = router;
        this.auth = auth;
        this.api = api;
        this.titleService = titleService;
        this.metaService = metaService;
        this.refreshing = false;
        this.id = undefined;
        this.data = {};
        router.events.subscribe((val) => {
            if (this.profile != this.route.snapshot.paramMap.get('profile')) {
                this.profile = this.route.snapshot.paramMap.get('profile');
                this.ngOnChanges();
            }
        });
        this.ngOnChanges();
    }
    isConnected() {
        return this.auth.isConnected();
    }
    getProfileId(profileId) {
        return this.rest.getApiEndpoint()
            .then(endpoint => {
            return this.api.getProfileId(endpoint, profileId);
        });
    }
    getProfileById(id) {
        let cache = localStorage.getItem('profile_' + id);
        let cacheData;
        if (cache != null) {
            cacheData = JSON.parse(cache);
            this.id = cacheData.data.currentPerson._id;
            this.setTitle(cacheData.data.currentPerson);
            this.data = cacheData.data;
            const svg = d3__WEBPACK_IMPORTED_MODULE_1__["select"]('.familyTree');
            new _treeDraw__WEBPACK_IMPORTED_MODULE_2__["TreeDraw"]().draw(svg, cacheData.data);
        }
        if (cacheData == undefined || cacheData.timestamp < new Date(new Date().getTime() - 10 * 60000).toJSON()) {
            this.rest.getApiEndpoint()
                .then(endpoint => {
                return this.api.getProfile(endpoint, id);
            })
                .then(data => {
                this.id = data.currentPerson._id;
                this.setTitle(data.currentPerson);
                this.setMeta(data);
                this.data = data;
                const svg = d3__WEBPACK_IMPORTED_MODULE_1__["select"]('.familyTree');
                new _treeDraw__WEBPACK_IMPORTED_MODULE_2__["TreeDraw"]().draw(svg, data);
            });
        }
    }
    setTitle(person) {
        this.titleService.setTitle(`${person.firstName} ${person.lastName}'s profile`);
    }
    setMeta(data) {
        const person = data.currentPerson;
        this.metaService.updateTag({ content: `${person.firstName} ${person.lastName}'s profile` }, 'name="description"');
        this.metaService.updateTag({ content: `${person.firstName}, ${person.lastName}, profile` }, 'name="keywords"');
    }
    getProfilePrivateById(id) {
        this.rest.getApiEndpoint()
            .then(endpoint => {
            return this.api.getPrivateInfo(endpoint, id);
        })
            .then(data => {
            this.privateData = data;
        });
    }
    ngAfterContentInit() {
    }
    ngOnChanges() {
        if (this.profile == undefined) {
            return;
        }
        console.log(this.profile);
        //this.getProfileId(this.profile)
        // .then(profileId => {
        console.log(this.profile);
        this.getProfileById(this.profile);
        if (this.isConnected()) {
            this.getProfilePrivateById(this.profile);
        }
        //  });
    }
    ngOnInit() {
    }
}
PersonComponentComponent.ɵfac = function PersonComponentComponent_Factory(t) { return new (t || PersonComponentComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_3__["ConfigurationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_6__["GraphQLService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__["Title"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__["Meta"])); };
PersonComponentComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: PersonComponentComponent, selectors: [["app-person-component"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]], decls: 15, vars: 7, consts: [["class", "main-div", "style", "display: flex; flex-direction: row;flex-wrap: wrap; flex-shrink: 0;justify-content: center; ", 4, "ngIf"], [1, "main-div", 2, "display", "flex", "flex-direction", "row", "flex-wrap", "wrap", "flex-shrink", "0", "justify-content", "center"], [3, "id", "editable", "data"], [3, "id", "editable", "data", "privateData"], [2, "padding", "16px"], ["title", "Father", "type", "parent", 3, "id", "person", "editable"], ["title", "Mother", "type", "parent", 3, "id", "person", "editable"], ["title", "Children", "type", "child", 3, "id", "persons", "editable"], ["title", "Spouses", "type", "spouse", 3, "id", "persons", "editable"], ["title", "Siblings", "type", "sibling", 3, "id", "persons", "editable"], [1, "tree-card"], [3, "data"], [3, "id", "editable"]], template: function PersonComponentComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, PersonComponentComponent_div_0_Template, 31, 25, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-accordion");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-expansion-panel");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "mat-expansion-panel-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "mat-panel-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, " Debug ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Data: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "pre");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](9, "json");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, " Private Data: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "pre");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](14, "json");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.id != undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](9, 3, ctx.data), "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](14, 5, ctx.privateData), "");
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_8__["NgIf"], _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__["MatAccordion"], _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__["MatExpansionPanel"], _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__["MatExpansionPanelHeader"], _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__["MatExpansionPanelTitle"], _angular_material_card__WEBPACK_IMPORTED_MODULE_10__["MatCard"], _angular_material_card__WEBPACK_IMPORTED_MODULE_10__["MatCardContent"], _person_profile_component_person_profile_component__WEBPACK_IMPORTED_MODULE_11__["PersonProfileComponent"], _person_profile_detail_component_person_profile_detail_component__WEBPACK_IMPORTED_MODULE_12__["PersonProfileDetailComponent"], _angular_material_card__WEBPACK_IMPORTED_MODULE_10__["MatCardHeader"], _angular_material_card__WEBPACK_IMPORTED_MODULE_10__["MatCardTitle"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_13__["MatIcon"], _person_links_component_person_links_component__WEBPACK_IMPORTED_MODULE_14__["PersonLinksComponent"], _tree_component_tree_component__WEBPACK_IMPORTED_MODULE_15__["TreeComponent"], _photo_component_photo_component__WEBPACK_IMPORTED_MODULE_16__["PhotoComponent"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_8__["JsonPipe"]], styles: [".main-div[_ngcontent-%COMP%]{\r\n    min-width: 400;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: left;\r\n    vertical-align: top;\r\n  }\r\n  \r\n\r\n.linage[_ngcontent-%COMP%] {\r\n    fill: none;\r\n    stroke: black;\r\n}\r\n  \r\n\r\n.marriage[_ngcontent-%COMP%] {\r\n    fill: none;\r\n    stroke: black;\r\n}\r\n  \r\n\r\n.node[_ngcontent-%COMP%] {\r\n    background-color: lightblue;\r\n    border-style: solid;\r\n    border-width: 1px;\r\n}\r\n  \r\n\r\n.nodeText[_ngcontent-%COMP%]{\r\n    font: 10px sans-serif;\r\n}\r\n  \r\n\r\nh1[_ngcontent-%COMP%]{\r\n    margin-left: 20px;\r\n}\r\n  \r\n\r\nmat-card[_ngcontent-%COMP%]{\r\n    width:400px;\r\n    margin:5px;\r\n    padding:0px\r\n}\r\n  \r\n\r\n.tree-card[_ngcontent-%COMP%]{\r\n    width:auto;\r\n    max-width: 1220px;\r\n    overflow:auto;\r\n    padding: 0px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9hcHAvY29tcG9uZW50cy9wZXJzb24tY29tcG9uZW50L3BlcnNvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLGFBQWE7SUFDYix1QkFBdUI7SUFDdkIsaUJBQWlCO0lBQ2pCLG1CQUFtQjtFQUNyQjs7O0FBR0Y7SUFDSSxVQUFVO0lBQ1YsYUFBYTtBQUNqQjs7O0FBQ0E7SUFDSSxVQUFVO0lBQ1YsYUFBYTtBQUNqQjs7O0FBQ0E7SUFDSSwyQkFBMkI7SUFDM0IsbUJBQW1CO0lBQ25CLGlCQUFpQjtBQUNyQjs7O0FBQ0E7SUFDSSxxQkFBcUI7QUFDekI7OztBQUNBO0lBQ0ksaUJBQWlCO0FBQ3JCOzs7QUFFQTtJQUNJLFdBQVc7SUFDWCxVQUFVO0lBQ1Y7QUFDSjs7O0FBRUE7SUFDSSxVQUFVO0lBQ1YsaUJBQWlCO0lBQ2pCLGFBQWE7SUFDYixZQUFZO0FBQ2hCIiwiZmlsZSI6Ii4uL3NyYy9hcHAvY29tcG9uZW50cy9wZXJzb24tY29tcG9uZW50L3BlcnNvbi5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1haW4tZGl2e1xyXG4gICAgbWluLXdpZHRoOiA0MDA7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogbGVmdDtcclxuICAgIHZlcnRpY2FsLWFsaWduOiB0b3A7XHJcbiAgfVxyXG4gIFxyXG5cclxuLmxpbmFnZSB7XHJcbiAgICBmaWxsOiBub25lO1xyXG4gICAgc3Ryb2tlOiBibGFjaztcclxufVxyXG4ubWFycmlhZ2Uge1xyXG4gICAgZmlsbDogbm9uZTtcclxuICAgIHN0cm9rZTogYmxhY2s7XHJcbn1cclxuLm5vZGUge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRibHVlO1xyXG4gICAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuICAgIGJvcmRlci13aWR0aDogMXB4O1xyXG59XHJcbi5ub2RlVGV4dHtcclxuICAgIGZvbnQ6IDEwcHggc2Fucy1zZXJpZjtcclxufVxyXG5oMXtcclxuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG59XHJcblxyXG5tYXQtY2FyZHtcclxuICAgIHdpZHRoOjQwMHB4O1xyXG4gICAgbWFyZ2luOjVweDtcclxuICAgIHBhZGRpbmc6MHB4XHJcbn1cclxuXHJcbi50cmVlLWNhcmR7XHJcbiAgICB3aWR0aDphdXRvO1xyXG4gICAgbWF4LXdpZHRoOiAxMjIwcHg7XHJcbiAgICBvdmVyZmxvdzphdXRvO1xyXG4gICAgcGFkZGluZzogMHB4O1xyXG59XHJcblxyXG4iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](PersonComponentComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-person-component',
                templateUrl: './person.component.html',
                styleUrls: ['./person.component.css']
            }]
    }], function () { return [{ type: src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_3__["ConfigurationService"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }, { type: src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"] }, { type: src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_6__["GraphQLService"] }, { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__["Title"] }, { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__["Meta"] }]; }, null); })();


/***/ }),

/***/ "./src/app/components/person-link-component/person-link.component.ts":
/*!***************************************************************************!*\
  !*** ./src/app/components/person-link-component/person-link.component.ts ***!
  \***************************************************************************/
/*! exports provided: PersonLinkComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PersonLinkComponent", function() { return PersonLinkComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/_services/ConfigurationService */ "./src/app/_services/ConfigurationService.ts");
/* harmony import */ var src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/_services/GraphQLService */ "./src/app/_services/GraphQLService.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/tooltip */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/tooltip.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/icon.js");











function PersonLinkComponent_span_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("(", ctx_r38.person.profileId, ")");
} }
function PersonLinkComponent_button_5_Template(rf, ctx) { if (rf & 1) {
    const _r41 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PersonLinkComponent_button_5_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r41); const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r40.removeLink(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "link_off");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
class PersonLinkComponent {
    constructor(http, fb, rest, graphQLService, router) {
        this.http = http;
        this.fb = fb;
        this.rest = rest;
        this.graphQLService = graphQLService;
        this.router = router;
        this.id = '';
        this.person = {};
        this.editable = false;
        this.type = '';
        this.edit = false;
        this.personEditForm = null;
        this.personEditForm = this.fb.group({
            id: this.person._id,
            firstName: this.person.firstName,
            lastName: this.person.lastName,
            gender: this.person.gender,
            birthDate: this.person.yearOfBirth,
        });
    }
    onClick() {
        this.router.navigateByUrl('person/' + this.person.profileId);
    }
    ngOnInit() {
    }
    ngAfterContentInit() {
    }
    removeLink() {
        if (this.type === 'sibling') {
            this.removeSiblingLink();
        }
        else {
            this.removeDirectLink();
        }
    }
    removeSiblingLink() {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.graphQLService.removeSiblingLink(endpoint, this.id, this.person._id);
        }).then(res => {
            console.log(res);
            location.reload();
        });
    }
    removeDirectLink() {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.graphQLService.removeLink(endpoint, this.id, this.person._id);
        }).then(res => {
            console.log(res);
            location.reload();
        });
    }
}
PersonLinkComponent.ɵfac = function PersonLinkComponent_Factory(t) { return new (t || PersonLinkComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_3__["ConfigurationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_4__["GraphQLService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"])); };
PersonLinkComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: PersonLinkComponent, selectors: [["app-person-link"]], inputs: { id: "id", person: "person", editable: "editable", type: "type" }, decls: 6, vars: 6, consts: [["mat-flat-button", "", 3, "click"], [4, "ngIf"], ["mat-icon-button", "", "color", "warn", "matTooltip", "Remove link", 3, "click", 4, "ngIf"], ["mat-icon-button", "", "color", "warn", "matTooltip", "Remove link", 3, "click"]], template: function PersonLinkComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PersonLinkComponent_Template_button_click_1_listener() { return ctx.onClick(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "uppercase");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, PersonLinkComponent_span_4_Template, 2, 1, "span", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, PersonLinkComponent_button_5_Template, 3, 0, "button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"](" ", ctx.person == null ? null : ctx.person.firstName, " ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](3, 4, ctx.person == null ? null : ctx.person.lastName), "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.editable && ctx.person != null);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.editable && ctx.person != null);
    } }, directives: [_angular_material_button__WEBPACK_IMPORTED_MODULE_6__["MatButton"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["NgIf"], _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_8__["MatTooltip"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_9__["MatIcon"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_7__["UpperCasePipe"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiIuLi9zcmMvYXBwL2NvbXBvbmVudHMvcGVyc29uLWxpbmstY29tcG9uZW50L3BlcnNvbi1saW5rLmNvbXBvbmVudC5jc3MifQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](PersonLinkComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-person-link',
                templateUrl: './person-link.component.html',
                styleUrls: ['./person-link.component.css']
            }]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }, { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] }, { type: src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_3__["ConfigurationService"] }, { type: src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_4__["GraphQLService"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }]; }, { id: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], person: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], editable: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], type: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();


/***/ }),

/***/ "./src/app/components/person-links-component/person-links.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/components/person-links-component/person-links.component.ts ***!
  \*****************************************************************************/
/*! exports provided: PersonLinksComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PersonLinksComponent", function() { return PersonLinksComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/_services/ConfigurationService */ "./src/app/_services/ConfigurationService.ts");
/* harmony import */ var src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/_services/GraphQLService */ "./src/app/_services/GraphQLService.ts");
/* harmony import */ var src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/_services/NotificationService */ "./src/app/_services/NotificationService.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/icon.js");
/* harmony import */ var _person_link_component_person_link_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../person-link-component/person-link.component */ "./src/app/components/person-link-component/person-link.component.ts");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/tooltip */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/tooltip.js");
/* harmony import */ var _person_search_component_person_search_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../person-search-component/person-search.component */ "./src/app/components/person-search-component/person-search.component.ts");















function PersonLinksComponent_button_4_Template(rf, ctx) { if (rf & 1) {
    const _r48 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PersonLinksComponent_button_4_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r48); const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r47.switchEdit(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "edit");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", ctx_r42.edit ? "warn" : "primary");
} }
function PersonLinksComponent_app_person_link_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-person-link", 5);
} if (rf & 2) {
    const ctx_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("id", ctx_r43.id)("person", ctx_r43.person)("type", ctx_r43.type)("editable", ctx_r43.editable && ctx_r43.edit);
} }
function PersonLinksComponent_div_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "app-person-link", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const x_r49 = ctx.$implicit;
    const ctx_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("id", ctx_r44.id)("person", x_r49)("type", ctx_r44.type)("editable", ctx_r44.editable && ctx_r44.edit);
} }
function PersonLinksComponent_div_7_Template(rf, ctx) { if (rf & 1) {
    const _r51 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-form-field", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "FirstName");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "input", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function PersonLinksComponent_div_7_Template_input_ngModelChange_4_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r51); const ctx_r50 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r50.firstName = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mat-form-field", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "LastName");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "input", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function PersonLinksComponent_div_7_Template_input_ngModelChange_8_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r51); const ctx_r52 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r52.lastName = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PersonLinksComponent_div_7_Template_button_click_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r51); const ctx_r53 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r53.createPersonAndLink(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "add");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r45.firstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r45.lastName);
} }
function PersonLinksComponent_div_8_button_2_Template(rf, ctx) { if (rf & 1) {
    const _r56 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PersonLinksComponent_div_8_button_2_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r56); const ctx_r55 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r55.addLink(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "link");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function PersonLinksComponent_div_8_Template(rf, ctx) { if (rf & 1) {
    const _r58 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "app-person-search", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("personChanged", function PersonLinksComponent_div_8_Template_app_person_search_personChanged_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r58); const ctx_r57 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r57.setLink($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, PersonLinksComponent_div_8_button_2_Template, 3, 0, "button", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r46 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r46.editable && ctx_r46.edit && (ctx_r46.person == null ? null : ctx_r46.person._id) == null);
} }
class PersonLinksComponent {
    constructor(http, fb, rest, graphQLService, notif) {
        this.http = http;
        this.fb = fb;
        this.rest = rest;
        this.graphQLService = graphQLService;
        this.notif = notif;
        this.title = '';
        this.id = '';
        this.person = {};
        this.persons = [];
        this.editable = false;
        this.edit = false;
        this.type = '';
        this.linkId = '';
        this.firstName = '';
        this.lastName = '';
        this.personEditForm = null;
        this.personEditForm = this.fb.group({
            id: this.person._id,
            firstName: this.person.FirstName,
            lastName: this.person.LastName,
            gender: this.person.Gender,
            birthDate: this.person.YearOfBirth,
        });
    }
    ngOnInit() {
    }
    ngAfterContentInit() {
    }
    createPersonAndLink() {
        var _a, _b;
        const changes = {};
        changes.firstName = (_a = this.firstName, (_a !== null && _a !== void 0 ? _a : ''));
        changes.lastName = (_b = this.lastName, (_b !== null && _b !== void 0 ? _b : ''));
        if (changes.firstName == '' && changes.lastName == '') {
            this.notif.showError('please fill up the name.');
            return;
        }
        this.rest.getApiEndpoint()
            .then(endpoint => {
            return this.graphQLService.createPerson(endpoint, changes);
        })
            .then(res => {
            this.notif.showSuccess('Person created');
            this.linkId = res;
            this.addLink();
        });
    }
    addLink() {
        var _a, _b;
        console.log(this.linkId);
        if ((_a = this.linkId, (_a !== null && _a !== void 0 ? _a : '' == '')) || (_b = this.id, (_b !== null && _b !== void 0 ? _b : '' == ''))) {
            this.notif.showError('please fill up the link.');
            return;
        }
        switch (this.type) {
            case 'parent':
                this.linkParent();
                break;
            case 'child':
                this.linkChild();
                break;
            case 'spouse':
                this.linkSpouse();
                break;
            case 'sibling':
                this.linkSibling();
                break;
            default:
                alert(this.type + ' not supported');
        }
    }
    removeLink() {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.graphQLService.removeLink(endpoint, this.id, this.person._id);
        })
            .then(res => {
            console.log(res.data);
            this.notif.showSuccess('Link removed');
            location.reload();
        });
    }
    linkParent() {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.graphQLService.linkParent(endpoint, this.id, this.linkId);
        })
            .then(res => {
            this.notif.showSuccess('Link added');
            location.reload();
        });
    }
    linkChild() {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.graphQLService.linkChild(endpoint, this.id, this.linkId);
        })
            .then(res => {
            this.notif.showSuccess('Link added');
            location.reload();
        });
    }
    linkSpouse() {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.graphQLService.linkSpouse(endpoint, this.id, this.linkId);
        })
            .then(res => {
            this.notif.showSuccess('Link added');
            location.reload();
        });
    }
    linkSibling() {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.graphQLService.linkSibling(endpoint, this.id, this.linkId);
        })
            .then(res => {
            this.notif.showSuccess('Link added');
            location.reload();
        });
    }
    switchEdit() {
        this.edit = !this.edit;
    }
    setLink(option) {
        this.linkId = option._id;
    }
}
PersonLinksComponent.ɵfac = function PersonLinksComponent_Factory(t) { return new (t || PersonLinksComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_3__["ConfigurationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_4__["GraphQLService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_5__["NotificationService"])); };
PersonLinksComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: PersonLinksComponent, selectors: [["app-person-links"]], inputs: { title: "title", id: "id", person: "person", persons: "persons", editable: "editable", type: "type" }, decls: 9, vars: 6, consts: [["mat-icon-button", "", 3, "color", "click", 4, "ngIf"], [3, "id", "person", "type", "editable", 4, "ngIf"], [4, "ngFor", "ngForOf"], [4, "ngIf"], ["mat-icon-button", "", 3, "color", "click"], [3, "id", "person", "type", "editable"], ["appearance", "standard"], ["matInput", "", 3, "ngModel", "ngModelChange"], ["mat-icon-button", "", "color", "primary", "matTooltip", "create Person and Link", 3, "click"], [3, "personChanged"], ["mat-icon-button", "", "color", "primary", "matTooltip", "add link", 3, "click", 4, "ngIf"], ["mat-icon-button", "", "color", "primary", "matTooltip", "add link", 3, "click"]], template: function PersonLinksComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, ": ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, PersonLinksComponent_button_4_Template, 3, 1, "button", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, PersonLinksComponent_app_person_link_5_Template, 1, 4, "app-person-link", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, PersonLinksComponent_div_6_Template, 2, 4, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, PersonLinksComponent_div_7_Template, 12, 2, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, PersonLinksComponent_div_8_Template, 3, 1, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.title);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.editable);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.type == "parent");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.persons);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.editable && ctx.edit && (ctx.person == null ? null : ctx.person._id) == null);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.editable && ctx.edit && (ctx.person == null ? null : ctx.person._id) == null);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_6__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["NgForOf"], _angular_material_button__WEBPACK_IMPORTED_MODULE_7__["MatButton"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__["MatIcon"], _person_link_component_person_link_component__WEBPACK_IMPORTED_MODULE_9__["PersonLinkComponent"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__["MatFormField"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__["MatLabel"], _angular_material_input__WEBPACK_IMPORTED_MODULE_11__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgModel"], _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_12__["MatTooltip"], _person_search_component_person_search_component__WEBPACK_IMPORTED_MODULE_13__["PersonSearchComponent"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiIuLi9zcmMvYXBwL2NvbXBvbmVudHMvcGVyc29uLWxpbmtzLWNvbXBvbmVudC9wZXJzb24tbGlua3MuY29tcG9uZW50LmNzcyJ9 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](PersonLinksComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-person-links',
                templateUrl: './person-links.component.html',
                styleUrls: ['./person-links.component.css']
            }]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }, { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] }, { type: src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_3__["ConfigurationService"] }, { type: src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_4__["GraphQLService"] }, { type: src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_5__["NotificationService"] }]; }, { title: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], id: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], person: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], persons: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], editable: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], type: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();


/***/ }),

/***/ "./src/app/components/person-profile-component/person-profile.component.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/components/person-profile-component/person-profile.component.ts ***!
  \*********************************************************************************/
/*! exports provided: PersonProfileComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PersonProfileComponent", function() { return PersonProfileComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/_services/ConfigurationService */ "./src/app/_services/ConfigurationService.ts");
/* harmony import */ var src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/_services/GraphQLService */ "./src/app/_services/GraphQLService.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/_services/NotificationService */ "./src/app/_services/NotificationService.ts");
/* harmony import */ var src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/_services/AuthenticationService */ "./src/app/_services/AuthenticationService.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/icon.js");
/* harmony import */ var _login_register_component_login_register_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../login-register-component/login-register.component */ "./src/app/components/login-register-component/login-register.component.ts");











function PersonProfileComponent_button_0_Template(rf, ctx) { if (rf & 1) {
    const _r69 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PersonProfileComponent_button_0_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r69); const ctx_r68 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r68.switchEdit(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "edit");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function PersonProfileComponent_div_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r65 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Id: ", ctx_r65.data == null ? null : ctx_r65.data._id, "");
} }
function PersonProfileComponent_span_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "app-login-register", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r66 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("id", ctx_r66.data._id);
} }
function PersonProfileComponent_div_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Unclaim profile : Todo");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, " change login: Todo");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, " Change password: Todo\n");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
class PersonProfileComponent {
    constructor(configService, api, fb, notif, auth) {
        this.configService = configService;
        this.api = api;
        this.fb = fb;
        this.notif = notif;
        this.auth = auth;
        this.id = '';
        this.data = {};
        this.editable = false;
        this.personEditForm = null;
        this.editMode = false;
        this.image = '';
        this.personEditForm = this.fb.group({
            id: '',
            firstName: '',
            lastName: '',
            gender: '',
            yearOfBirth: '',
            birthDate: ''
        });
    }
    getConnectedLogin() {
        return this.auth.getConnectedLogin();
    }
    switchEdit() {
        this.notif.showInfo(`To change profile image, please go to photo gallery and choose 'Set as profile' on the selected image.`);
    }
    getImage() {
        this.configService.getApiEndpoint()
            .then(endpoint => {
            return this.api.getProfilePhoto(endpoint, this.id);
        })
            .then(data => {
            var _a;
            if (data != null) {
                this.image = data.url;
                return;
            }
            if (((_a = this.data) === null || _a === void 0 ? void 0 : _a.gender) == 'Female') {
                this.image = '../../../assets/img/profile_female.jpg';
            }
            else {
                this.image = '../../../assets/img/profile_male.jpg';
            }
        });
    }
    ngOnChanges() {
        this.getImage();
    }
    getRole(user) {
        return 'Admin';
    }
    canEditProfile() {
        const connectedUser = 'daniel';
        const role = this.getRole(connectedUser);
        if (role === 'Admin') {
            return true;
        }
        return false;
    }
    ngOnInit() {
    }
    getDisplayName(person) {
        var _a, _b, _c;
        let maidenName = (_a = person) === null || _a === void 0 ? void 0 : _a.maidenName;
        if (!!maidenName) {
            maidenName = ` (${maidenName})`;
        }
        return `${(_b = person) === null || _b === void 0 ? void 0 : _b.firstName} ${(_c = person) === null || _c === void 0 ? void 0 : _c.lastName} ${(maidenName !== null && maidenName !== void 0 ? maidenName : '')}`;
    }
    onChange(value) {
        this.editMode = value.checked;
    }
    canEdit() {
        return this.editMode && this.editable;
    }
}
PersonProfileComponent.ɵfac = function PersonProfileComponent_Factory(t) { return new (t || PersonProfileComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__["ConfigurationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_2__["GraphQLService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_4__["NotificationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"])); };
PersonProfileComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: PersonProfileComponent, selectors: [["app-person-profile"]], inputs: { id: "id", data: "data", editable: "editable" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]], decls: 11, vars: 7, consts: [["mat-icon-button", "", "style", "float: right;", "color", "primary", 3, "click", 4, "ngIf"], [2, "display", "flex", "flex-direction", "column", "width", "350px", "padding", "16px"], [2, "font-size", "larger"], [2, "color", "gray"], ["style", "color: gray;", 4, "ngIf"], [2, "display", "flex", "justify-content", "center", "align-items", "center"], ["width", "300", "loading", "lazy", 3, "src"], [4, "ngIf"], ["mat-icon-button", "", "color", "primary", 2, "float", "right", 3, "click"], [3, "id"]], template: function PersonProfileComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, PersonProfileComponent_button_0_Template, 3, 0, "button", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, PersonProfileComponent_div_6_Template, 2, 1, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "img", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, PersonProfileComponent_span_9_Template, 2, 1, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](10, PersonProfileComponent_div_10_Template, 6, 0, "div", 7);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.editable);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.getDisplayName(ctx.data));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Profile: ", ctx.data == null ? null : ctx.data.profileId, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx.data == null ? null : ctx.data.profileId) != (ctx.data == null ? null : ctx.data._id));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx.image, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.editable && ctx.data && ctx.data.profileId == ctx.data._id);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.getConnectedLogin() == ctx.data.profileId);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_6__["NgIf"], _angular_material_button__WEBPACK_IMPORTED_MODULE_7__["MatButton"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__["MatIcon"], _login_register_component_login_register_component__WEBPACK_IMPORTED_MODULE_9__["LoginRegisterComponent"]], styles: [".row[_ngcontent-%COMP%] {\r\n  display: flex;\r\n}\r\n  \r\n.column[_ngcontent-%COMP%] {\r\n  flex: 50%;\r\n}\r\n  \r\n.mat-select-disabled[_ngcontent-%COMP%]   .mat-select-value[_ngcontent-%COMP%] {\r\n  color: rgba(black, 0.38);\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9hcHAvY29tcG9uZW50cy9wZXJzb24tcHJvZmlsZS1jb21wb25lbnQvcGVyc29uLXByb2ZpbGUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQWE7QUFDZjs7QUFFQTtFQUNFLFNBQVM7QUFDWDs7QUFFQTtFQUNFLHdCQUF3QjtBQUMxQiIsImZpbGUiOiIuLi9zcmMvYXBwL2NvbXBvbmVudHMvcGVyc29uLXByb2ZpbGUtY29tcG9uZW50L3BlcnNvbi1wcm9maWxlLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucm93IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG59XHJcbiAgXHJcbi5jb2x1bW4ge1xyXG4gIGZsZXg6IDUwJTtcclxufVxyXG5cclxuLm1hdC1zZWxlY3QtZGlzYWJsZWQgLm1hdC1zZWxlY3QtdmFsdWUge1xyXG4gIGNvbG9yOiByZ2JhKGJsYWNrLCAwLjM4KTtcclxufSJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](PersonProfileComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-person-profile',
                templateUrl: './person-profile.component.html',
                styleUrls: ['./person-profile.component.css']
            }]
    }], function () { return [{ type: src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__["ConfigurationService"] }, { type: src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_2__["GraphQLService"] }, { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] }, { type: src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_4__["NotificationService"] }, { type: src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"] }]; }, { id: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], data: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], editable: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();


/***/ }),

/***/ "./src/app/components/person-profile-detail-component/person-profile-detail.component.ts":
/*!***********************************************************************************************!*\
  !*** ./src/app/components/person-profile-detail-component/person-profile-detail.component.ts ***!
  \***********************************************************************************************/
/*! exports provided: PersonProfileDetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PersonProfileDetailComponent", function() { return PersonProfileDetailComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/_services/ConfigurationService */ "./src/app/_services/ConfigurationService.ts");
/* harmony import */ var src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/_services/GraphQLService */ "./src/app/_services/GraphQLService.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/_services/NotificationService */ "./src/app/_services/NotificationService.ts");
/* harmony import */ var src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/_services/AuthenticationService */ "./src/app/_services/AuthenticationService.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/card */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/card.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/icon.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/select */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/select.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/core */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/checkbox */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/checkbox.js");
















function PersonProfileDetailComponent_button_0_Template(rf, ctx) { if (rf & 1) {
    const _r116 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PersonProfileDetailComponent_button_0_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r116); const ctx_r115 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r115.switchEdit(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "edit");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r104 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", ctx_r104.editMode ? "warn" : "primary");
} }
function PersonProfileDetailComponent_mat_form_field_18_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-form-field", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "MaidenName");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "input", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r105 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r105.data == null ? null : ctx_r105.data.maidenName)("readonly", !ctx_r105.canEdit());
} }
function PersonProfileDetailComponent_mat_form_field_29_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-form-field", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Birth");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "input", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r106 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r106.data == null ? null : ctx_r106.data.yearOfBirth);
} }
function PersonProfileDetailComponent_div_31_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-checkbox", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Died");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r107 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("checked", ctx_r107.data == null ? null : ctx_r107.data.isDead)("disabled", !ctx_r107.canEdit());
} }
function PersonProfileDetailComponent_mat_form_field_32_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-form-field", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Death");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "input", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r108 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r108.data == null ? null : ctx_r108.data.yearOfDeath);
} }
function PersonProfileDetailComponent_mat_form_field_33_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-form-field", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "BirthDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "input", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r109 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r109.privateData == null ? null : ctx_r109.privateData.birthDate)("readonly", !ctx_r109.canEdit());
} }
function PersonProfileDetailComponent_mat_form_field_34_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-form-field", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "BirthLocation");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "input", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r110 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r110.privateData == null ? null : ctx_r110.privateData.birthLocation)("readonly", !ctx_r110.canEdit());
} }
function PersonProfileDetailComponent_div_35_mat_form_field_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-form-field", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "DeathDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "input", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r117 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r117.privateData == null ? null : ctx_r117.privateData.deathDate)("readonly", !ctx_r117.canEdit());
} }
function PersonProfileDetailComponent_div_35_mat_form_field_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-form-field", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "DeathLocation");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "input", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r118 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r118.privateData == null ? null : ctx_r118.privateData.deathLocation)("readonly", !ctx_r118.canEdit());
} }
function PersonProfileDetailComponent_div_35_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, PersonProfileDetailComponent_div_35_mat_form_field_1_Template, 4, 2, "mat-form-field", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, PersonProfileDetailComponent_div_35_mat_form_field_2_Template, 4, 2, "mat-form-field", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r111 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r111.editable);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r111.editable);
} }
function PersonProfileDetailComponent_div_36_mat_form_field_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-form-field", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Location");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "input", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r119 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r119.privateData == null ? null : ctx_r119.privateData.currentLocation)("readonly", !ctx_r119.canEdit());
} }
function PersonProfileDetailComponent_div_36_mat_form_field_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-form-field", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Phone");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "input", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r120 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r120.privateData == null ? null : ctx_r120.privateData.phone)("readonly", !ctx_r120.canEdit());
} }
function PersonProfileDetailComponent_div_36_mat_form_field_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-form-field", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Email");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "input", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r121 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r121.privateData == null ? null : ctx_r121.privateData.email)("readonly", !ctx_r121.canEdit());
} }
function PersonProfileDetailComponent_div_36_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, PersonProfileDetailComponent_div_36_mat_form_field_1_Template, 4, 2, "mat-form-field", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, PersonProfileDetailComponent_div_36_mat_form_field_2_Template, 4, 2, "mat-form-field", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, PersonProfileDetailComponent_div_36_mat_form_field_3_Template, 4, 2, "mat-form-field", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r112 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r112.editable);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r112.editable);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r112.editable);
} }
function PersonProfileDetailComponent_button_38_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Save");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r113 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", !ctx_r113.personEditForm.valid);
} }
function PersonProfileDetailComponent_button_40_Template(rf, ctx) { if (rf & 1) {
    const _r123 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PersonProfileDetailComponent_button_40_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r123); const ctx_r122 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r122.deleteProfile(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Delete Profile");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
class PersonProfileDetailComponent {
    constructor(rest, api, fb, notif, auth) {
        this.rest = rest;
        this.api = api;
        this.fb = fb;
        this.notif = notif;
        this.auth = auth;
        this.id = '';
        this.data = {};
        this.privateData = {};
        this.editable = false;
        this.personEditForm = null;
        this.editMode = false;
        this.personEditForm = this.fb.group({
            id: '',
            firstName: '',
            lastName: '',
            gender: '',
            yearOfBirth: '',
            birthDate: '',
            yearOfDeath: '',
            deathDate: '',
            isDead: '',
            currentLocation: '',
            birthLocation: '',
            deathLocation: '',
            email: '',
            phone: '',
        });
    }
    ngOnChanges(changes) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q;
        this.personEditForm = this.fb.group({
            id: (_a = this.data) === null || _a === void 0 ? void 0 : _a._id,
            firstName: (_b = this.data) === null || _b === void 0 ? void 0 : _b.firstName,
            lastName: (_c = this.data) === null || _c === void 0 ? void 0 : _c.lastName,
            gender: (_d = this.data) === null || _d === void 0 ? void 0 : _d.gender,
            yearOfBirth: (_e = this.data) === null || _e === void 0 ? void 0 : _e.yearOfBirth,
            birthDate: (_f = this.privateData) === null || _f === void 0 ? void 0 : _f.birthDate,
            yearOfDeath: (_g = this.data) === null || _g === void 0 ? void 0 : _g.yearOfDeath,
            deathDate: (_h = this.privateData) === null || _h === void 0 ? void 0 : _h.deathDate,
            isDead: (_k = (_j = this.data) === null || _j === void 0 ? void 0 : _j.isDead, (_k !== null && _k !== void 0 ? _k : false)),
            currentLocation: (_l = this.privateData) === null || _l === void 0 ? void 0 : _l.currentLocation,
            birthLocation: (_m = this.privateData) === null || _m === void 0 ? void 0 : _m.birthLocation,
            deathLocation: (_o = this.privateData) === null || _o === void 0 ? void 0 : _o.deathLocation,
            email: (_p = this.privateData) === null || _p === void 0 ? void 0 : _p.email,
            phone: (_q = this.privateData) === null || _q === void 0 ? void 0 : _q.phone,
        });
    }
    getImage() {
        var _a;
        if (((_a = this.data) === null || _a === void 0 ? void 0 : _a.gender) === 'Female') {
            return '../../../assets/img/profile_female.jpg';
        }
        return '../../../assets/img/profile_male.jpg';
    }
    getRole(user) {
        return 'Admin';
    }
    canEditProfile() {
        const connectedUser = 'daniel';
        const role = this.getRole(connectedUser);
        if (role === 'Admin') {
            return true;
        }
        return false;
    }
    ngOnInit() {
    }
    onSubmit() {
        var _a, _b, _c, _d, _e, _f, _g;
        const changes = {};
        if (this.personEditForm.get('firstName').value !== this.data.firstName && this.personEditForm.get('firstName').value) {
            changes.firstName = this.personEditForm.get('firstName').value;
        }
        if (this.personEditForm.get('lastName').value !== this.data.lastName && this.personEditForm.get('lastName').value) {
            changes.lastName = this.personEditForm.get('lastName').value;
        }
        if (this.personEditForm.get('gender').value !== this.data.gender && this.personEditForm.get('gender').value) {
            changes.gender = this.personEditForm.get('gender').value;
        }
        if (this.personEditForm.get('isDead').value !== this.data.isDead && this.personEditForm.get('isDead').value) {
            changes.isDead = this.personEditForm.get('isDead').value;
        }
        const privateChanges = {};
        if (this.personEditForm.get('birthDate').value !== ((_a = this.data.privateData) === null || _a === void 0 ? void 0 : _a.birthDate) && this.personEditForm.get('birthDate').value) {
            privateChanges.birthDate = this.personEditForm.get('birthDate').value;
        }
        if (this.personEditForm.get('deathDate').value !== ((_b = this.data.privateData) === null || _b === void 0 ? void 0 : _b.deathDate) && this.personEditForm.get('deathDate').value) {
            privateChanges.deathDate = this.personEditForm.get('deathDate').value;
        }
        if (this.personEditForm.get('currentLocation').value !== ((_c = this.data.privateData) === null || _c === void 0 ? void 0 : _c.currentLocation) && this.personEditForm.get('currentLocation').value) {
            privateChanges.currentLocation = this.personEditForm.get('currentLocation').value;
        }
        if (this.personEditForm.get('birthLocation').value !== ((_d = this.data.privateData) === null || _d === void 0 ? void 0 : _d.birthLocation) && this.personEditForm.get('birthLocation').value) {
            privateChanges.birthLocation = this.personEditForm.get('birthLocation').value;
        }
        if (this.personEditForm.get('deathLocation').value !== ((_e = this.data.privateData) === null || _e === void 0 ? void 0 : _e.deathLocation) && this.personEditForm.get('deathLocation').value) {
            privateChanges.deathLocation = this.personEditForm.get('deathLocation').value;
        }
        if (this.personEditForm.get('phone').value !== ((_f = this.data.privateData) === null || _f === void 0 ? void 0 : _f.phone) && this.personEditForm.get('phone').value) {
            privateChanges.phone = this.personEditForm.get('phone').value;
        }
        if (this.personEditForm.get('email').value !== ((_g = this.data.privateData) === null || _g === void 0 ? void 0 : _g.email) && this.personEditForm.get('email').value) {
            privateChanges.email = this.personEditForm.get('email').value;
        }
        if (Object.keys(changes).length === 0 && changes.constructor === Object &&
            Object.keys(privateChanges).length === 0 && privateChanges.constructor === Object) {
        }
        else {
            this.rest.getApiEndpoint().then((endpoint) => {
                this.updateProfile(this.id, changes, privateChanges);
            });
        }
    }
    switchEdit() {
        this.editMode = !this.editMode;
    }
    deleteProfile() {
        const r = confirm(`Delete ${this.data._id}?`);
        if (r === true) {
            // OK
            this.rest.getApiEndpoint()
                .then((endpoint) => {
                return this.api.deleteProfile(endpoint.toString(), this.id);
            })
                .then(res => {
                console.log(res.data);
                this.notif.showSuccess(res.data.removeProfile);
                window.location.href = '/';
            });
        }
    }
    getDisplayName(person) {
        var _a, _b, _c;
        let maidenName = (_a = person) === null || _a === void 0 ? void 0 : _a.maidenName;
        if (!!maidenName) {
            maidenName = ` (${maidenName})`;
        }
        return `${(_b = person) === null || _b === void 0 ? void 0 : _b.firstName} ${(_c = person) === null || _c === void 0 ? void 0 : _c.lastName} ${(maidenName !== null && maidenName !== void 0 ? maidenName : '')}`;
    }
    onChange(value) {
        this.editMode = value.checked;
    }
    canEdit() {
        return this.editMode && this.editable;
    }
    updateProfile(id, changes, privateChanges) {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.api.updateProfile(endpoint, id, changes, privateChanges, this.auth.getConnectedProfile());
        })
            .then(res => {
            this.notif.showSuccess('Profile updated.');
            location.reload();
        })
            .catch(err => {
            alert(err);
        });
    }
}
PersonProfileDetailComponent.ɵfac = function PersonProfileDetailComponent_Factory(t) { return new (t || PersonProfileDetailComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__["ConfigurationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_2__["GraphQLService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_4__["NotificationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"])); };
PersonProfileDetailComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: PersonProfileDetailComponent, selectors: [["app-person-profile-detail"]], inputs: { id: "id", data: "data", privateData: "privateData", editable: "editable" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]], decls: 42, vars: 18, consts: [["mat-icon-button", "", "style", "float: right;", 3, "color", "click", 4, "ngIf"], [1, "row", 2, "padding", "16px"], [1, "column"], [1, "row"], [3, "formGroup", "ngSubmit"], ["appearance", "standard"], ["matInput", "", "placeholder", "firstName", "formControlName", "firstName", 3, "value", "readonly"], ["matInput", "", "placeholder", "lastName", "formControlName", "lastName", 3, "value", "readonly"], ["appearance", "standard", 4, "ngIf"], ["formControlName", "gender", "placeholder", "gender", 3, "value", "disabled"], ["value", "Female"], ["value", "Male"], [4, "ngIf"], ["mat-stroked-button", "", "color", "primary", 3, "disabled", 4, "ngIf"], ["mat-button", "", "color", "warn", 3, "click", 4, "ngIf"], ["mat-icon-button", "", 2, "float", "right", 3, "color", "click"], ["matInput", "", "placeholder", "maidenName", 3, "value", "readonly"], ["matInput", "", "type", "string", "placeholder", "yearOfBirth", "readonly", "", "formControlName", "yearOfBirth", 3, "value"], ["placeholder", "isDead", 3, "checked", "disabled"], ["matInput", "", "type", "string", "placeholder", "yearOfDeath", "readonly", "", "formControlName", "yearOfDeath", 3, "value"], ["matInput", "", "type", "date", "placeholder", "birthDate", "formControlName", "birthDate", 3, "value", "readonly"], ["matInput", "", "type", "text", "placeholder", "birthLocation", "formControlName", "birthLocation", 3, "value", "readonly"], ["matInput", "", "type", "date", "placeholder", "deathDate", "formControlName", "deathDate", 3, "value", "readonly"], ["matInput", "", "type", "text", "placeholder", "deathLocation", "formControlName", "deathLocation", 3, "value", "readonly"], ["matInput", "", "type", "text", "placeholder", "currentLocation", "formControlName", "currentLocation", 3, "value", "readonly"], ["matInput", "", "type", "text", "placeholder", "Phone", "formControlName", "phone", 3, "value", "readonly"], ["matInput", "", "type", "email", "placeholder", "email", "formControlName", "email", 3, "value", "readonly"], ["mat-stroked-button", "", "color", "primary", 3, "disabled"], ["mat-button", "", "color", "warn", 3, "click"]], template: function PersonProfileDetailComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, PersonProfileDetailComponent_button_0_Template, 3, 1, "button", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Info");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "face");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "form", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngSubmit", function PersonProfileDetailComponent_Template_form_ngSubmit_9_listener() { return ctx.onSubmit(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "mat-form-field", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "FirstName");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](13, "input", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "mat-form-field", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "LastName");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "input", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](18, PersonProfileDetailComponent_mat_form_field_18_Template, 4, 2, "mat-form-field", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](19, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "mat-form-field", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "Gender");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "mat-select", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "mat-option", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "Female");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "mat-option", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "Male");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](28, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](29, PersonProfileDetailComponent_mat_form_field_29_Template, 4, 1, "mat-form-field", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](30, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](31, PersonProfileDetailComponent_div_31_Template, 4, 2, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](32, PersonProfileDetailComponent_mat_form_field_32_Template, 4, 1, "mat-form-field", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](33, PersonProfileDetailComponent_mat_form_field_33_Template, 4, 2, "mat-form-field", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](34, PersonProfileDetailComponent_mat_form_field_34_Template, 4, 2, "mat-form-field", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](35, PersonProfileDetailComponent_div_35_Template, 3, 2, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](36, PersonProfileDetailComponent_div_36_Template, 4, 3, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](37, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](38, PersonProfileDetailComponent_button_38_Template, 2, 1, "button", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](39, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](40, PersonProfileDetailComponent_button_40_Template, 2, 0, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](41, "div");
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.editable);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx.personEditForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx.data == null ? null : ctx.data.firstName)("readonly", !ctx.canEdit());
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx.data == null ? null : ctx.data.lastName)("readonly", !ctx.canEdit());
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx.data == null ? null : ctx.data.maidenName) != "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx.data == null ? null : ctx.data.gender)("disabled", !ctx.canEdit());
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.editable);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.data == null ? null : ctx.data.isDead);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.editable && (ctx.data == null ? null : ctx.data.yearOfDate));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.editable);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.editable);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.data == null ? null : ctx.data.isDead);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !(ctx.data == null ? null : ctx.data.isDead));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.canEdit());
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.canEdit());
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_6__["NgIf"], _angular_material_card__WEBPACK_IMPORTED_MODULE_7__["MatCardTitle"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__["MatIcon"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormGroupDirective"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatFormField"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatLabel"], _angular_material_input__WEBPACK_IMPORTED_MODULE_10__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], _angular_material_select__WEBPACK_IMPORTED_MODULE_11__["MatSelect"], _angular_material_core__WEBPACK_IMPORTED_MODULE_12__["MatOption"], _angular_material_button__WEBPACK_IMPORTED_MODULE_13__["MatButton"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_14__["MatCheckbox"]], styles: [".row[_ngcontent-%COMP%] {\r\n  display: flex;\r\n}\r\n  \r\n.column[_ngcontent-%COMP%] {\r\n  flex: 50%;\r\n}\r\n  \r\n.mat-select-disabled[_ngcontent-%COMP%]   .mat-select-value[_ngcontent-%COMP%] {\r\n  color: rgba(black, 0.38);\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9hcHAvY29tcG9uZW50cy9wZXJzb24tcHJvZmlsZS1kZXRhaWwtY29tcG9uZW50L3BlcnNvbi1wcm9maWxlLWRldGFpbC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBYTtBQUNmOztBQUVBO0VBQ0UsU0FBUztBQUNYOztBQUVBO0VBQ0Usd0JBQXdCO0FBQzFCIiwiZmlsZSI6Ii4uL3NyYy9hcHAvY29tcG9uZW50cy9wZXJzb24tcHJvZmlsZS1kZXRhaWwtY29tcG9uZW50L3BlcnNvbi1wcm9maWxlLWRldGFpbC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnJvdyB7XHJcbiAgZGlzcGxheTogZmxleDtcclxufVxyXG4gIFxyXG4uY29sdW1uIHtcclxuICBmbGV4OiA1MCU7XHJcbn1cclxuXHJcbi5tYXQtc2VsZWN0LWRpc2FibGVkIC5tYXQtc2VsZWN0LXZhbHVlIHtcclxuICBjb2xvcjogcmdiYShibGFjaywgMC4zOCk7XHJcbn0iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](PersonProfileDetailComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-person-profile-detail',
                templateUrl: './person-profile-detail.component.html',
                styleUrls: ['./person-profile-detail.component.css']
            }]
    }], function () { return [{ type: src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__["ConfigurationService"] }, { type: src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_2__["GraphQLService"] }, { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] }, { type: src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_4__["NotificationService"] }, { type: src_app_services_AuthenticationService__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"] }]; }, { id: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], data: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], privateData: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], editable: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();


/***/ }),

/***/ "./src/app/components/person-search-component/person-search.component.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/components/person-search-component/person-search.component.ts ***!
  \*******************************************************************************/
/*! exports provided: PersonSearchComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PersonSearchComponent", function() { return PersonSearchComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/_services/ConfigurationService */ "./src/app/_services/ConfigurationService.ts");
/* harmony import */ var src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/_services/GraphQLService */ "./src/app/_services/GraphQLService.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var src_app_services_ClientCacheService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/_services/ClientCacheService */ "./src/app/_services/ClientCacheService.ts");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
/* harmony import */ var _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/autocomplete */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/autocomplete.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/core */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/core.js");















function PersonSearchComponent_mat_option_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-option", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const option_r126 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", option_r126);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"](" ", option_r126.firstName, " ", option_r126.lastName, " ");
} }
class PersonSearchComponent {
    constructor(http, fb, configurationService, graphQLService, router, cacheService) {
        this.http = http;
        this.fb = fb;
        this.configurationService = configurationService;
        this.graphQLService = graphQLService;
        this.router = router;
        this.cacheService = cacheService;
        this.personChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.myControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]();
        this.options = [];
    }
    optionSelected(id) {
        this.personChanged.emit(id);
    }
    displayFn(user) {
        return user && user.firstName + ' ' + user.lastName;
    }
    getPersonList() {
        let cachedItems = this.cacheService.getPersonListFromCache();
        this.options = cachedItems.data;
        this.configurationService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQLService.getPersonList(endpoint, cachedItems.data.length, cachedItems.timestamp);
        })
            .then(res => {
            console.log(JSON.stringify(res));
            if (!res.isUpToDate) {
                this.options = res.users;
            }
        });
    }
    ngOnInit() {
        this.getPersonList();
        this.filteredOptions = this.myControl.valueChanges
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["startWith"])(''), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(value => typeof value === 'string' ? value : value.firstName), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(name => name ? this._filter(name) : this.options.slice()));
    }
    _filter(name) {
        const filterValue = name.toLowerCase();
        return this.options.filter(option => (option.firstName + ' ' + option.lastName).toLowerCase()
            .includes(filterValue));
    }
    ngAfterContentInit() {
    }
}
PersonSearchComponent.ɵfac = function PersonSearchComponent_Factory(t) { return new (t || PersonSearchComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_4__["ConfigurationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_5__["GraphQLService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_ClientCacheService__WEBPACK_IMPORTED_MODULE_7__["ClientCacheService"])); };
PersonSearchComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: PersonSearchComponent, selectors: [["app-person-search"]], outputs: { personChanged: "personChanged" }, decls: 10, vars: 10, consts: [[1, "example-form", 2, "display", "inline"], [1, "example-full-width"], ["type", "text", "matInput", "", 3, "formControl", "matAutocomplete"], [3, "displayWith", "optionSelected"], ["auto", "matAutocomplete"], [3, "value", 4, "ngFor", "ngForOf"], [3, "value"]], template: function PersonSearchComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "form", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-form-field", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Person");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "input", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mat-autocomplete", 3, 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("optionSelected", function PersonSearchComponent_Template_mat_autocomplete_optionSelected_5_listener($event) { return ctx.optionSelected($event.option.value); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, PersonSearchComponent_mat_option_7_Template, 2, 3, "mat-option", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](8, "slice");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](9, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r124 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formControl", ctx.myControl)("matAutocomplete", _r124);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("displayWith", ctx.displayFn);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind3"](8, 4, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](9, 8, ctx.filteredOptions), 0, 10));
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgForm"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_8__["MatFormField"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_8__["MatLabel"], _angular_material_input__WEBPACK_IMPORTED_MODULE_9__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["DefaultValueAccessor"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_10__["MatAutocompleteTrigger"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControlDirective"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_10__["MatAutocomplete"], _angular_common__WEBPACK_IMPORTED_MODULE_11__["NgForOf"], _angular_material_core__WEBPACK_IMPORTED_MODULE_12__["MatOption"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_11__["SlicePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_11__["AsyncPipe"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiIuLi9zcmMvYXBwL2NvbXBvbmVudHMvcGVyc29uLXNlYXJjaC1jb21wb25lbnQvcGVyc29uLXNlYXJjaC5jb21wb25lbnQuY3NzIn0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](PersonSearchComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-person-search',
                templateUrl: './person-search.component.html',
                styleUrls: ['./person-search.component.css']
            }]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }, { type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"] }, { type: src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_4__["ConfigurationService"] }, { type: src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_5__["GraphQLService"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] }, { type: src_app_services_ClientCacheService__WEBPACK_IMPORTED_MODULE_7__["ClientCacheService"] }]; }, { personChanged: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }] }); })();


/***/ }),

/***/ "./src/app/components/photo-component/photo.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/components/photo-component/photo.component.ts ***!
  \***************************************************************/
/*! exports provided: PhotoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PhotoComponent", function() { return PhotoComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/_services/ConfigurationService */ "./src/app/_services/ConfigurationService.ts");
/* harmony import */ var src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/_services/GraphQLService */ "./src/app/_services/GraphQLService.ts");
/* harmony import */ var src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/_services/NotificationService */ "./src/app/_services/NotificationService.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/card */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/card.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/icon.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
/* harmony import */ var _angular_material_chips__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/chips */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/chips.js");
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/tooltip */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/tooltip.js");
/* harmony import */ var _person_search_component_person_search_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../person-search-component/person-search.component */ "./src/app/components/person-search-component/person-search.component.ts");












function PhotoComponent_button_0_Template(rf, ctx) { if (rf & 1) {
    const _r82 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PhotoComponent_button_0_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r82); const ctx_r81 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r81.switchEdit(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "edit");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r73 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", ctx_r73.editMode ? "warn" : "primary");
} }
function PhotoComponent_span_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "(Click on photo to enlarge.)");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function PhotoComponent_span_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "No photos yet.");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function PhotoComponent_a_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r76 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("href", ctx_r76.photos[ctx_r76.photoIndex] == null ? null : ctx_r76.photos[ctx_r76.photoIndex].url, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx_r76.photos[ctx_r76.photoIndex] == null ? null : ctx_r76.photos[ctx_r76.photoIndex].url, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
} }
function PhotoComponent_div_11_button_8_Template(rf, ctx) { if (rf & 1) {
    const _r85 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PhotoComponent_div_11_button_8_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r85); const ctx_r84 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r84.setProfilePicture(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Set as Profile picture ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function PhotoComponent_div_11_Template(rf, ctx) { if (rf & 1) {
    const _r87 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PhotoComponent_div_11_Template_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r87); const ctx_r86 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r86.previous(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "skip_previous");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PhotoComponent_div_11_Template_button_click_5_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r87); const ctx_r88 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r88.next(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "skip_next");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, PhotoComponent_div_11_button_8_Template, 2, 0, "button", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r77 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"](" ", ctx_r77.photoIndex + 1, " / ", ctx_r77.photos == null ? null : ctx_r77.photos.length, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r77.photos[ctx_r77.photoIndex]._id != ctx_r77.profile);
} }
function PhotoComponent_mat_chip_list_12_mat_chip_2_button_2_Template(rf, ctx) { if (rf & 1) {
    const _r94 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PhotoComponent_mat_chip_list_12_mat_chip_2_button_2_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r94); const x_r90 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit; const ctx_r92 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r92.removeTag(x_r90._id, ctx_r92.photos[ctx_r92.photoIndex]._id); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "clear");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function PhotoComponent_mat_chip_list_12_mat_chip_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-chip");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, PhotoComponent_mat_chip_list_12_mat_chip_2_button_2_Template, 3, 0, "button", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const x_r90 = ctx.$implicit;
    const ctx_r89 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", x_r90.firstName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r89.editMode);
} }
function PhotoComponent_mat_chip_list_12_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-chip-list");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Tags: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, PhotoComponent_mat_chip_list_12_mat_chip_2_Template, 3, 2, "mat-chip", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r78 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r78.photos[ctx_r78.photoIndex].persons);
} }
function PhotoComponent_div_13_Template(rf, ctx) { if (rf & 1) {
    const _r96 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Add Tag: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "app-person-search", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("personChanged", function PhotoComponent_div_13_Template_app_person_search_personChanged_2_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r96); const ctx_r95 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r95.setLink($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PhotoComponent_div_13_Template_button_click_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r96); const ctx_r97 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r97.addTag(ctx_r97.linkId, ctx_r97.photos[ctx_r97.photoIndex]._id); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "link");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function PhotoComponent_div_14_button_2_Template(rf, ctx) { if (rf & 1) {
    const _r100 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PhotoComponent_div_14_button_2_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r100); const ctx_r99 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r99.deletePicture(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Delete photo ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function PhotoComponent_div_14_Template(rf, ctx) { if (rf & 1) {
    const _r102 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, PhotoComponent_div_14_button_2_Template, 2, 0, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "input", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function PhotoComponent_div_14_Template_input_change_4_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r102); const ctx_r101 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r101.changeListener($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PhotoComponent_div_14_Template_button_click_5_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r102); const ctx_r103 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r103.upload(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "cloud_upload");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r80 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx_r80.photos == null ? null : ctx_r80.photos.length) > 0);
} }
class PhotoComponent {
    constructor(configService, graphQlService, notification) {
        this.configService = configService;
        this.graphQlService = graphQlService;
        this.notification = notification;
        this.id = undefined;
        this.editable = false;
        this.editMode = false;
        this.photoIndex = 0;
        this.persons = [];
        this.edit = false;
    }
    switchEdit() {
        this.editMode = !this.editMode;
    }
    setLink(option) {
        this.linkId = option._id;
    }
    changeListener($event) {
        this.readThis($event.target);
    }
    readThis(inputValue) {
        const file = inputValue.files[0];
        this.image2 = file;
        const myReader = new FileReader();
        myReader.onloadend = (e) => {
            this.image = myReader.result;
        };
        myReader.readAsDataURL(file);
    }
    upload() {
        const myHeaders = new Headers();
        myHeaders.append('Authorization', 'Client-ID 7e2fbe3383eb5ed');
        const formdata = new FormData();
        formdata.append('image', this.image2);
        formdata.append('type', 'file');
        formdata.append('name', this.image2.name);
        const requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: formdata,
            redirect: 'follow'
        };
        fetch('https://api.imgur.com/3/image', requestOptions)
            .then(response => response.json())
            .then(result => {
            const link = result.data.link;
            const deletehash = result.data.deletehash;
            return this.configService.getApiEndpoint()
                .then(endpoint => {
                return this.graphQlService.addPhoto(endpoint, link, deletehash, [this.id]);
            });
        })
            .then(res => {
            this.notification.showSuccess('Photo added');
            window.location.reload();
        })
            .catch(error => {
            console.log(Error(error));
            this.notification.showError('Something went wrong. please check logs for details.');
        });
    }
    setProfilePicture() {
        const picture = this.photos[this.photoIndex]._id;
        const user = this.id;
        this.configService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQlService.setProfilePicture(endpoint, user, picture);
        })
            .catch(err => {
            this.notification.showError('Something went wrong. please check logs for detail.');
            console.log(err);
            throw Error(err);
        })
            .then(res => {
            this.notification.showSuccess('Profile picture changed.');
            window.location.reload();
        });
    }
    removeTag(tag, photo) {
        this.configService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQlService.removePhotoTag(endpoint, tag, photo);
        })
            .catch(err => {
            this.notification.showError('Something went wrong. please check logs for detail.');
            console.log(err);
            throw Error(err);
        })
            .then(res => {
            this.notification.showSuccess('Tag removed');
            window.location.reload();
        });
    }
    addTag(tag, photo) {
        if (tag.length < 12) {
            this.notification.showError('Id should be valid');
            return;
        }
        this.configService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQlService.addPhotoTag(endpoint, tag, photo);
        })
            .catch(err => {
            this.notification.showError('Something went wrong. please check logs for detail.');
            console.log(err);
            throw Error(err);
        })
            .then(res => {
            this.notification.showSuccess('Tag added');
            this.linkId = '';
            window.location.reload();
        });
    }
    next() {
        if (this.photoIndex < this.photos.length - 1) {
            this.photoIndex++;
        }
    }
    previous() {
        if (this.photoIndex > 0) {
            this.photoIndex--;
        }
    }
    ngOnInit() {
    }
    ngOnChanges() {
        this.getProfileImage(this.id);
        this.getPhotos(this.id);
    }
    deletePicture() {
        const picture = this.photos[this.photoIndex]._id;
        this.configService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQlService.deletePhoto(endpoint, picture);
        })
            .catch(err => {
            this.notification.showError('Something went wrong. please check logs for detail.');
            console.log(err);
            throw Error(err);
        })
            .then(res => {
            this.notification.showSuccess('Photo deleted.');
            window.location.reload();
        });
    }
    getProfileImage(id) {
        this.configService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQlService.getProfilePhoto(endpoint, id);
        })
            .then(data => {
            var _a;
            this.profile = (_a = data) === null || _a === void 0 ? void 0 : _a._id;
        });
    }
    getPhotos(id) {
        this.configService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQlService.getProfile(endpoint, id);
        })
            .then(data => {
            this.photos = data.photos;
        });
    }
}
PhotoComponent.ɵfac = function PhotoComponent_Factory(t) { return new (t || PhotoComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__["ConfigurationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_2__["GraphQLService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_3__["NotificationService"])); };
PhotoComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: PhotoComponent, selectors: [["app-photo"]], inputs: { id: "id", editable: "editable", photos: "photos" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]], decls: 15, vars: 8, consts: [["mat-icon-button", "", "style", "float: right;", 3, "color", "click", 4, "ngIf"], ["style", "margin-left:20px", 4, "ngIf"], ["target", "_blank", 3, "href", 4, "ngIf"], [4, "ngIf"], ["mat-icon-button", "", 2, "float", "right", 3, "color", "click"], [2, "margin-left", "20px"], ["target", "_blank", 3, "href"], ["width", "380", 3, "src"], ["mat-icon-button", "", "aria-label", "Previous", 3, "click"], ["mat-icon-button", "", "aria-label", "Next", 3, "click"], ["mat-icon-button", "", "aria-label", "Next", 3, "click", 4, "ngIf"], [4, "ngFor", "ngForOf"], ["mat-icon-button", "", "color", "primary", "matTooltip", "delete tag", 3, "click", 4, "ngIf"], ["mat-icon-button", "", "color", "primary", "matTooltip", "delete tag", 3, "click"], [3, "personChanged"], ["mat-icon-button", "", "color", "primary", "matTooltip", "add tag", 3, "click"], ["mat-icon-button", "", "color", "warn", "aria-label", "Delete", 3, "click", 4, "ngIf"], ["type", "file", "accept", "image/*", 3, "change"], ["mat-icon-button", "", "aria-label", "upload", 3, "click"], ["mat-icon-button", "", "color", "warn", "aria-label", "Delete", 3, "click"]], template: function PhotoComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, PhotoComponent_button_0_Template, 3, 1, "button", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Photo Gallery");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "camera_alt");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, PhotoComponent_span_6_Template, 2, 0, "span", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, PhotoComponent_span_7_Template, 2, 0, "span", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, PhotoComponent_a_9_Template, 2, 2, "a", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](11, PhotoComponent_div_11_Template, 9, 3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](12, PhotoComponent_mat_chip_list_12_Template, 3, 1, "mat-chip-list", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](13, PhotoComponent_div_13_Template, 6, 0, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](14, PhotoComponent_div_14_Template, 8, 1, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.editable);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx.photos == null ? null : ctx.photos.length) > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx.photos == null ? null : ctx.photos.length) == 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx.photos == null ? null : ctx.photos.length) > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx.photos == null ? null : ctx.photos.length) > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx.photos == null ? null : ctx.photos.length) > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx.photos == null ? null : ctx.photos.length) > 0 && ctx.editMode);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.editMode);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["NgIf"], _angular_material_card__WEBPACK_IMPORTED_MODULE_5__["MatCardTitle"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__["MatIcon"], _angular_material_button__WEBPACK_IMPORTED_MODULE_7__["MatButton"], _angular_material_chips__WEBPACK_IMPORTED_MODULE_8__["MatChipList"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgForOf"], _angular_material_chips__WEBPACK_IMPORTED_MODULE_8__["MatChip"], _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_9__["MatTooltip"], _person_search_component_person_search_component__WEBPACK_IMPORTED_MODULE_10__["PersonSearchComponent"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiIuLi9zcmMvYXBwL2NvbXBvbmVudHMvcGhvdG8tY29tcG9uZW50L3Bob3RvLmNvbXBvbmVudC5jc3MifQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](PhotoComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-photo',
                templateUrl: './photo.component.html',
                styleUrls: ['./photo.component.css']
            }]
    }], function () { return [{ type: src_app_services_ConfigurationService__WEBPACK_IMPORTED_MODULE_1__["ConfigurationService"] }, { type: src_app_services_GraphQLService__WEBPACK_IMPORTED_MODULE_2__["GraphQLService"] }, { type: src_app_services_NotificationService__WEBPACK_IMPORTED_MODULE_3__["NotificationService"] }]; }, { id: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], editable: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], photos: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();


/***/ }),

/***/ "./src/app/components/share-component/share.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/components/share-component/share.component.ts ***!
  \***************************************************************/
/*! exports provided: BottomSheetOverviewExampleSheet */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BottomSheetOverviewExampleSheet", function() { return BottomSheetOverviewExampleSheet; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/bottom-sheet */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/bottom-sheet.js");



class BottomSheetOverviewExampleSheet {
    constructor(_bottomSheetRef) {
        this._bottomSheetRef = _bottomSheetRef;
    }
    openLink(event) {
        this._bottomSheetRef.dismiss();
        event.preventDefault();
    }
}
BottomSheetOverviewExampleSheet.ɵfac = function BottomSheetOverviewExampleSheet_Factory(t) { return new (t || BottomSheetOverviewExampleSheet)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_1__["MatBottomSheetRef"])); };
BottomSheetOverviewExampleSheet.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: BottomSheetOverviewExampleSheet, selectors: [["bottom-sheet-overview-example-sheet"]], decls: 1, vars: 0, template: function BottomSheetOverviewExampleSheet_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](0, " a test");
    } }, encapsulation: 2 });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BottomSheetOverviewExampleSheet, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'bottom-sheet-overview-example-sheet',
                templateUrl: 'bottom-sheet-overview-example-sheet.html',
            }]
    }], function () { return [{ type: _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_1__["MatBottomSheetRef"] }]; }, null); })();


/***/ }),

/***/ "./src/app/components/tree-component/tree.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/components/tree-component/tree.component.ts ***!
  \*************************************************************/
/*! exports provided: TreeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TreeComponent", function() { return TreeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var d3__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! d3 */ "./node_modules/d3/index.js");
/* harmony import */ var _treeDraw__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../treeDraw */ "./src/app/treeDraw.ts");
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/card */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/card.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/icon.js");






class TreeComponent {
    constructor() {
        this.data = {};
    }
    ngOnInit() {
    }
    ngAfterContentInit() {
        let svg = d3__WEBPACK_IMPORTED_MODULE_1__["select"]('.familyTree');
        new _treeDraw__WEBPACK_IMPORTED_MODULE_2__["TreeDraw"]().draw(svg, this.data);
    }
    openShareSheet() {
    }
}
TreeComponent.ɵfac = function TreeComponent_Factory(t) { return new (t || TreeComponent)(); };
TreeComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: TreeComponent, selectors: [["app-tree"]], inputs: { data: "data" }, decls: 10, vars: 0, consts: [[2, "margin-left", "20px"], [1, "familyTree"]], template: function TreeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Family Tree ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "mat-icon");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "dashboard");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "span", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "(Click on family members to view details.)");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "svg", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, directives: [_angular_material_card__WEBPACK_IMPORTED_MODULE_3__["MatCardTitle"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_4__["MatIcon"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiIuLi9zcmMvYXBwL2NvbXBvbmVudHMvdHJlZS1jb21wb25lbnQvdHJlZS5jb21wb25lbnQuY3NzIn0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](TreeComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-tree',
                templateUrl: './tree.component.html',
                styleUrls: ['./tree.component.css']
            }]
    }], function () { return []; }, { data: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"],
            args: ['data']
        }] }); })();


/***/ }),

/***/ "./src/app/data/cache/personList.json":
/*!********************************************!*\
  !*** ./src/app/data/cache/personList.json ***!
  \********************************************/
/*! exports provided: data, timestamp, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"data\":[{\"_id\":\"5e6556437af677179baf2ed2\",\"firstName\":\"Elizabeth\",\"lastName\":\"Anthonypillai\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ed2\"},{\"_id\":\"5e6556437af677179baf2ed1\",\"firstName\":\"Soosaipillai\",\"lastName\":\"Anthonypillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ed1\"},{\"_id\":\"5e6556427af677179baf2e60\",\"firstName\":\"Angeline Swinitha\",\"lastName\":\"Arulraj\",\"maidenName\":\"Manuelpillai\",\"gender\":\"Female\",\"yearOfBirth\":\"1951\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e60\"},{\"_id\":\"5e6556427af677179baf2e6b\",\"firstName\":\"Brintha\",\"lastName\":\"Arulraj\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1987\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e6b\"},{\"_id\":\"5e6556427af677179baf2e6a\",\"firstName\":\"Rajeev\",\"lastName\":\"Arulraj\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1982\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e6a\"},{\"_id\":\"5e6556427af677179baf2e6c\",\"firstName\":\"Sanjeev\",\"lastName\":\"Arulraj\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1984\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e6c\"},{\"_id\":\"5e6556437af677179baf2ecb\",\"firstName\":\"Jesuthasan\",\"lastName\":\"Augustine Mariampillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ecb\"},{\"_id\":\"5e6556427af677179baf2ea2\",\"firstName\":\"Jonathan\",\"lastName\":\"Balendran\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":null,\"yearOfDeath\":\"1970\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ea2\"},{\"_id\":\"5e6556427af677179baf2ea0\",\"firstName\":\"Kayasin\",\"lastName\":\"Balendran\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1965\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ea0\"},{\"_id\":\"5e6556427af677179baf2ea3\",\"firstName\":\"Keetha\",\"lastName\":\"Balendran\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1970\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ea3\"},{\"_id\":\"5e6556427af677179baf2e9f\",\"firstName\":\"Meera\",\"lastName\":\"Balendran\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1960\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e9f\"},{\"_id\":\"5e6556427af677179baf2ea1\",\"firstName\":\"Neela\",\"lastName\":\"Balendran\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1970\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ea1\"},{\"_id\":\"5e6556427af677179baf2eae\",\"firstName\":\"Manuelpillai\",\"lastName\":\"Bastiampillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1970\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eae\"},{\"_id\":\"5e6556427af677179baf2eb0\",\"firstName\":\"Mariampillai\",\"lastName\":\"Bastiampillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1970\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eb0\"},{\"_id\":\"5e6556427af677179baf2eac\",\"firstName\":\"Saverimuthu\",\"lastName\":\"Bastiampillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1970\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eac\"},{\"_id\":\"5e6556427af677179baf2eb3\",\"firstName\":\"Thambyrajah\",\"lastName\":\"Bastiampillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1940\",\"yearOfDeath\":\"1960\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eb3\"},{\"_id\":\"5e6556427af677179baf2eaf\",\"firstName\":\"Thangammah\",\"lastName\":\"Bastiampillai\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1970\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eaf\"},{\"_id\":\"5e6556427af677179baf2ead\",\"firstName\":\"Victoria Muthu\",\"lastName\":\"Bastiampillai\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1970\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ead\"},{\"_id\":\"5e6556427af677179baf2eb4\",\"firstName\":\"Xavier Bastian\",\"lastName\":\"Bastiampillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1950\",\"yearOfDeath\":\"1970\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eb4\"},{\"_id\":\"5e6556437af677179baf2ec3\",\"firstName\":\"Rosammah\",\"lastName\":\"Chelliah\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ec3\"},{\"_id\":\"5e6556437af677179baf2ec6\",\"firstName\":\"Rohan\",\"lastName\":\"Felix\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ec6\"},{\"_id\":\"5e6556437af677179baf2ec8\",\"firstName\":\"Benedict\",\"lastName\":\"Fernandopillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ec8\"},{\"_id\":\"5e6556427af677179baf2e61\",\"firstName\":\"Manuelpillai Stephen\",\"lastName\":\"Gabrielpillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1921\",\"yearOfDeath\":\"1993\",\"isDead\":true,\"profileId\":\"5e6556427af677179baf2e61\"},{\"_id\":\"5e6556427af677179baf2e64\",\"firstName\":\"Margaret\",\"lastName\":\"Gabrielpillai\",\"maidenName\":\"Mariampilla\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e64\"},{\"_id\":\"5e6556437af677179baf2ec5\",\"firstName\":\"Violet\",\"lastName\":\"Gabrielpillai\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ec5\"},{\"_id\":\"5ebc7695df64a80017c4c621\",\"firstName\":\"Nicolas\",\"lastName\":\"Gruselle\",\"maidenName\":null,\"gender\":\"Male\",\"yearOfBirth\":null,\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5ebc7695df64a80017c4c621\"},{\"_id\":\"5e6556427af677179baf2e76\",\"firstName\":\"Carmaline\",\"lastName\":\"Jesuthasan\",\"maidenName\":\"Manuelpillai\",\"gender\":\"Female\",\"yearOfBirth\":\"1965\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e76\"},{\"_id\":\"5e6556427af677179baf2e79\",\"firstName\":\"Juliana\",\"lastName\":\"Jesuthasan\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1996\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e79\"},{\"_id\":\"5ebc5a9fdf64a80017c4c5ab\",\"firstName\":\"Noel\",\"lastName\":\"Jesuthasan\",\"maidenName\":null,\"gender\":\"Male\",\"yearOfBirth\":null,\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5ebc5a9fdf64a80017c4c5ab\"},{\"_id\":\"5e6556427af677179baf2e78\",\"firstName\":\"Sabrina\",\"lastName\":\"Jesuthasan\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1994\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e78\"},{\"_id\":\"5ebc5ce0df64a80017c4c5be\",\"firstName\":\"Daria\",\"lastName\":\"Joseph\",\"maidenName\":null,\"gender\":\"Female\",\"yearOfBirth\":\"1987\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5ebc5ce0df64a80017c4c5be\"},{\"_id\":\"5ebc612fdf64a80017c4c5d2\",\"firstName\":\"Gavin\",\"lastName\":\"Joseph\",\"maidenName\":null,\"gender\":\"Male\",\"yearOfBirth\":\"2018\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5ebc612fdf64a80017c4c5d2\"},{\"_id\":\"5e6556427af677179baf2e92\",\"firstName\":\"Mahalwathy\",\"lastName\":\"Joseph\",\"maidenName\":\"Philips\",\"gender\":\"Female\",\"yearOfBirth\":\"1929\",\"yearOfDeath\":\"1977\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e92\"},{\"_id\":\"5e6556427af677179baf2e81\",\"firstName\":\"Ahalya\",\"lastName\":\"Kandasamy\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1989\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e81\"},{\"_id\":\"5e6556427af677179baf2e82\",\"firstName\":\"Arun\",\"lastName\":\"Kandasamy\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1992\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e82\"},{\"_id\":\"5e6556427af677179baf2e83\",\"firstName\":\"Ashvia\",\"lastName\":\"Kandasamy\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1995\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e83\"},{\"_id\":\"5e6556427af677179baf2e97\",\"firstName\":\"Balendran\",\"lastName\":\"Kulasegaram\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1960\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e97\"},{\"_id\":\"5e6556427af677179baf2e99\",\"firstName\":\"Nanthan\",\"lastName\":\"Kulasegaram\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1968\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e99\"},{\"_id\":\"5e6556427af677179baf2e8c\",\"firstName\":\"Pakiam\",\"lastName\":\"Kulasegaram\",\"maidenName\":\"Manickam\",\"gender\":\"Female\",\"yearOfBirth\":\"1940\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e8c\"},{\"_id\":\"5e6556427af677179baf2e98\",\"firstName\":\"Ravi\",\"lastName\":\"Kulasegaram\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1970\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e98\"},{\"_id\":\"5e6556427af677179baf2e7d\",\"firstName\":\"Choi Yuk\",\"lastName\":\"Lam\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1959\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e7d\"},{\"_id\":\"5ebc5f2fdf64a80017c4c5cb\",\"firstName\":\"Mathan\",\"lastName\":\"Mahalingam\",\"maidenName\":null,\"gender\":\"Male\",\"yearOfBirth\":\"1983\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5ebc5f2fdf64a80017c4c5cb\"},{\"_id\":\"5e6556427af677179baf2e80\",\"firstName\":\"Kandasamy\",\"lastName\":\"Manickam\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1952\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e80\"},{\"_id\":\"5e6556427af677179baf2e8e\",\"firstName\":\"Patmanathan\",\"lastName\":\"Manickam\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1945\",\"yearOfDeath\":\"2018\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e8e\"},{\"_id\":\"5e6556427af677179baf2e8a\",\"firstName\":\"Puspamalar\",\"lastName\":\"Manickam\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1946\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e8a\"},{\"_id\":\"5e6556427af677179baf2e96\",\"firstName\":\"Vallipillai\",\"lastName\":\"Manickam\",\"maidenName\":\"t\",\"gender\":\"Female\",\"yearOfBirth\":\"1920\",\"yearOfDeath\":\"2000\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e96\"},{\"_id\":\"5e6556427af677179baf2e95\",\"firstName\":\"Vallipillai\",\"lastName\":\"Manickam\",\"maidenName\":\"Thaivanapillai\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"2002\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e95\"},{\"_id\":\"5e6556427af677179baf2e9b\",\"firstName\":\"Anna Jeywathy\",\"lastName\":\"Manuelpillai\",\"maidenName\":\"Phillips\",\"gender\":\"Female\",\"yearOfBirth\":\"1927\",\"yearOfDeath\":\"2017\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e9b\"},{\"_id\":\"5e6556427af677179baf2e9d\",\"firstName\":\"Anutha\",\"lastName\":\"Manuelpillai\",\"maidenName\":\"Balendran\",\"gender\":\"Female\",\"yearOfBirth\":\"1975\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e9d\"},{\"_id\":\"5e6556427af677179baf2e72\",\"firstName\":\"Bernard\",\"lastName\":\"Manuelpillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1956\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e72\"},{\"_id\":\"5e6556427af677179baf2e7a\",\"firstName\":\"Bianca\",\"lastName\":\"Manuelpillai\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"2000\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e7a\"},{\"_id\":\"5e6556427af677179baf2e5d\",\"firstName\":\"Denisia\",\"lastName\":\"Manuelpillai\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1993\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e5d\"},{\"_id\":\"5e6556427af677179baf2e73\",\"firstName\":\"Finton\",\"lastName\":\"Manuelpillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1959\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e73\"},{\"_id\":\"5e6556427af677179baf2e5f\",\"firstName\":\"Gabriel\",\"lastName\":\"Manuelpillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"2019\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e5f\"},{\"_id\":\"5e6556427af677179baf2e7b\",\"firstName\":\"Gianna\",\"lastName\":\"Manuelpillai\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"2000\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e7b\"},{\"_id\":\"5e6556427af677179baf2e74\",\"firstName\":\"Jean Donest\",\"lastName\":\"Manuelpillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1995\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e74\"},{\"_id\":\"5e6556427af677179baf2e75\",\"firstName\":\"Jerrine\",\"lastName\":\"Manuelpillai\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1993\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e75\"},{\"_id\":\"5e6556427af677179baf2e5b\",\"firstName\":\"Joseph Gaston\",\"lastName\":\"Manuelpillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1950\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"ranjan\"},{\"_id\":\"5e6556427af677179baf2e77\",\"firstName\":\"Julian\",\"lastName\":\"Manuelpillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1970\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e77\"},{\"_id\":\"5e6556427af677179baf2e5c\",\"firstName\":\"Maheswary\",\"lastName\":\"Manuelpillai\",\"maidenName\":\"Manickam\",\"gender\":\"Female\",\"yearOfBirth\":\"1949\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e5c\"},{\"_id\":\"5e6556427af677179baf2e8d\",\"firstName\":\"Malar\",\"lastName\":\"Manuelpillai\",\"maidenName\":\"Kulasegaram\",\"gender\":\"Female\",\"yearOfBirth\":\"1960\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e8d\"},{\"_id\":\"5e6556427af677179baf2ec0\",\"firstName\":\"Peterpillai\",\"lastName\":\"Manuelpillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ec0\"},{\"_id\":\"5e6556427af677179baf2e67\",\"firstName\":\"Augustine Rajadurai\",\"lastName\":\"Mariampilla\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e67\"},{\"_id\":\"5e6556427af677179baf2e68\",\"firstName\":\"Seraphina\",\"lastName\":\"Mariampilla\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e68\"},{\"_id\":\"5e6556427af677179baf2eb7\",\"firstName\":\"Ariyam\",\"lastName\":\"Mariampillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eb7\"},{\"_id\":\"5e6556427af677179baf2ebd\",\"firstName\":\"Ferdinand\",\"lastName\":\"Mariampillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ebd\"},{\"_id\":\"5e6556427af677179baf2ebc\",\"firstName\":\"Joseph Baba\",\"lastName\":\"Mariampillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ebc\"},{\"_id\":\"5e6556437af677179baf2ece\",\"firstName\":\"Lourdes\",\"lastName\":\"Mariampillai\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ece\"},{\"_id\":\"5e6556427af677179baf2ebe\",\"firstName\":\"Pius Emmanuel\",\"lastName\":\"Mariampillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1940\",\"yearOfDeath\":\"2011\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ebe\"},{\"_id\":\"5e6556427af677179baf2eba\",\"firstName\":\"Satkunam\",\"lastName\":\"Mariampillai\",\"maidenName\":\"Saverimuthu\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eba\"},{\"_id\":\"5e6556437af677179baf2ed3\",\"firstName\":\"Seenier\",\"lastName\":\"Mariampillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ed3\"},{\"_id\":\"5e6556427af677179baf2e65\",\"firstName\":\"Sellachchi\",\"lastName\":\"Mariampillai\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1880\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e65\"},{\"_id\":\"5ebc660bdf64a80017c4c5e4\",\"firstName\":\"Amelia\",\"lastName\":\"Mathan\",\"maidenName\":null,\"gender\":\"Female\",\"yearOfBirth\":\"2012\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5ebc660bdf64a80017c4c5e4\"},{\"_id\":\"5ebc661edf64a80017c4c5e9\",\"firstName\":\"Liam\",\"lastName\":\"Mathan\",\"maidenName\":null,\"gender\":\"Male\",\"yearOfBirth\":\"2018\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5ebc661edf64a80017c4c5e9\"},{\"_id\":\"5e6556427af677179baf2ebb\",\"firstName\":\"Mariampillai\",\"lastName\":\"Muthurasa\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ebb\"},{\"_id\":\"5e6556427af677179baf2eb9\",\"firstName\":\"Rajendram Benedict\",\"lastName\":\"Nicholapillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eb9\"},{\"_id\":\"5e6556427af677179baf2ebf\",\"firstName\":\"Grace\",\"lastName\":\"Peterpillai\",\"maidenName\":\"Saverimuthu\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ebf\"},{\"_id\":\"5e6556427af677179baf2ec1\",\"firstName\":\"Justin Stanyslaus\",\"lastName\":\"Peterpillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ec1\"},{\"_id\":\"5e6556427af677179baf2e91\",\"firstName\":\"Narendra\",\"lastName\":\"Philips\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1925\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e91\"},{\"_id\":\"5e6556427af677179baf2e90\",\"firstName\":\"Rajendra\",\"lastName\":\"Philips\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1920\",\"yearOfDeath\":\"2017\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e90\"},{\"_id\":\"5e6556427af677179baf2e94\",\"firstName\":\"Yohendra\",\"lastName\":\"Philips\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1943\",\"yearOfDeath\":\"2004\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e94\"},{\"_id\":\"5e6556427af677179baf2e9c\",\"firstName\":\"Balendra\",\"lastName\":\"Phillips\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1933\",\"yearOfDeath\":\"2020\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e9c\"},{\"_id\":\"5e6556427af677179baf2e8f\",\"firstName\":\"Sabina\",\"lastName\":\"Phillips\",\"maidenName\":\"Philips\",\"gender\":\"Female\",\"yearOfBirth\":\"1901\",\"yearOfDeath\":\"1988\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e8f\"},{\"_id\":\"5e6556427af677179baf2e9e\",\"firstName\":\"Savarimuthu\",\"lastName\":\"Phillips\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1887\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e9e\"},{\"_id\":\"5e6556437af677179baf2eca\",\"firstName\":\"Augustine\",\"lastName\":\"Rajadurai Mariampillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2eca\"},{\"_id\":\"5e6556427af677179baf2eb5\",\"firstName\":\"Unknown\",\"lastName\":\"Rajadurai\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eb5\"},{\"_id\":\"5e6556427af677179baf2e93\",\"firstName\":\"Paulwathy\",\"lastName\":\"Rajasingam\",\"maidenName\":\"Philips\",\"gender\":\"Female\",\"yearOfBirth\":\"1929\",\"yearOfDeath\":\"1984\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e93\"},{\"_id\":\"5e6556427af677179baf2e66\",\"firstName\":\"Mariampillai\",\"lastName\":\"Rasiah\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1880\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e66\"},{\"_id\":\"5ebc7082df64a80017c4c60c\",\"firstName\":\"Thayalini\",\"lastName\":\"Ruben\",\"maidenName\":null,\"gender\":null,\"yearOfBirth\":null,\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5ebc7082df64a80017c4c60c\"},{\"_id\":\"5e6556427af677179baf2e62\",\"firstName\":\"Manickam\",\"lastName\":\"Sangarapillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":null,\"yearOfDeath\":\"2005\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e62\"},{\"_id\":\"5e6556427af677179baf2ec2\",\"firstName\":\"Bastiampillai\",\"lastName\":\"Saverimuthu\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ec2\"},{\"_id\":\"5e6556437af677179baf2ec4\",\"firstName\":\"Felix Ponraja\",\"lastName\":\"Saverimuthu\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ec4\"},{\"_id\":\"5e6556437af677179baf2ec9\",\"firstName\":\"Lourdes Selvam\",\"lastName\":\"Saverimuthu\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ec9\"},{\"_id\":\"5e6556437af677179baf2ec7\",\"firstName\":\"Unis\",\"lastName\":\"Saverimuthu\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ec7\"},{\"_id\":\"5e6556437af677179baf2ecd\",\"firstName\":\"Thambayah\",\"lastName\":\"Seemampillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ecd\"},{\"_id\":\"5ec68d6966db3f2a946ce8ce\",\"firstName\":\"Kylian\",\"lastName\":\"Sivanadan\",\"maidenName\":null,\"gender\":\"Male\",\"yearOfBirth\":null,\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5ec68d6966db3f2a946ce8ce\"},{\"_id\":\"5e6556427af677179baf2e84\",\"firstName\":\"Atpiuthamalar\",\"lastName\":\"Sivanandan\",\"maidenName\":\"Manickam\",\"gender\":\"Female\",\"yearOfBirth\":\"1954\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e84\"},{\"_id\":\"5e6556427af677179baf2e89\",\"firstName\":\"Damian\",\"lastName\":\"Sivanandan\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1995\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e89\"},{\"_id\":\"5e6556427af677179baf2e85\",\"firstName\":\"Delan\",\"lastName\":\"Sivanandan\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1985\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e85\"},{\"_id\":\"5e6556427af677179baf2e86\",\"firstName\":\"Delphinei\",\"lastName\":\"Sivanandan\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1989\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e86\"},{\"_id\":\"5e6556427af677179baf2e88\",\"firstName\":\"Dismine\",\"lastName\":\"Sivanandan\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1992\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e88\"},{\"_id\":\"5e6556427af677179baf2e87\",\"firstName\":\"Donex\",\"lastName\":\"Sivanandan\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1991\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e87\"},{\"_id\":\"5ec68d8566db3f2a946ce8d3\",\"firstName\":\"kaylan\",\"lastName\":\"Sivandan\",\"maidenName\":null,\"gender\":\"Male\",\"yearOfBirth\":null,\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5ec68d8566db3f2a946ce8d3\"},{\"_id\":\"5e6556427af677179baf2e70\",\"firstName\":\"Andrew\",\"lastName\":\"Soosaipillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1982\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e70\"},{\"_id\":\"5e6556427af677179baf2e71\",\"firstName\":\"Caroline\",\"lastName\":\"Soosaipillai\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1985\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e71\"},{\"_id\":\"5ebc6f78df64a80017c4c5fc\",\"firstName\":\"Elena\",\"lastName\":\"Soosaipillai\",\"maidenName\":null,\"gender\":\"Female\",\"yearOfBirth\":\"2019\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5ebc6f78df64a80017c4c5fc\"},{\"_id\":\"5e6556427af677179baf2e6e\",\"firstName\":\"Emanuel\",\"lastName\":\"Soosaipillai\",\"maidenName\":\"Soosaipilla\",\"gender\":\"Male\",\"yearOfBirth\":\"1950\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e6e\"},{\"_id\":\"5ebc6fabdf64a80017c4c603\",\"firstName\":\"Joshua\",\"lastName\":\"Soosaipillai\",\"maidenName\":null,\"gender\":null,\"yearOfBirth\":null,\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5ebc6fabdf64a80017c4c603\"},{\"_id\":\"5ebc6ffedf64a80017c4c605\",\"firstName\":\"Joshua\",\"lastName\":\"Soosaipillai\",\"maidenName\":null,\"gender\":\"Male\",\"yearOfBirth\":null,\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5ebc6ffedf64a80017c4c605\"},{\"_id\":\"5e6556427af677179baf2e6d\",\"firstName\":\"Noeline\",\"lastName\":\"Soosaipillai\",\"maidenName\":\"Manuelpillai\",\"gender\":\"Female\",\"yearOfBirth\":\"1953\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e6d\"},{\"_id\":\"5e6556427af677179baf2e6f\",\"firstName\":\"Ruben\",\"lastName\":\"Soosaipillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1981\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e6f\"},{\"_id\":\"5e6556427af677179baf2eb8\",\"firstName\":\"Beatrice Lily Theresa\",\"lastName\":\"Thambirajah\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eb8\"},{\"_id\":\"5e6556427af677179baf2eb6\",\"firstName\":\"Unknown\",\"lastName\":\"Thambirajah\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eb6\"},{\"_id\":\"5e6556427af677179baf2eb2\",\"firstName\":\"Daisy\",\"lastName\":\"Thambyrajah\",\"maidenName\":\"Saverimuthu\",\"gender\":\"Female\",\"yearOfBirth\":\"1940\",\"yearOfDeath\":\"1960\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eb2\"},{\"_id\":\"5e6556427af677179baf2eaa\",\"firstName\":\"Bastiampillai\",\"lastName\":\"Thaveethupillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1860\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eaa\"},{\"_id\":\"5e6556427af677179baf2ea4\",\"firstName\":\"Kamalarajan\",\"lastName\":\"Thiagarajah\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1970\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ea4\"},{\"_id\":\"5e6556427af677179baf2e8b\",\"firstName\":\"Patmavathi\",\"lastName\":\"Thiagarajah\",\"maidenName\":\"Manickam\",\"gender\":\"Female\",\"yearOfBirth\":\"1941\",\"yearOfDeath\":\"2019\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e8b\"},{\"_id\":\"5e6556427af677179baf2ea6\",\"firstName\":\"Puvanarajan\",\"lastName\":\"Thiagarajah\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1970\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ea6\"},{\"_id\":\"5e6556427af677179baf2ea5\",\"firstName\":\"Rohini\",\"lastName\":\"Thiagarajah\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1970\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ea5\"},{\"_id\":\"5e6556427af677179baf2ea9\",\"firstName\":\"Nalahini\",\"lastName\":\"Thiyagarajah\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1970\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ea9\"},{\"_id\":\"5e6556427af677179baf2ea8\",\"firstName\":\"Nalini\",\"lastName\":\"Thiyagarajah\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1970\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ea8\"},{\"_id\":\"5e6556427af677179baf2e9a\",\"firstName\":\"Varatharasan\",\"lastName\":\"Thiyagarajah\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1965\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e9a\"},{\"_id\":\"5e6556437af677179baf2ed0\",\"firstName\":\"Anthonypillai\",\"lastName\":\"Unknow\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ed0\"},{\"_id\":\"5e6556437af677179baf2ecf\",\"firstName\":\"Gnanamuthu\",\"lastName\":\"Unknow\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ecf\"},{\"_id\":\"5e6556437af677179baf2ed4\",\"firstName\":\"Anasia\",\"lastName\":\"Unknown\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ed4\"},{\"_id\":\"5e6556427af677179baf2eb1\",\"firstName\":\"Annamah\",\"lastName\":\"Unknown\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1930\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eb1\"},{\"_id\":\"5e6556427af677179baf2e69\",\"firstName\":\"Arulraj\",\"lastName\":\"Unknown\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":null,\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e69\"},{\"_id\":\"5e6556427af677179baf2e63\",\"firstName\":\"Gabrielpillai\",\"lastName\":\"Unknown\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":null,\"yearOfDeath\":\"1926\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e63\"},{\"_id\":\"5e6556437af677179baf2ecc\",\"firstName\":\"Phillipupillai\",\"lastName\":\"Unknown\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1900\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556437af677179baf2ecc\"},{\"_id\":\"5e6556427af677179baf2ea7\",\"firstName\":\"Thiyagarajah\",\"lastName\":\"Unknown\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1940\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2ea7\"},{\"_id\":\"5e6556427af677179baf2e7c\",\"firstName\":\"Kam\",\"lastName\":\"Wong\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1951\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e7c\"},{\"_id\":\"5e6556427af677179baf2e7e\",\"firstName\":\"Tsan King\",\"lastName\":\"Wong\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1983\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e7e\"},{\"_id\":\"5e6556427af677179baf2e7f\",\"firstName\":\"Tsan Lam\",\"lastName\":\"Wong\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1984\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e7f\"},{\"_id\":\"5e6556427af677179baf2e5e\",\"firstName\":\"Yu Ling\",\"lastName\":\"Wong\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1989\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"5e6556427af677179baf2e5e\"},{\"_id\":\"5e6556427af677179baf2e5a\",\"firstName\":\"daniel\",\"lastName\":\"manuelpillai\",\"maidenName\":\"\",\"gender\":\"Male\",\"yearOfBirth\":\"1983\",\"yearOfDeath\":null,\"isDead\":false,\"profileId\":\"daniel.manuelpillai\"},{\"_id\":\"5e6556427af677179baf2eab\",\"firstName\":\"Ustina\",\"lastName\":\"x\",\"maidenName\":\"\",\"gender\":\"Female\",\"yearOfBirth\":\"1860\",\"yearOfDeath\":\"1900\",\"isDead\":false,\"profileId\":\"5e6556427af677179baf2eab\"}],\"timestamp\":\"2020-05-27T07:42:12.695Z\"}");

/***/ }),

/***/ "./src/app/data/cache/randomPhotos.json":
/*!**********************************************!*\
  !*** ./src/app/data/cache/randomPhotos.json ***!
  \**********************************************/
/*! exports provided: 0, 1, 2, 3, 4, default */
/***/ (function(module) {

module.exports = JSON.parse("[{\"_id\":\"5ebd501847c86f320cb56eba\",\"url\":\"https://i.imgur.com/pWeWIu7.jpg\"},{\"_id\":\"5ebd77e947c86f320cb56ebc\",\"url\":\"https://i.imgur.com/JQjU6fR.jpg\"},{\"_id\":\"5ec0ff345f054e001796ce5c\",\"url\":\"https://i.imgur.com/Br34VTM.jpg\"},{\"_id\":\"5ec104f35f054e001796ce5e\",\"url\":\"https://i.imgur.com/2PMzeIs.jpg\"},{\"_id\":\"5ec306c6b680b500172c107e\",\"url\":\"https://i.imgur.com/oeF9ajf.jpg\"}]");

/***/ }),

/***/ "./src/app/treeData.ts":
/*!*****************************!*\
  !*** ./src/app/treeData.ts ***!
  \*****************************/
/*! exports provided: TreeData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TreeData", function() { return TreeData; });
/* harmony import */ var _treeItem__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./treeItem */ "./src/app/treeItem.ts");

class TreeData {
    constructor(data, settings) {
        this.row1 = [];
        this.row2 = [];
        this.row3 = [];
        this.children = [];
        this.siblingsBefore = [];
        this.spouses = [];
        this.siblingsAfter = [];
        this.currentPersonWithSiblings = [];
        this.settings = settings;
        this.ExtractData(data);
        this.row1 = [this.father, this.mother];
        this.row2 = [...this.siblingsBefore, this.currentPerson, ...this.spouses, ...this.siblingsAfter];
        this.shiftRow(this.row2, 0, (this.settings.rectangleHeight + this.settings.verticalOffset));
        this.row3 = [...this.children];
        this.shiftRow(this.row3, 0, (this.settings.rectangleHeight + this.settings.verticalOffset) * 2);
        this.shiftXEachItems(this.row1);
        this.shiftXEachItems(this.row2);
        this.shiftXEachItems(this.row3);
        let toShift = (this.currentPersonWithSiblings[0].x - this.currentPersonWithSiblings[this.currentPersonWithSiblings.length - 1].x) / 2;
        toShift += (this.settings.rectangleWidth + this.settings.horizontalOffset) / 2;
        this.shiftRow(this.row2, toShift, 0);
        const toShift2 = (this.children.length > 0)
            ? ((this.children[0].x + this.children[this.children.length - 1].x) / 2)
            : 0;
        const toShift3 = (this.spouses.length > 0) ?
            ((this.currentPerson.x + this.spouses[0].x) / 2) : 0;
        this.shiftRow(this.row3, toShift3 - toShift2, 0);
        this.shiftMin();
        this.shiftRow(this.row1, this.settings.horizontalOffset, this.settings.verticalOffset);
        this.shiftRow(this.row2, this.settings.horizontalOffset, this.settings.verticalOffset);
        this.shiftRow(this.row3, this.settings.horizontalOffset, this.settings.verticalOffset);
    }
    ExtractData(data) {
        var _a, _b, _c, _d;
        this.father = new _treeItem__WEBPACK_IMPORTED_MODULE_0__["TreeItem"](0, 0, data.father, 'father');
        this.mother = new _treeItem__WEBPACK_IMPORTED_MODULE_0__["TreeItem"](0, 0, data.mother, 'mother');
        // Add current user, spouse and siblings
        const siblingsBefore = data.siblings.filter(x => x.yearOfBirth < data.currentPerson.yearOfBirth);
        if (((_a = siblingsBefore) === null || _a === void 0 ? void 0 : _a.length) > 0) {
            for (const sibling of siblingsBefore) {
                this.siblingsBefore.push(new _treeItem__WEBPACK_IMPORTED_MODULE_0__["TreeItem"](0, 0, sibling, 'sibling'));
            }
        }
        this.currentPerson = new _treeItem__WEBPACK_IMPORTED_MODULE_0__["TreeItem"](0, 0, data.currentPerson, 'current');
        if (((_b = data.spouses) === null || _b === void 0 ? void 0 : _b.length) > 0) {
            for (const spouse of data.spouses) {
                this.spouses.push(new _treeItem__WEBPACK_IMPORTED_MODULE_0__["TreeItem"](0, 0, spouse, 'spouse'));
            }
        }
        else if (((_c = data.children) === null || _c === void 0 ? void 0 : _c.length) > 0) {
            this.spouses.push(new _treeItem__WEBPACK_IMPORTED_MODULE_0__["TreeItem"](0, 0, null, 'spouse'));
        }
        const siblingsAfter = data.siblings.filter(x => x.yearOfBirth >= data.currentPerson.yearOfBirth);
        if (((_d = siblingsAfter) === null || _d === void 0 ? void 0 : _d.length) > 0) {
            for (const sibling of siblingsAfter) {
                this.siblingsAfter.push(new _treeItem__WEBPACK_IMPORTED_MODULE_0__["TreeItem"](0, 0, sibling, 'sibling'));
            }
        }
        // Add children
        if (data.children != null) {
            for (const child of data.children) {
                this.children.push(new _treeItem__WEBPACK_IMPORTED_MODULE_0__["TreeItem"](0, 0, child, 'child'));
            }
        }
        this.currentPersonWithSiblings = [...this.siblingsBefore, this.currentPerson, ...this.siblingsAfter];
    }
    getWidth() {
        return Math.max(this.row1[this.row1.length - 1].x + this.settings.rectangleWidth, this.row2[this.row2.length - 1].x + this.settings.rectangleWidth, this.row3.length > 0 ? this.row3[this.row3.length - 1].x + this.settings.rectangleWidth : 0) + this.settings.horizontalOffset;
    }
    getHeight() {
        return (this.children.length === 0 ? 2 : 3) *
            (this.settings.rectangleHeight + this.settings.verticalOffset) + this.settings.verticalOffset;
    }
    shiftRow(row, shiftX, shiftY) {
        row.forEach(elm => {
            elm.x += shiftX;
            elm.y += shiftY;
        });
    }
    shiftXEachItems(row) {
        let idx = 0;
        for (const rowItem of row) {
            rowItem.x += idx * (this.settings.rectangleWidth + this.settings.horizontalOffset);
            idx++;
        }
    }
    shiftMin() {
        let min = 0;
        for (const i of this.row1) {
            if (i.x < min) {
                min = i.x;
            }
        }
        for (const i of this.row2) {
            if (i.x < min) {
                min = i.x;
            }
        }
        for (const i of this.row3) {
            if (i.x < min) {
                min = i.x;
            }
        }
        this.shiftRow(this.row1, -min, 0);
        this.shiftRow(this.row2, -min, 0);
        this.shiftRow(this.row3, -min, 0);
    }
}


/***/ }),

/***/ "./src/app/treeDraw.ts":
/*!*****************************!*\
  !*** ./src/app/treeDraw.ts ***!
  \*****************************/
/*! exports provided: TreeDraw */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TreeDraw", function() { return TreeDraw; });
/* harmony import */ var _treeData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./treeData */ "./src/app/treeData.ts");

class TreeDraw {
    drawBorder(svg, height, width) {
        const g = svg.append('g');
        g.append('g')
            .append('rect')
            .attr('x', 0)
            .attr('y', 0)
            .attr('height', height)
            .attr('width', width)
            .attr('stroke-width', 1)
            .attr('fill', '#FFFFFF')
            .attr('stroke', '#000000');
    }
    draw(svg, data) {
        var _a;
        if (data.currentPerson == null) {
            return;
        }
        this.settings = {
            horizontalOffset: 30,
            verticalOffset: 30,
            rectangleWidth: 140,
            rectangleHeight: 60
        };
        const treeData = new _treeData__WEBPACK_IMPORTED_MODULE_0__["TreeData"](data, this.settings);
        const height = treeData.getHeight();
        const width = treeData.getWidth();
        this.drawBorder(svg, height, width);
        svg
            .style('width', width + 'px')
            .style('height', height + 'px');
        const id = (_a = data.currentPerson) === null || _a === void 0 ? void 0 : _a.profileId;
        treeData.row1.forEach(element => {
            this.drawPerson2(svg, element, id);
        });
        treeData.row2.forEach(element => {
            this.drawPerson2(svg, element, id);
        });
        treeData.row3.forEach(element => {
            this.drawPerson2(svg, element, id);
        });
        this.drawSpouse(svg, treeData.father, treeData.mother);
        this.drawChild(svg, treeData.father, treeData.mother);
        if (treeData.spouses.length > 0) {
            this.drawSpouse(svg, treeData.spouses[0], treeData.currentPerson);
        }
        if (data.children.length > 0) {
            this.drawChild(svg, treeData.spouses[0], treeData.currentPerson);
            treeData.children.forEach(x => {
                this.drawParent(svg, x);
            });
            this.drawSibling(svg, treeData.children[0], treeData.children[treeData.children.length - 1]);
        }
        if (treeData.currentPersonWithSiblings.length > 0) {
            treeData.currentPersonWithSiblings.forEach(x => {
                this.drawParent(svg, x);
            });
            this.drawSibling(svg, treeData.currentPersonWithSiblings[0], treeData.currentPersonWithSiblings[treeData.currentPersonWithSiblings.length - 1]);
        }
    }
    drawSpouse(svg, i1, i2) {
        const g = svg.append('g');
        g.append('line')
            .attr('x1', (i1.x > i2.x ? i2.x : i1.x) + this.settings.rectangleWidth)
            .attr('y1', i1.y + this.settings.rectangleHeight / 2)
            .attr('x2', (i1.x > i2.x ? i1.x : i2.x))
            .attr('y2', i2.y + this.settings.rectangleHeight / 2)
            .attr('stroke-width', 1.5)
            .attr('stroke', '#000000');
    }
    drawChild(svg, i1, i2) {
        const g = svg.append('g');
        g.append('line')
            .attr('x1', (i1.x > i2.x ? i2.x : i1.x) + this.settings.rectangleWidth + this.settings.horizontalOffset / 2)
            .attr('y1', i1.y + this.settings.rectangleHeight / 2)
            .attr('x2', (i1.x > i2.x ? i2.x : i1.x) + this.settings.rectangleWidth + this.settings.horizontalOffset / 2)
            .attr('y2', i1.y + this.settings.rectangleHeight + this.settings.verticalOffset / 2)
            .attr('stroke-width', 1.5)
            .attr('stroke', '#000000');
    }
    drawParent(svg, i) {
        const g = svg.append('g');
        g.append('line')
            .attr('x1', i.x + this.settings.rectangleWidth / 2)
            .attr('y1', i.y)
            .attr('x2', i.x + this.settings.rectangleWidth / 2)
            .attr('y2', i.y - this.settings.verticalOffset / 2)
            .attr('stroke-width', 1.5)
            .attr('stroke', '#000000');
    }
    drawSibling(svg, i1, i2) {
        const g = svg.append('g');
        g.append('line')
            .attr('x1', i1.x + this.settings.rectangleWidth / 2)
            .attr('y1', i1.y - this.settings.verticalOffset / 2)
            .attr('x2', i2.x + this.settings.rectangleWidth / 2)
            .attr('y2', i1.y - this.settings.verticalOffset / 2)
            .attr('stroke-width', 1.5)
            .attr('stroke', '#000000');
    }
    drawPerson2(svg, treeItem, currentPersonId) {
        this.drawPerson(svg, treeItem.x, treeItem.y, treeItem.data, currentPersonId);
    }
    drawPerson(svg, x, y, person, currentPersonId) {
        var _a, _b;
        if (!person) {
            const unknown = { fill: '#A5A6A6', foreground: '#FFFFFF', stroke: '#000000' };
            const g1 = svg.append('g');
            g1.append('rect')
                .attr('x', x)
                .attr('y', y)
                .attr('height', this.settings.rectangleHeight)
                .attr('width', this.settings.rectangleWidth)
                .attr('stroke-width', 1)
                .attr('fill', unknown.fill)
                .attr('stroke', unknown.stroke);
            return;
        }
        const currentUserMan = { fill: '#0657f8', foreground: '#FFFFFF', stroke: '#f20408' };
        const currentUserWoman = { fill: '#ff036c', foreground: '#FFFFFF', stroke: '#f20408' };
        const manStyle = { fill: '#53a7fc', foreground: '#000000', stroke: '#000000' };
        const womanStyle = { fill: '#ffaaff', foreground: '#000000', stroke: '#000000' };
        let style = {};
        if (person.gender === 'Male') {
            style = manStyle;
        }
        else {
            style = womanStyle;
        }
        if (person.profileId === currentPersonId) {
            if (person.gender === 'Male') {
                style = currentUserMan;
            }
            else {
                style = currentUserWoman;
            }
        }
        const style1 = Object.assign(style);
        const year = (_a = person.yearOfBirth, (_a !== null && _a !== void 0 ? _a : ''));
        const year2 = (_b = person.yearOfDeath, (_b !== null && _b !== void 0 ? _b : ''));
        let yearText = `${year}-${year2}`;
        if (yearText === '-') {
            yearText = '';
        }
        let g = svg.append('g');
        g.append('title')
            .text(person.firstName);
        const baseUrl = 'person/';
        if (person.profileId !== currentPersonId) {
            g = g.append('a')
                .attr('href', baseUrl + person.profileId);
        }
        g.append('rect')
            .attr('x', x)
            .attr('y', y)
            .attr('height', this.settings.rectangleHeight)
            .attr('width', this.settings.rectangleWidth)
            .attr('stroke-width', 1)
            .attr('fill', style1.fill)
            .attr('stroke', style1.stroke);
        g.append('text')
            .attr('font-size', '12')
            .attr('font-weight', 'bold')
            .attr('y', y + 20)
            .attr('x', x + 10)
            .attr('fill', style1.foreground)
            .text(person.lastName);
        g.append('text')
            .attr('font-size', '12')
            .attr('font-weight', 'bold')
            .attr('y', y + 40)
            .attr('x', x + 10)
            .attr('fill', style1.foreground)
            .text(person.firstName);
        g.append('text')
            .attr('font-size', '12')
            .attr('y', y + 55)
            .attr('x', x + 55)
            .attr('fill', style1.foreground)
            .text(yearText);
    }
}


/***/ }),

/***/ "./src/app/treeItem.ts":
/*!*****************************!*\
  !*** ./src/app/treeItem.ts ***!
  \*****************************/
/*! exports provided: TreeItem */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TreeItem", function() { return TreeItem; });
class TreeItem {
    constructor(x, y, data, type) {
        this.x = x;
        this.y = y;
        this.data = data;
        this.type = type;
    }
}


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\Repository\Genealogy-web\src\main.ts */"./src/main.ts");


/***/ }),

/***/ 1:
/*!********************!*\
  !*** ws (ignored) ***!
  \********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map