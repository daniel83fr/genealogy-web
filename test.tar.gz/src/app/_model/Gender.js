var Gender;
(function (Gender) {
    Gender["Male"] = "Male";
    Gender["Female"] = "Female";
    Gender["Unknown"] = "Unknown";
})(Gender || (Gender = {}));
//# sourceMappingURL=Gender.js.map