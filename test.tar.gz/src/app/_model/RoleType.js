var RoleType;
(function (RoleType) {
    RoleType["Admin"] = "Admin";
    // Can see /edit everything
    RoleType["Contributor"] = "Contributor";
    // Can see most in detailed of the info from ascendent/descendant/siblings
    RoleType["Limited"] = "Limited";
    //Can see public info and update his direct family
    RoleType["Guest"] = "Guest";
    //Can only view and suggest modification.
})(RoleType || (RoleType = {}));
//# sourceMappingURL=RoleType.js.map