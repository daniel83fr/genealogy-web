var ProfileType;
(function (ProfileType) {
    ProfileType["Public"] = "Public";
    // All information are visible (Deceased people have public profile)
    ProfileType["Detailed"] = "Detailed";
    // Most info are visible (exception phones, emails ..)
    ProfileType["Default"] = "Default";
    // Only basic info visible (names, year of birth..)
    ProfileType["Private"] = "Private";
    // Only LastName, initials and year of birth visible
})(ProfileType || (ProfileType = {}));
//# sourceMappingURL=profileType.js.map