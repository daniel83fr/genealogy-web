import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
let ConfigurationService = class ConfigurationService {
    constructor(cacheService, http) {
        this.cacheService = cacheService;
        this.http = http;
    }
    getApiEndpoint() {
        return new Promise((resolve, reject) => {
            const cachedEndpoint = this.cacheService.endpoint;
            if (cachedEndpoint != null) {
                resolve(cachedEndpoint);
            }
            const url = window.location.origin + '/env';
            fetch(url)
                .then((resp) => resp.json())
                .then(res => {
                const endpoint = res.GENEALOGY_API;
                this.cacheService.endpoint = endpoint;
                resolve(endpoint);
                return endpoint;
            }).catch(err => {
                reject(Error(err));
            });
        });
    }
    getEnvironnement() {
        return new Promise((resolve, reject) => {
            const cachedEnv = this.cacheService.environnement;
            if (cachedEnv != null) {
                resolve(cachedEnv);
            }
            const url = window.location.origin + '/env';
            fetch(url)
                .then((resp) => resp.json())
                .then(res => {
                const env = res.Environnement;
                this.cacheService.environnement = env;
                resolve(env);
                return env;
            }).catch(err => {
                reject(Error(err));
            });
        });
    }
};
ConfigurationService = __decorate([
    Injectable({
        providedIn: 'root'
    })
], ConfigurationService);
export { ConfigurationService };
//# sourceMappingURL=ConfigurationService.js.map