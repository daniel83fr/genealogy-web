import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
let EncryptionService = class EncryptionService {
    encryptPassword(password) {
        return password;
    }
};
EncryptionService = __decorate([
    Injectable({
        providedIn: 'root'
    })
], EncryptionService);
export { EncryptionService };
//# sourceMappingURL=EncryptionService.js.map