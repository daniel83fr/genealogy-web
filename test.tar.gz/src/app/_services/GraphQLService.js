import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
import { createApolloFetch } from 'apollo-fetch';
let GraphQLService = class GraphQLService {
    constructor(cacheService, encryptionService) {
        this.cacheService = cacheService;
        this.encryptionService = encryptionService;
    }
    addPhoto(endpoint, link, deletehash, persons) {
        const token = localStorage.getItem('token');
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        fetch.use(addToken(token));
        return fetch({
            query: `mutation addPhoto($link: String!, $deleteHash: String, $persons: [String] ) {
  addPhoto( url : $link, deleteHash :$deleteHash, persons:$persons)
          }
          `,
            variables: { link, deleteHash: deletehash, persons }
        }).then(res => {
            return res.data.addPhoto;
        });
    }
    login(endpoint, login, password) {
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        const encrypted = this.encryptionService.encryptPassword(password);
        return fetch({
            query: `
query Login {
  login(login: "${login}", password: "${encrypted}"){
    success
    token
    error
  }
}`
        })
            .then(res => res.data.login);
    }
    register(endpoint, id, login, email, password) {
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        const encrypted = this.encryptionService.encryptPassword(password);
        return fetch({
            query: `
query Register {
  register(id: "${id}", login: "${login}", email: "${email}" password: "${encrypted}")
}`
        }).then(res => {
            return res.data;
        });
    }
    getPersonList(endpoint, itemCount, cacheDate) {
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        return fetch({
            query: `query SearchAllPersons($cacheCount: Int, $cacheDate: String) {
            data: getPersonList(cacheCount: $cacheCount, cacheDate: $cacheDate) {
              users{
                _id
                firstName
                lastName
                maidenName,
                gender,
                yearOfBirth,
                yearOfDeath,
                isDead,
                profileId
              },
              isUpToDate
            }
          }
          `,
            variables: { cacheCount: itemCount, cacheDate: cacheDate }
        }).then(res => {
            if (!res.data.data.isUpToDate) {
                this.cacheService.personsList = this.cacheService.createCacheObject(res.data.data.users);
            }
            return res.data.data;
        });
    }
    getConnectedUser(endpoint) {
        const token = localStorage.getItem('token');
        if (token == null) {
            return null;
        }
        const fetch = createApolloFetch({
            uri: endpoint
        });
        fetch.use(({ request, options }, next) => {
            if (!options.headers) {
                options.headers = {};
            }
            options.headers['authorization'] = `Bearer ${token}`;
            next();
        });
        return fetch({
            query: `query me {
        me{
          id
          login
        }
      }
      `
        })
            .catch(err => {
            throw Error(err);
        })
            .then(res => {
            return res.data.me;
        });
    }
    getPrivateInfo(endpoint, id) {
        const token = localStorage.getItem('token');
        const fetch = createApolloFetch({
            uri: endpoint
        });
        fetch.use(({ request, options }, next) => {
            if (!options.headers) {
                options.headers = {};
            }
            options.headers['authorization'] = `Bearer ${token}`;
            next();
        });
        return fetch({
            query: `query getPrivateProfile($_id: String!) {
        profile: getPrivateProfile( profileId : $_id) {
          birthDate
          deathDate
          isDead
          currentLocation
          birthLocation
          deathLocation
          email
          phone
          _id
        }
      }
      `,
            variables: { _id: id }
        })
            .catch(err => {
            throw Error(err);
        })
            .then(res => {
            return res.data.profile;
        });
    }
    getProfile(endpoint, id) {
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        return fetch({
            query: `query GetProfile($id: String!) {
        profile: getProfile( profileId : $id) {
          currentPerson{
            ...PersonInfo
          }
          mother{
            ...PersonInfo
          }
          father{
            ...PersonInfo
          }
          siblings{
            ...PersonInfo
          }
          spouses{
            ...PersonInfo
          }
          children{
            ...PersonInfo
          }
          photos{
            url
            _id
            persons{
              ...PhotoTag
            }
          }
      }
    }
    
    fragment PhotoTag on User {
                  _id
                  firstName
                  lastName
                  profileId
                }
       fragment PersonInfo on User {
                  _id
                  firstName
                  lastName
                  maidenName
                  gender
                  yearOfBirth
                  yearOfDeath
                  isDead,
                  profileId
                }
            `,
            variables: { id }
        })
            .then(res => {
            let profile = res.data.profile;
            let cacheObject = this.cacheService.createCacheObject(profile);
            localStorage.setItem("profile_" + id, JSON.stringify(cacheObject));
            return profile;
        });
    }
    getProfileId(endpoint, id) {
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        return fetch({
            query: `query GetProfileId($id: String!) {
              getProfileId(_id: $id)
            }
            `,
            variables: { id }
        })
            .then(res => {
            var _a, _b, _c;
            console.log(JSON.stringify(res));
            return _c = (_b = (_a = res) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.getProfileId, (_c !== null && _c !== void 0 ? _c : id);
        })
            .catch(err => {
            return id;
        });
    }
    deleteProfile(endpoint, id) {
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        return fetch({
            query: `mutation RemoveProfile($id: String!) {
              removeProfile(_id: $id)
            }
            `,
            variables: {
                id,
            }
        });
    }
    updateProfile(endpoint, id, changes, privateChange, updateUser) {
        const token = localStorage.getItem('token');
        if (changes != {}) {
            changes['updatedBy'] = updateUser;
        }
        if (privateChange != {}) {
            privateChange['updatedBy'] = updateUser;
        }
        const patchString = this.generatePatch(changes);
        const privatePatchString = this.generatePatch(privateChange);
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        fetch.use(addToken(token));
        return fetch({
            query: `mutation UpdatePerson($_id:String!) {
              updatePerson(_id: $_id, patch: ${patchString} ) {
                _id
                firstName
                lastName
                maidenName
                gender
                isDead
              },
              updatePersonPrivateInfo(_id: $_id, patch: ${privatePatchString} ) {
                _id
                birthDate
                deathDate
                currentLocation
                birthLocation
                deathLocation
                email
                phone
              },
            }
            `,
            variables: {
                _id: id,
            }
        });
    }
    generatePatch(changes) {
        const objectKeys = Object.keys(changes);
        let patchString = '{';
        objectKeys.forEach(i => {
            patchString += i;
            patchString += ':';
            patchString += '"' + changes[i] + '"';
            patchString += ',';
        });
        patchString += '}';
        return patchString;
    }
    createPerson(endpoint, changes) {
        const fetch = createApolloFetch({
            uri: endpoint.toString(),
        });
        const objectKeys = Object.keys(changes);
        let patchString = '{';
        objectKeys.forEach(i => {
            patchString += i;
            patchString += ':';
            patchString += '"' + changes[i] + '"';
            patchString += ',';
        });
        patchString += '}';
        return fetch({
            query: `mutation createPerson {
          createPerson(person: ${patchString} ) {
            _id
            firstName
            lastName
            maidenName
            gender
            yearOfBirth
          }
        }
        `
        }).then(res => {
            return res.data.createPerson._id;
        });
    }
    getPhotos(endpoint, person) {
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        return fetch({
            query: `query getPhotosById($_id: String!) {
        getPhotosById(_id: $_id) {
          _id
          url
          persons{
            firstName
            lastName
            _id
          }
        }
      }
          `,
            variables: { _id: person }
        })
            .catch(err => {
            throw Error(err);
        }).then(res => {
            var _a;
            return (_a = res.data) === null || _a === void 0 ? void 0 : _a.getPhotosById;
        });
    }
    getProfilePhoto(endpoint, person) {
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        return fetch({
            query: `query getPhotoProfile($_id: String!) {
  getPhotoProfile( _id : $_id) {
              url
              _id
            }
          }
          `,
            variables: { _id: person }
        })
            .catch(err => {
            throw Error(err);
        }).then(res => {
            var _a;
            return (_a = res.data) === null || _a === void 0 ? void 0 : _a.getPhotoProfile;
        });
    }
    getPhotosRandom(endpoint) {
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        return fetch({
            query: `query GetPhotos {
        photos: getPhotosRandom(number: 5) {
          url
          _id
        }
      }`
        }).then(res => {
            return res.data.photos;
        });
    }
    getTodaysEvents(endpoint) {
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        return fetch({
            query: `query getTodayMarriagedays {
        birthday: getTodayBirthdays{
         ...usr
        },
        deathday: getTodayDeathdays{
         ...usr
        },
        marriage: getTodayMarriagedays{
         ...usr
        }
      }
      fragment usr on User{
           _id
          firstName
          lastName
      }
      `
        }).then(res => {
            return res.data;
        });
    }
    getAuditLastEntries(endpoint) {
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        return fetch({
            query: `query GetAudit {
        audit: getAuditLastEntries(number: 10) {
          timestamp
          type
          id
          user
          action
        }
      }
      `
        }).then(res => {
            return res.data.audit;
        });
    }
    removeLink(endpoint, person1, person2) {
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        return fetch({
            query: `mutation RemoveLink($id: String!, $id2: String!) {
          removeLink(_id1: $id, _id2: $id2)
        }
        `,
            variables: {
                id: person1,
                id2: person2
            }
        }).then(res => {
            return res.data.removeLink;
        });
    }
    removeSiblingLink(endpoint, person1, person2) {
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        return fetch({
            query: `mutation RemoveSiblingLink($id: String!, $id2: String!) {
        removeSiblingLink(_id1: $id, _id2: $id2)
      }
      `,
            variables: {
                id: person1,
                id2: person2
            }
        }).then(res => {
            return res.data.removeSiblingLink;
        });
    }
    linkParent(endpoint, person1, person2) {
        const fetch = createApolloFetch({
            uri: endpoint.toString(),
        });
        return fetch({
            query: `mutation addParentLink($id: String!, $id2: String!) {
          addParentLink(_id: $id, _parentId: $id2)
        }
        `,
            variables: {
                id: person1,
                id2: person2
            }
        })
            .then(res => {
            return res.data.addParentLink;
        });
    }
    linkChild(endpoint, person1, person2) {
        const fetch = createApolloFetch({
            uri: endpoint,
        });
        return fetch({
            query: `mutation addChildLink($id: String!, $id2: String!) {
          addChildLink(_id: $id, _childId: $id2)
        }
        `,
            variables: {
                id: person1,
                id2: person2
            }
        })
            .then(res => {
            return res.data.addChildLink;
        });
    }
    deletePhoto(endpoint, image) {
        const fetch = createApolloFetch({
            uri: endpoint.toString(),
        });
        return fetch({
            query: `mutation deletePhoto($image: String!) {
        deletePhoto(image: $image)
        }
        `,
            variables: {
                image: image
            }
        })
            .then(res => {
            return res.data.deletePhoto;
        });
    }
    setProfilePicture(endpoint, person, image) {
        const fetch = createApolloFetch({
            uri: endpoint.toString(),
        });
        return fetch({
            query: `mutation setProfilePicture($person: String!, $image: String!) {
        setProfilePicture(person: $person, image: $image)
        }
        `,
            variables: {
                person: person,
                image: image
            }
        })
            .then(res => {
            return res.data.setProfilePicture;
        });
    }
    addPhotoTag(endpoint, person, image) {
        const fetch = createApolloFetch({
            uri: endpoint.toString(),
        });
        return fetch({
            query: `mutation addPhotoTag($person: String!, $image: String!) {
        addPhotoTag(image: $image, tag: $person)
        }
        `,
            variables: {
                person: person,
                image: image
            }
        })
            .then(res => {
            return res.data.addPhotoTag;
        });
    }
    removePhotoTag(endpoint, person, image) {
        const fetch = createApolloFetch({
            uri: endpoint.toString(),
        });
        return fetch({
            query: `mutation removePhotoTag($person: String!, $image: String!) {
        removePhotoTag(image: $image, tag: $person)
        }
        `,
            variables: {
                person: person,
                image: image
            }
        })
            .then(res => {
            return res.data.removePhotoTag;
        });
    }
    linkSpouse(endpoint, person1, person2) {
        const fetch = createApolloFetch({
            uri: endpoint.toString(),
        });
        return fetch({
            query: `mutation addSpouseLink($id: String!, $id2: String!) {
          addSpouseLink(_id1: $id, _id2: $id2)
        }
        `,
            variables: {
                id: person1,
                id2: person2
            }
        })
            .then(res => {
            return res.data.addSpouseLink;
        });
    }
    linkSibling(endpoint, person1, person2) {
        const fetch = createApolloFetch({
            uri: endpoint.toString(),
        });
        return fetch({
            query: `mutation addSiblingLink($id: String!, $id2: String!) {
          addSiblingLink(_id1: $id, _id2: $id2)
        }
        `,
            variables: {
                id: person1,
                id2: person2
            }
        })
            .then(res => {
            return res.data.addSiblingLink;
        });
    }
};
GraphQLService = __decorate([
    Injectable({
        providedIn: 'root'
    })
], GraphQLService);
export { GraphQLService };
function addToken(token) {
    return ({ request, options }, next) => {
        if (!options.headers) {
            options.headers = {};
        }
        options.headers.authorization = `Bearer ${token}`;
        next();
    };
}
//# sourceMappingURL=GraphQLService.js.map