import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
let NotificationService = class NotificationService {
    constructor(snackBar) {
        this.snackBar = snackBar;
        this.duration = 3000;
    }
    showInfo(text) {
        this.snackBar.open(text, 'close', { duration: this.duration, panelClass: ['info-snackbar'] });
    }
    showSuccess(text) {
        this.snackBar.open(text, 'close', { duration: this.duration, panelClass: ['success-snackbar'] });
    }
    showError(text) {
        this.snackBar.open(text, 'close', { duration: this.duration, panelClass: ['error-snackbar'] });
    }
    showWarning(text) {
        this.snackBar.open(text, 'close', { duration: this.duration, panelClass: ['warn-snackbar'] });
    }
};
NotificationService = __decorate([
    Injectable({
        providedIn: 'root'
    })
], NotificationService);
export { NotificationService };
//# sourceMappingURL=NotificationService.js.map