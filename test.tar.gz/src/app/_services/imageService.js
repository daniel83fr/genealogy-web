import { __awaiter, __decorate } from "tslib";
import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
let ImageService = class ImageService {
    constructor(http) {
        this.http = http;
        this.images = [];
        this.url = 'https://api.imgur.com/3/image';
        this.clientId = '7e2fbe3383eb5ed';
    }
    uploadImage(imageFile, infoObject) {
        return __awaiter(this, void 0, void 0, function* () {
            const formData = new FormData();
            formData.append('image', imageFile, imageFile.name);
            const header = new HttpHeaders({
                'authorization': 'Client-ID ' + this.clientId
            });
            const imageData = yield this.http.post(this.url, formData, { headers: header }).toPromise();
            this.imageLink = imageData['data'].link;
            const newImageObject = {
                title: infoObject['title'],
                description: infoObject['description'],
                link: this.imageLink
            };
            this.images.unshift(newImageObject);
        });
    }
    getImages() {
        return this.images;
    }
};
ImageService = __decorate([
    Injectable({
        providedIn: 'root'
    })
], ImageService);
export { ImageService };
//# sourceMappingURL=imageService.js.map