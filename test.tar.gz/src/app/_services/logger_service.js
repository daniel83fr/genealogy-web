const dateFormat = () => new Date(Date.now()).toISOString();
export default class LoggerService {
    constructor(cls) {
        this.cls = cls;
    }
    logToConsole(message, level) {
        console.log(`${dateFormat()} - ${this.cls} - ${level} - ${message}`);
    }
    info(message, obj = null) {
        this.logToConsole(`${message} ${obj == null ? '' : JSON.stringify(obj)}`, 'info');
    }
    debug(message, obj = null) {
        this.logToConsole(`${message} ${obj == null ? '' : JSON.stringify(obj)}`, 'debug');
    }
    error(message, obj = null) {
        this.logToConsole(`${message} ${obj == null ? '' : JSON.stringify(obj)}`, 'error');
    }
}
//# sourceMappingURL=logger_service.js.map