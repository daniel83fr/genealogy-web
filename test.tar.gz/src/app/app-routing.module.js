import { __decorate } from "tslib";
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { PersonComponentComponent } from './components/person-component/person.component';
import { MainComponent } from './components/main-component/main.component';
import { AdminComponent } from './components/admin-component/admin.component';
import { HelpComponent } from './components/help-component/help.component';
import { LoginComponent } from './components/login-component/login.component';
const routes = [
    {
        path: 'admin', component: AdminComponent
    },
    {
        path: 'help', component: HelpComponent
    },
    {
        path: 'login', component: LoginComponent
    },
    {
        path: 'person/:profile', component: PersonComponentComponent
    },
    {
        path: '**', component: MainComponent
    }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = __decorate([
    NgModule({
        imports: [RouterModule.forRoot(routes)],
        exports: [RouterModule]
    })
], AppRoutingModule);
export { AppRoutingModule };
//# sourceMappingURL=app-routing.module.js.map