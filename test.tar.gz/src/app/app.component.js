import { __decorate } from "tslib";
import { Component } from '@angular/core';
let AppComponent = class AppComponent {
    constructor(titleService, metaService) {
        this.titleService = titleService;
        this.metaService = metaService;
        this.title = 'Res01 - Family Tree';
    }
    ngOnInit() {
        this.titleService.setTitle(this.title);
        this.metaService.addTags([
            { name: 'keywords', content: 'Angular, Universal, Example' },
            { name: 'description', content: 'Angular Universal Example' },
            { name: 'robots', content: 'index, follow' }
        ]);
    }
};
AppComponent = __decorate([
    Component({
        selector: 'app-root',
        templateUrl: './app.component.html',
        styleUrls: ['./app.component.css']
    })
], AppComponent);
export { AppComponent };
//# sourceMappingURL=app.component.js.map