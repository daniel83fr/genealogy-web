import { __decorate } from "tslib";
import { Component, EventEmitter, Output } from '@angular/core';
let AdminComponent = class AdminComponent {
    constructor(configurationService, auth) {
        this.configurationService = configurationService;
        this.auth = auth;
        this.onSetTitle = new EventEmitter();
        this.configurationService.getEnvironnement()
            .then(env => {
            this.environnement = env;
        });
        this.configurationService.getApiEndpoint()
            .then(endpoint => {
            this.endpoint = endpoint;
        });
    }
    setTitle() {
        this.onSetTitle.emit('Admin Area');
    }
    isConnected() {
        return this.auth.isConnected();
    }
    connectedLogin() {
        return this.auth.getConnectedLogin();
    }
    connectedProfile() {
        return this.auth.getConnectedProfile();
    }
    ngOnInit() {
    }
    ngAfterContentInit() {
    }
};
__decorate([
    Output()
], AdminComponent.prototype, "onSetTitle", void 0);
AdminComponent = __decorate([
    Component({
        selector: 'app-admin',
        templateUrl: './admin.component.html',
        styleUrls: ['./admin.component.css']
    })
], AdminComponent);
export { AdminComponent };
//# sourceMappingURL=admin.component.js.map