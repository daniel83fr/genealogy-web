import { __decorate } from "tslib";
import { Component } from '@angular/core';
let FooterComponent = class FooterComponent {
    constructor(configurationService, auth) {
        this.configurationService = configurationService;
        this.auth = auth;
        this.configurationService.getEnvironnement()
            .then(env => {
            this.environnement = env;
        });
        this.configurationService.getApiEndpoint()
            .then(endpoint => {
            this.endpoint = endpoint;
        });
    }
    isConnected() {
        return this.auth.isConnected();
    }
    connectedLogin() {
        return this.auth.getConnectedLogin();
    }
    connectedProfile() {
        return this.auth.getConnectedProfile();
    }
    ngOnInit() {
    }
    ngAfterContentInit() {
    }
};
FooterComponent = __decorate([
    Component({
        selector: 'app-footer',
        templateUrl: './footer.component.html',
        styleUrls: ['./footer.component.css']
    })
], FooterComponent);
export { FooterComponent };
//# sourceMappingURL=footer.component.js.map