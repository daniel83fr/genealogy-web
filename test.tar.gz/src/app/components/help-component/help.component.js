import { __decorate } from "tslib";
import { Component } from '@angular/core';
let HelpComponent = class HelpComponent {
    constructor() {
        this.panelOpenState = false;
    }
    ngOnInit() {
    }
    ngAfterContentInit() {
    }
};
HelpComponent = __decorate([
    Component({
        selector: 'app-help',
        templateUrl: './help.component.html',
        styleUrls: ['./help.component.css']
    })
], HelpComponent);
export { HelpComponent };
//# sourceMappingURL=help.component.js.map