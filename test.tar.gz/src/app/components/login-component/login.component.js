import { __decorate } from "tslib";
import { Component } from '@angular/core';
let LoginComponent = class LoginComponent {
    constructor(fb, auth, notif) {
        this.fb = fb;
        this.auth = auth;
        this.notif = notif;
        this.changePasswordForm = null;
        this.loginForm = null;
        this.loginForm = this.fb.group({
            login: '',
            password: ''
        });
        this.changePasswordForm = this.fb.group({
            login: '',
            password: ''
        });
    }
    onSubmit() {
        const login = this.loginForm.controls.login.value;
        const password = this.loginForm.controls.password.value;
        if (login && password) {
            this.auth.login(login, password)
                .catch(err => {
                this.notif.showError('Login failed');
            });
        }
    }
    ngOnInit() {
    }
    isConnected() {
        return this.auth.isConnected();
    }
    ngAfterContentInit() {
    }
};
LoginComponent = __decorate([
    Component({
        selector: 'app-login',
        templateUrl: './login.component.html',
        styleUrls: ['./login.component.css']
    })
], LoginComponent);
export { LoginComponent };
//# sourceMappingURL=login.component.js.map