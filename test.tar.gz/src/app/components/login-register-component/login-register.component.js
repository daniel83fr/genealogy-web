import { __decorate } from "tslib";
import { Component, Input } from '@angular/core';
let LoginRegisterComponent = class LoginRegisterComponent {
    constructor(fb, authService, notif) {
        this.fb = fb;
        this.authService = authService;
        this.notif = notif;
        this.id = '';
        this.edit = false;
        this.registerForm = null;
        this.registerForm = this.fb.group({
            id: '',
            login: '',
            password: '',
            confirm: ''
        });
    }
    onSubmit() {
        const id = this.registerForm.controls.id.value;
        const login = this.registerForm.controls.login.value;
        const password = this.registerForm.controls.password.value;
        const confirm = this.registerForm.controls.confirm.value;
        const email = this.registerForm.controls.email.value;
        if (password != confirm) {
            this.notif.showError('Password/confirmation not matching');
            return;
        }
        if (login && password) {
            this.authService.register(id, login, email, password)
                .then(res => {
                this.notif.showSuccess('Registrated');
                window.location.reload();
            }).catch(err => {
                this.notif.showError(err);
            });
        }
    }
    ngOnInit() {
        var _a;
        this.registerForm = this.fb.group({
            id: (_a = this) === null || _a === void 0 ? void 0 : _a.id,
            login: '',
            email: '',
            password: '',
            confirm: ''
        });
    }
    ngAfterContentInit() {
    }
    onChange(value) {
        this.edit = value.checked;
    }
    click() {
        this.edit = !this.edit;
    }
};
__decorate([
    Input('id')
], LoginRegisterComponent.prototype, "id", void 0);
LoginRegisterComponent = __decorate([
    Component({
        selector: 'app-login-register',
        templateUrl: './login-register.component.html',
        styleUrls: ['./login-register.component.css']
    })
], LoginRegisterComponent);
export { LoginRegisterComponent };
//# sourceMappingURL=login-register.component.js.map