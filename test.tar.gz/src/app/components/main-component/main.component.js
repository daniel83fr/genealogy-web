import { __decorate } from "tslib";
import { Component, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import io from 'socket.io-client';
import LoggerService from 'src/app/_services/logger_service';
let MainComponent = class MainComponent {
    constructor(configurationService, graphQLService, router, auth, cacheService) {
        this.configurationService = configurationService;
        this.graphQLService = graphQLService;
        this.router = router;
        this.auth = auth;
        this.cacheService = cacheService;
        this.logger = new LoggerService('main');
        this.displayedColumns = [];
        this.inputMessage = '';
        this.messages = '';
        this.date = Date();
    }
    ngOnInit() {
        this.ioClient = io.connect();
        this.ioClient.on('message-received', (msg) => {
            const message = msg + '\r\n';
            this.messages = this.messages + message;
        });
    }
    randomPhotos() {
        const fileCache = require('../../data/cache/randomPhotos.json');
        this.images = fileCache;
        this.configurationService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQLService.getPhotosRandom(endpoint);
        })
            .then(res => this.images = res);
    }
    ngAfterContentInit() {
        this.search();
        this.randomPhotos();
        this.configurationService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQLService.getAuditLastEntries(endpoint);
        })
            .then(res => this.audit = res);
        this.configurationService.getApiEndpoint()
            .then(endpoint => {
            const res = this.graphQLService.getTodaysEvents(endpoint);
            console.log(JSON.stringify(res));
            return res;
        })
            .then(res => this.events = res);
    }
    search() {
        let cachedItems = this.cacheService.getPersonListFromCache();
        this.fillGrid(cachedItems.data);
        this.configurationService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQLService.getPersonList(endpoint, cachedItems.data.length, cachedItems.timestamp);
        })
            .then(res => {
            console.log(JSON.stringify(res));
            if (!res.isUpToDate) {
                this.logger.info('cache updated');
                this.fillGrid(res.users);
                this.logger.info('search refreshed');
            }
        });
    }
    fillGrid(data) {
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        // if(window.screen.availWidth < 400 ){
        //   this.displayedColumns = ['firstName', 'lastName', 'link'];
        // } else{
        //   this.displayedColumns = ['firstName', 'lastName', 'gender', 'year', 'link'];
        // }
        this.displayedColumns = ['firstName', 'lastName', 'link', 'gender'];
    }
    getTitle(element) {
        var _a, _b;
        const birth = (_a = element.yearOfBirth, (_a !== null && _a !== void 0 ? _a : ''));
        const death = (_b = element.yearOfDeath, (_b !== null && _b !== void 0 ? _b : ''));
        return `${element._id}:
    ${element.firstName} ${element.lastName}
    ${birth}-${death}`;
    }
    navigateTo(url) {
        this.router.navigateByUrl(url);
    }
    applyFilter(event) {
        const filterValue = event.target.value;
        this.dataSource.filter = filterValue.trim().toLowerCase();
    }
    sendMessage(txt) {
        if (txt !== '') {
            this.ioClient.emit('message', this.auth.getConnectedLogin() + ': ' + txt.replace('<', ''));
            this.inputMessage = '';
        }
    }
};
__decorate([
    ViewChild(MatSort, { static: true })
], MainComponent.prototype, "sort", void 0);
__decorate([
    ViewChild(MatPaginator, { static: true })
], MainComponent.prototype, "paginator", void 0);
MainComponent = __decorate([
    Component({
        selector: 'app-main',
        templateUrl: './main.component.html',
        styleUrls: ['./main.component.css']
    })
], MainComponent);
export { MainComponent };
//# sourceMappingURL=main.component.js.map