import { __decorate } from "tslib";
import { Component } from '@angular/core';
let NavComponent = class NavComponent {
    constructor(configurationService, graphQLService, auth, router) {
        this.configurationService = configurationService;
        this.graphQLService = graphQLService;
        this.auth = auth;
        this.router = router;
        this.environnement = '';
        this.connectedUser = '';
        this.profileLink = '/';
    }
    ngOnInit() {
    }
    logout() {
        this.auth.logout();
    }
    isConnected() {
        return this.auth.isConnected();
    }
    getConnectedLogin() {
        return this.auth.getConnectedLogin();
    }
    getConnectedProfile() {
        this.router.navigateByUrl('/person/' + this.getConnectedLogin());
    }
    ngAfterContentInit() {
    }
};
NavComponent = __decorate([
    Component({
        selector: 'app-nav',
        templateUrl: './nav.component.html',
        styleUrls: ['./nav.component.css']
    })
], NavComponent);
export { NavComponent };
//# sourceMappingURL=nav.component.js.map