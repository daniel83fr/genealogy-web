import { __decorate } from "tslib";
import { Component } from '@angular/core';
import * as d3 from 'd3';
import { TreeDraw } from '../../treeDraw';
let PersonComponentComponent = class PersonComponentComponent {
    constructor(rest, route, router, auth, api, titleService, metaService) {
        this.rest = rest;
        this.route = route;
        this.router = router;
        this.auth = auth;
        this.api = api;
        this.titleService = titleService;
        this.metaService = metaService;
        this.refreshing = false;
        this.id = undefined;
        this.data = {};
        router.events.subscribe((val) => {
            if (this.profile != this.route.snapshot.paramMap.get('profile')) {
                this.profile = this.route.snapshot.paramMap.get('profile');
                this.ngOnChanges();
            }
        });
        this.ngOnChanges();
    }
    isConnected() {
        return this.auth.isConnected();
    }
    getProfileId(profileId) {
        return this.rest.getApiEndpoint()
            .then(endpoint => {
            return this.api.getProfileId(endpoint, profileId);
        });
    }
    getProfileById(id) {
        let cache = localStorage.getItem('profile_' + id);
        let cacheData;
        if (cache != null) {
            cacheData = JSON.parse(cache);
            this.id = cacheData.data.currentPerson._id;
            this.setTitle(cacheData.data.currentPerson);
            this.data = cacheData.data;
            const svg = d3.select('.familyTree');
            new TreeDraw().draw(svg, cacheData.data);
        }
        if (cacheData == undefined || cacheData.timestamp < new Date(new Date().getTime() - 10 * 60000).toJSON()) {
            this.rest.getApiEndpoint()
                .then(endpoint => {
                return this.api.getProfile(endpoint, id);
            })
                .then(data => {
                this.id = data.currentPerson._id;
                this.setTitle(data.currentPerson);
                this.setMeta(data);
                this.data = data;
                const svg = d3.select('.familyTree');
                new TreeDraw().draw(svg, data);
            });
        }
    }
    setTitle(person) {
        this.titleService.setTitle(`${person.firstName} ${person.lastName}'s profile`);
    }
    setMeta(data) {
        const person = data.currentPerson;
        this.metaService.updateTag({ content: `${person.firstName} ${person.lastName}'s profile` }, 'name="description"');
        this.metaService.updateTag({ content: `${person.firstName}, ${person.lastName}, profile` }, 'name="keywords"');
    }
    getProfilePrivateById(id) {
        this.rest.getApiEndpoint()
            .then(endpoint => {
            return this.api.getPrivateInfo(endpoint, id);
        })
            .then(data => {
            this.privateData = data;
        });
    }
    ngAfterContentInit() {
    }
    ngOnChanges() {
        if (this.profile == undefined) {
            return;
        }
        console.log(this.profile);
        //this.getProfileId(this.profile)
        // .then(profileId => {
        console.log(this.profile);
        this.getProfileById(this.profile);
        if (this.isConnected()) {
            this.getProfilePrivateById(this.profile);
        }
        //  });
    }
    ngOnInit() {
    }
};
PersonComponentComponent = __decorate([
    Component({
        selector: 'app-person-component',
        templateUrl: './person.component.html',
        styleUrls: ['./person.component.css']
    })
], PersonComponentComponent);
export { PersonComponentComponent };
//# sourceMappingURL=person.component.js.map