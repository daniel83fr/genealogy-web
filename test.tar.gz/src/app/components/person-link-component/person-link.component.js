import { __decorate } from "tslib";
import { Component, Input } from '@angular/core';
let PersonLinkComponent = class PersonLinkComponent {
    constructor(http, fb, rest, graphQLService, router) {
        this.http = http;
        this.fb = fb;
        this.rest = rest;
        this.graphQLService = graphQLService;
        this.router = router;
        this.id = '';
        this.person = {};
        this.editable = false;
        this.type = '';
        this.edit = false;
        this.personEditForm = null;
        this.personEditForm = this.fb.group({
            id: this.person._id,
            firstName: this.person.firstName,
            lastName: this.person.lastName,
            gender: this.person.gender,
            birthDate: this.person.yearOfBirth,
        });
    }
    onClick() {
        this.router.navigateByUrl('person/' + this.person.profileId);
    }
    ngOnInit() {
    }
    ngAfterContentInit() {
    }
    removeLink() {
        if (this.type === 'sibling') {
            this.removeSiblingLink();
        }
        else {
            this.removeDirectLink();
        }
    }
    removeSiblingLink() {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.graphQLService.removeSiblingLink(endpoint, this.id, this.person._id);
        }).then(res => {
            console.log(res);
            location.reload();
        });
    }
    removeDirectLink() {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.graphQLService.removeLink(endpoint, this.id, this.person._id);
        }).then(res => {
            console.log(res);
            location.reload();
        });
    }
};
__decorate([
    Input()
], PersonLinkComponent.prototype, "id", void 0);
__decorate([
    Input()
], PersonLinkComponent.prototype, "person", void 0);
__decorate([
    Input()
], PersonLinkComponent.prototype, "editable", void 0);
__decorate([
    Input()
], PersonLinkComponent.prototype, "type", void 0);
PersonLinkComponent = __decorate([
    Component({
        selector: 'app-person-link',
        templateUrl: './person-link.component.html',
        styleUrls: ['./person-link.component.css']
    })
], PersonLinkComponent);
export { PersonLinkComponent };
//# sourceMappingURL=person-link.component.js.map