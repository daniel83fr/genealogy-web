import { __decorate } from "tslib";
import { Component, Input } from '@angular/core';
let PersonLinksComponent = class PersonLinksComponent {
    constructor(http, fb, rest, graphQLService, notif) {
        this.http = http;
        this.fb = fb;
        this.rest = rest;
        this.graphQLService = graphQLService;
        this.notif = notif;
        this.title = '';
        this.id = '';
        this.person = {};
        this.persons = [];
        this.editable = false;
        this.edit = false;
        this.type = '';
        this.linkId = '';
        this.firstName = '';
        this.lastName = '';
        this.personEditForm = null;
        this.personEditForm = this.fb.group({
            id: this.person._id,
            firstName: this.person.FirstName,
            lastName: this.person.LastName,
            gender: this.person.Gender,
            birthDate: this.person.YearOfBirth,
        });
    }
    ngOnInit() {
    }
    ngAfterContentInit() {
    }
    createPersonAndLink() {
        var _a, _b;
        const changes = {};
        changes.firstName = (_a = this.firstName, (_a !== null && _a !== void 0 ? _a : ''));
        changes.lastName = (_b = this.lastName, (_b !== null && _b !== void 0 ? _b : ''));
        if (changes.firstName == '' && changes.lastName == '') {
            this.notif.showError('please fill up the name.');
            return;
        }
        this.rest.getApiEndpoint()
            .then(endpoint => {
            return this.graphQLService.createPerson(endpoint, changes);
        })
            .then(res => {
            this.notif.showSuccess('Person created');
            this.linkId = res;
            this.addLink();
        });
    }
    addLink() {
        var _a, _b;
        console.log(this.linkId);
        if ((_a = this.linkId, (_a !== null && _a !== void 0 ? _a : '' == '')) || (_b = this.id, (_b !== null && _b !== void 0 ? _b : '' == ''))) {
            this.notif.showError('please fill up the link.');
            return;
        }
        switch (this.type) {
            case 'parent':
                this.linkParent();
                break;
            case 'child':
                this.linkChild();
                break;
            case 'spouse':
                this.linkSpouse();
                break;
            case 'sibling':
                this.linkSibling();
                break;
            default:
                alert(this.type + ' not supported');
        }
    }
    removeLink() {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.graphQLService.removeLink(endpoint, this.id, this.person._id);
        })
            .then(res => {
            console.log(res.data);
            this.notif.showSuccess('Link removed');
            location.reload();
        });
    }
    linkParent() {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.graphQLService.linkParent(endpoint, this.id, this.linkId);
        })
            .then(res => {
            this.notif.showSuccess('Link added');
            location.reload();
        });
    }
    linkChild() {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.graphQLService.linkChild(endpoint, this.id, this.linkId);
        })
            .then(res => {
            this.notif.showSuccess('Link added');
            location.reload();
        });
    }
    linkSpouse() {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.graphQLService.linkSpouse(endpoint, this.id, this.linkId);
        })
            .then(res => {
            this.notif.showSuccess('Link added');
            location.reload();
        });
    }
    linkSibling() {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.graphQLService.linkSibling(endpoint, this.id, this.linkId);
        })
            .then(res => {
            this.notif.showSuccess('Link added');
            location.reload();
        });
    }
    switchEdit() {
        this.edit = !this.edit;
    }
    setLink(option) {
        this.linkId = option._id;
    }
};
__decorate([
    Input()
], PersonLinksComponent.prototype, "title", void 0);
__decorate([
    Input()
], PersonLinksComponent.prototype, "id", void 0);
__decorate([
    Input()
], PersonLinksComponent.prototype, "person", void 0);
__decorate([
    Input()
], PersonLinksComponent.prototype, "persons", void 0);
__decorate([
    Input()
], PersonLinksComponent.prototype, "editable", void 0);
__decorate([
    Input()
], PersonLinksComponent.prototype, "type", void 0);
PersonLinksComponent = __decorate([
    Component({
        selector: 'app-person-links',
        templateUrl: './person-links.component.html',
        styleUrls: ['./person-links.component.css']
    })
], PersonLinksComponent);
export { PersonLinksComponent };
//# sourceMappingURL=person-links.component.js.map