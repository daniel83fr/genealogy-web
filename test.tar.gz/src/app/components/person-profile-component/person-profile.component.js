import { __decorate } from "tslib";
import { Component, Input } from '@angular/core';
let PersonProfileComponent = class PersonProfileComponent {
    constructor(configService, api, fb, notif, auth) {
        this.configService = configService;
        this.api = api;
        this.fb = fb;
        this.notif = notif;
        this.auth = auth;
        this.id = '';
        this.data = {};
        this.editable = false;
        this.personEditForm = null;
        this.editMode = false;
        this.image = '';
        this.personEditForm = this.fb.group({
            id: '',
            firstName: '',
            lastName: '',
            gender: '',
            yearOfBirth: '',
            birthDate: ''
        });
    }
    getConnectedLogin() {
        return this.auth.getConnectedLogin();
    }
    switchEdit() {
        this.notif.showInfo(`To change profile image, please go to photo gallery and choose 'Set as profile' on the selected image.`);
    }
    getImage() {
        this.configService.getApiEndpoint()
            .then(endpoint => {
            return this.api.getProfilePhoto(endpoint, this.id);
        })
            .then(data => {
            var _a;
            if (data != null) {
                this.image = data.url;
                return;
            }
            if (((_a = this.data) === null || _a === void 0 ? void 0 : _a.gender) == 'Female') {
                this.image = '../../../assets/img/profile_female.jpg';
            }
            else {
                this.image = '../../../assets/img/profile_male.jpg';
            }
        });
    }
    ngOnChanges() {
        this.getImage();
    }
    getRole(user) {
        return 'Admin';
    }
    canEditProfile() {
        const connectedUser = 'daniel';
        const role = this.getRole(connectedUser);
        if (role === 'Admin') {
            return true;
        }
        return false;
    }
    ngOnInit() {
    }
    getDisplayName(person) {
        var _a, _b, _c;
        let maidenName = (_a = person) === null || _a === void 0 ? void 0 : _a.maidenName;
        if (!!maidenName) {
            maidenName = ` (${maidenName})`;
        }
        return `${(_b = person) === null || _b === void 0 ? void 0 : _b.firstName} ${(_c = person) === null || _c === void 0 ? void 0 : _c.lastName} ${(maidenName !== null && maidenName !== void 0 ? maidenName : '')}`;
    }
    onChange(value) {
        this.editMode = value.checked;
    }
    canEdit() {
        return this.editMode && this.editable;
    }
};
__decorate([
    Input()
], PersonProfileComponent.prototype, "id", void 0);
__decorate([
    Input()
], PersonProfileComponent.prototype, "data", void 0);
__decorate([
    Input()
], PersonProfileComponent.prototype, "editable", void 0);
PersonProfileComponent = __decorate([
    Component({
        selector: 'app-person-profile',
        templateUrl: './person-profile.component.html',
        styleUrls: ['./person-profile.component.css']
    })
], PersonProfileComponent);
export { PersonProfileComponent };
//# sourceMappingURL=person-profile.component.js.map