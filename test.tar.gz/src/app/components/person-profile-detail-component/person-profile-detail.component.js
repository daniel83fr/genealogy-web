import { __decorate } from "tslib";
import { Component, Input } from '@angular/core';
let PersonProfileDetailComponent = class PersonProfileDetailComponent {
    constructor(rest, api, fb, notif, auth) {
        this.rest = rest;
        this.api = api;
        this.fb = fb;
        this.notif = notif;
        this.auth = auth;
        this.id = '';
        this.data = {};
        this.privateData = {};
        this.editable = false;
        this.personEditForm = null;
        this.editMode = false;
        this.personEditForm = this.fb.group({
            id: '',
            firstName: '',
            lastName: '',
            gender: '',
            yearOfBirth: '',
            birthDate: '',
            yearOfDeath: '',
            deathDate: '',
            isDead: '',
            currentLocation: '',
            birthLocation: '',
            deathLocation: '',
            email: '',
            phone: '',
        });
    }
    ngOnChanges(changes) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q;
        this.personEditForm = this.fb.group({
            id: (_a = this.data) === null || _a === void 0 ? void 0 : _a._id,
            firstName: (_b = this.data) === null || _b === void 0 ? void 0 : _b.firstName,
            lastName: (_c = this.data) === null || _c === void 0 ? void 0 : _c.lastName,
            gender: (_d = this.data) === null || _d === void 0 ? void 0 : _d.gender,
            yearOfBirth: (_e = this.data) === null || _e === void 0 ? void 0 : _e.yearOfBirth,
            birthDate: (_f = this.privateData) === null || _f === void 0 ? void 0 : _f.birthDate,
            yearOfDeath: (_g = this.data) === null || _g === void 0 ? void 0 : _g.yearOfDeath,
            deathDate: (_h = this.privateData) === null || _h === void 0 ? void 0 : _h.deathDate,
            isDead: (_k = (_j = this.data) === null || _j === void 0 ? void 0 : _j.isDead, (_k !== null && _k !== void 0 ? _k : false)),
            currentLocation: (_l = this.privateData) === null || _l === void 0 ? void 0 : _l.currentLocation,
            birthLocation: (_m = this.privateData) === null || _m === void 0 ? void 0 : _m.birthLocation,
            deathLocation: (_o = this.privateData) === null || _o === void 0 ? void 0 : _o.deathLocation,
            email: (_p = this.privateData) === null || _p === void 0 ? void 0 : _p.email,
            phone: (_q = this.privateData) === null || _q === void 0 ? void 0 : _q.phone,
        });
    }
    getImage() {
        var _a;
        if (((_a = this.data) === null || _a === void 0 ? void 0 : _a.gender) === 'Female') {
            return '../../../assets/img/profile_female.jpg';
        }
        return '../../../assets/img/profile_male.jpg';
    }
    getRole(user) {
        return 'Admin';
    }
    canEditProfile() {
        const connectedUser = 'daniel';
        const role = this.getRole(connectedUser);
        if (role === 'Admin') {
            return true;
        }
        return false;
    }
    ngOnInit() {
    }
    onSubmit() {
        var _a, _b, _c, _d, _e, _f, _g;
        const changes = {};
        if (this.personEditForm.get('firstName').value !== this.data.firstName && this.personEditForm.get('firstName').value) {
            changes.firstName = this.personEditForm.get('firstName').value;
        }
        if (this.personEditForm.get('lastName').value !== this.data.lastName && this.personEditForm.get('lastName').value) {
            changes.lastName = this.personEditForm.get('lastName').value;
        }
        if (this.personEditForm.get('gender').value !== this.data.gender && this.personEditForm.get('gender').value) {
            changes.gender = this.personEditForm.get('gender').value;
        }
        if (this.personEditForm.get('isDead').value !== this.data.isDead && this.personEditForm.get('isDead').value) {
            changes.isDead = this.personEditForm.get('isDead').value;
        }
        const privateChanges = {};
        if (this.personEditForm.get('birthDate').value !== ((_a = this.data.privateData) === null || _a === void 0 ? void 0 : _a.birthDate) && this.personEditForm.get('birthDate').value) {
            privateChanges.birthDate = this.personEditForm.get('birthDate').value;
        }
        if (this.personEditForm.get('deathDate').value !== ((_b = this.data.privateData) === null || _b === void 0 ? void 0 : _b.deathDate) && this.personEditForm.get('deathDate').value) {
            privateChanges.deathDate = this.personEditForm.get('deathDate').value;
        }
        if (this.personEditForm.get('currentLocation').value !== ((_c = this.data.privateData) === null || _c === void 0 ? void 0 : _c.currentLocation) && this.personEditForm.get('currentLocation').value) {
            privateChanges.currentLocation = this.personEditForm.get('currentLocation').value;
        }
        if (this.personEditForm.get('birthLocation').value !== ((_d = this.data.privateData) === null || _d === void 0 ? void 0 : _d.birthLocation) && this.personEditForm.get('birthLocation').value) {
            privateChanges.birthLocation = this.personEditForm.get('birthLocation').value;
        }
        if (this.personEditForm.get('deathLocation').value !== ((_e = this.data.privateData) === null || _e === void 0 ? void 0 : _e.deathLocation) && this.personEditForm.get('deathLocation').value) {
            privateChanges.deathLocation = this.personEditForm.get('deathLocation').value;
        }
        if (this.personEditForm.get('phone').value !== ((_f = this.data.privateData) === null || _f === void 0 ? void 0 : _f.phone) && this.personEditForm.get('phone').value) {
            privateChanges.phone = this.personEditForm.get('phone').value;
        }
        if (this.personEditForm.get('email').value !== ((_g = this.data.privateData) === null || _g === void 0 ? void 0 : _g.email) && this.personEditForm.get('email').value) {
            privateChanges.email = this.personEditForm.get('email').value;
        }
        if (Object.keys(changes).length === 0 && changes.constructor === Object &&
            Object.keys(privateChanges).length === 0 && privateChanges.constructor === Object) {
        }
        else {
            this.rest.getApiEndpoint().then((endpoint) => {
                this.updateProfile(this.id, changes, privateChanges);
            });
        }
    }
    switchEdit() {
        this.editMode = !this.editMode;
    }
    deleteProfile() {
        const r = confirm(`Delete ${this.data._id}?`);
        if (r === true) {
            // OK
            this.rest.getApiEndpoint()
                .then((endpoint) => {
                return this.api.deleteProfile(endpoint.toString(), this.id);
            })
                .then(res => {
                console.log(res.data);
                this.notif.showSuccess(res.data.removeProfile);
                window.location.href = '/';
            });
        }
    }
    getDisplayName(person) {
        var _a, _b, _c;
        let maidenName = (_a = person) === null || _a === void 0 ? void 0 : _a.maidenName;
        if (!!maidenName) {
            maidenName = ` (${maidenName})`;
        }
        return `${(_b = person) === null || _b === void 0 ? void 0 : _b.firstName} ${(_c = person) === null || _c === void 0 ? void 0 : _c.lastName} ${(maidenName !== null && maidenName !== void 0 ? maidenName : '')}`;
    }
    onChange(value) {
        this.editMode = value.checked;
    }
    canEdit() {
        return this.editMode && this.editable;
    }
    updateProfile(id, changes, privateChanges) {
        this.rest.getApiEndpoint()
            .then((endpoint) => {
            return this.api.updateProfile(endpoint, id, changes, privateChanges, this.auth.getConnectedProfile());
        })
            .then(res => {
            this.notif.showSuccess('Profile updated.');
            location.reload();
        })
            .catch(err => {
            alert(err);
        });
    }
};
__decorate([
    Input()
], PersonProfileDetailComponent.prototype, "id", void 0);
__decorate([
    Input()
], PersonProfileDetailComponent.prototype, "data", void 0);
__decorate([
    Input()
], PersonProfileDetailComponent.prototype, "privateData", void 0);
__decorate([
    Input()
], PersonProfileDetailComponent.prototype, "editable", void 0);
PersonProfileDetailComponent = __decorate([
    Component({
        selector: 'app-person-profile-detail',
        templateUrl: './person-profile-detail.component.html',
        styleUrls: ['./person-profile-detail.component.css']
    })
], PersonProfileDetailComponent);
export { PersonProfileDetailComponent };
//# sourceMappingURL=person-profile-detail.component.js.map