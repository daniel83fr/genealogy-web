import { __decorate } from "tslib";
import { Component, Output, EventEmitter } from '@angular/core';
import { FormControl } from '@angular/forms';
import { map, startWith } from 'rxjs/operators';
let PersonSearchComponent = class PersonSearchComponent {
    constructor(http, fb, configurationService, graphQLService, router, cacheService) {
        this.http = http;
        this.fb = fb;
        this.configurationService = configurationService;
        this.graphQLService = graphQLService;
        this.router = router;
        this.cacheService = cacheService;
        this.personChanged = new EventEmitter();
        this.myControl = new FormControl();
        this.options = [];
    }
    optionSelected(id) {
        this.personChanged.emit(id);
    }
    displayFn(user) {
        return user && user.firstName + ' ' + user.lastName;
    }
    getPersonList() {
        let cachedItems = this.cacheService.getPersonListFromCache();
        this.options = cachedItems.data;
        this.configurationService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQLService.getPersonList(endpoint, cachedItems.data.length, cachedItems.timestamp);
        })
            .then(res => {
            console.log(JSON.stringify(res));
            if (!res.isUpToDate) {
                this.options = res.users;
            }
        });
    }
    ngOnInit() {
        this.getPersonList();
        this.filteredOptions = this.myControl.valueChanges
            .pipe(startWith(''), map(value => typeof value === 'string' ? value : value.firstName), map(name => name ? this._filter(name) : this.options.slice()));
    }
    _filter(name) {
        const filterValue = name.toLowerCase();
        return this.options.filter(option => (option.firstName + ' ' + option.lastName).toLowerCase()
            .includes(filterValue));
    }
    ngAfterContentInit() {
    }
};
__decorate([
    Output()
], PersonSearchComponent.prototype, "personChanged", void 0);
PersonSearchComponent = __decorate([
    Component({
        selector: 'app-person-search',
        templateUrl: './person-search.component.html',
        styleUrls: ['./person-search.component.css']
    })
], PersonSearchComponent);
export { PersonSearchComponent };
//# sourceMappingURL=person-search.component.js.map