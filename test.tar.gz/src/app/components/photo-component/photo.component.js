import { __decorate } from "tslib";
import { Component, Input } from '@angular/core';
let PhotoComponent = class PhotoComponent {
    constructor(configService, graphQlService, notification) {
        this.configService = configService;
        this.graphQlService = graphQlService;
        this.notification = notification;
        this.id = undefined;
        this.editable = false;
        this.editMode = false;
        this.photoIndex = 0;
        this.persons = [];
        this.edit = false;
    }
    switchEdit() {
        this.editMode = !this.editMode;
    }
    setLink(option) {
        this.linkId = option._id;
    }
    changeListener($event) {
        this.readThis($event.target);
    }
    readThis(inputValue) {
        const file = inputValue.files[0];
        this.image2 = file;
        const myReader = new FileReader();
        myReader.onloadend = (e) => {
            this.image = myReader.result;
        };
        myReader.readAsDataURL(file);
    }
    upload() {
        const myHeaders = new Headers();
        myHeaders.append('Authorization', 'Client-ID 7e2fbe3383eb5ed');
        const formdata = new FormData();
        formdata.append('image', this.image2);
        formdata.append('type', 'file');
        formdata.append('name', this.image2.name);
        const requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: formdata,
            redirect: 'follow'
        };
        fetch('https://api.imgur.com/3/image', requestOptions)
            .then(response => response.json())
            .then(result => {
            const link = result.data.link;
            const deletehash = result.data.deletehash;
            return this.configService.getApiEndpoint()
                .then(endpoint => {
                return this.graphQlService.addPhoto(endpoint, link, deletehash, [this.id]);
            });
        })
            .then(res => {
            this.notification.showSuccess('Photo added');
            window.location.reload();
        })
            .catch(error => {
            console.log(Error(error));
            this.notification.showError('Something went wrong. please check logs for details.');
        });
    }
    setProfilePicture() {
        const picture = this.photos[this.photoIndex]._id;
        const user = this.id;
        this.configService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQlService.setProfilePicture(endpoint, user, picture);
        })
            .catch(err => {
            this.notification.showError('Something went wrong. please check logs for detail.');
            console.log(err);
            throw Error(err);
        })
            .then(res => {
            this.notification.showSuccess('Profile picture changed.');
            window.location.reload();
        });
    }
    removeTag(tag, photo) {
        this.configService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQlService.removePhotoTag(endpoint, tag, photo);
        })
            .catch(err => {
            this.notification.showError('Something went wrong. please check logs for detail.');
            console.log(err);
            throw Error(err);
        })
            .then(res => {
            this.notification.showSuccess('Tag removed');
            window.location.reload();
        });
    }
    addTag(tag, photo) {
        if (tag.length < 12) {
            this.notification.showError('Id should be valid');
            return;
        }
        this.configService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQlService.addPhotoTag(endpoint, tag, photo);
        })
            .catch(err => {
            this.notification.showError('Something went wrong. please check logs for detail.');
            console.log(err);
            throw Error(err);
        })
            .then(res => {
            this.notification.showSuccess('Tag added');
            this.linkId = '';
            window.location.reload();
        });
    }
    next() {
        if (this.photoIndex < this.photos.length - 1) {
            this.photoIndex++;
        }
    }
    previous() {
        if (this.photoIndex > 0) {
            this.photoIndex--;
        }
    }
    ngOnInit() {
    }
    ngOnChanges() {
        this.getProfileImage(this.id);
        this.getPhotos(this.id);
    }
    deletePicture() {
        const picture = this.photos[this.photoIndex]._id;
        this.configService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQlService.deletePhoto(endpoint, picture);
        })
            .catch(err => {
            this.notification.showError('Something went wrong. please check logs for detail.');
            console.log(err);
            throw Error(err);
        })
            .then(res => {
            this.notification.showSuccess('Photo deleted.');
            window.location.reload();
        });
    }
    getProfileImage(id) {
        this.configService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQlService.getProfilePhoto(endpoint, id);
        })
            .then(data => {
            var _a;
            this.profile = (_a = data) === null || _a === void 0 ? void 0 : _a._id;
        });
    }
    getPhotos(id) {
        this.configService.getApiEndpoint()
            .then(endpoint => {
            return this.graphQlService.getProfile(endpoint, id);
        })
            .then(data => {
            this.photos = data.photos;
        });
    }
};
__decorate([
    Input()
], PhotoComponent.prototype, "id", void 0);
__decorate([
    Input()
], PhotoComponent.prototype, "editable", void 0);
__decorate([
    Input()
], PhotoComponent.prototype, "photos", void 0);
PhotoComponent = __decorate([
    Component({
        selector: 'app-photo',
        templateUrl: './photo.component.html',
        styleUrls: ['./photo.component.css']
    })
], PhotoComponent);
export { PhotoComponent };
//# sourceMappingURL=photo.component.js.map