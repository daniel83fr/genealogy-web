import { __decorate } from "tslib";
import { Component } from '@angular/core';
let LoginComponent = class LoginComponent {
    constructor(fb, authService, notif) {
        this.fb = fb;
        this.authService = authService;
        this.notif = notif;
        this.loginForm = null;
        this.loginForm = this.fb.group({
            'login': '',
            'password': ''
        });
    }
    onSubmit() {
        let login = this.loginForm.controls.login.value;
        let password = this.loginForm.controls.password.value;
        if (login && password) {
            this.authService.login(login, password)
                .then(res => {
                console.log("User is logged in");
                localStorage.setItem("token", res.toString());
                localStorage.setItem("login", login);
                window.location.href = "/";
            }).catch(err => {
                this.notif.showError("Login failed");
            });
        }
    }
    ngOnInit() {
    }
    ngAfterContentInit() {
    }
};
LoginComponent = __decorate([
    Component({
        selector: 'app-login',
        templateUrl: './login.component.html',
        styleUrls: ['./login.component.css']
    })
], LoginComponent);
export { LoginComponent };
//# sourceMappingURL=login.component.js.map