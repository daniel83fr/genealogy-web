import { __decorate } from "tslib";
import { Component } from '@angular/core';
let BottomSheetOverviewExampleSheet = class BottomSheetOverviewExampleSheet {
    constructor(_bottomSheetRef) {
        this._bottomSheetRef = _bottomSheetRef;
    }
    openLink(event) {
        this._bottomSheetRef.dismiss();
        event.preventDefault();
    }
};
BottomSheetOverviewExampleSheet = __decorate([
    Component({
        selector: 'bottom-sheet-overview-example-sheet',
        templateUrl: 'bottom-sheet-overview-example-sheet.html',
    })
], BottomSheetOverviewExampleSheet);
export { BottomSheetOverviewExampleSheet };
//# sourceMappingURL=share.component.js.map