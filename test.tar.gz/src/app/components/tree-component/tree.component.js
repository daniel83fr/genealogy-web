import { __decorate } from "tslib";
import { Component, Input } from '@angular/core';
import * as d3 from 'd3';
import { TreeDraw } from '../../treeDraw';
let TreeComponent = class TreeComponent {
    constructor() {
        this.data = {};
    }
    ngOnInit() {
    }
    ngAfterContentInit() {
        let svg = d3.select('.familyTree');
        new TreeDraw().draw(svg, this.data);
    }
    openShareSheet() {
    }
};
__decorate([
    Input('data')
], TreeComponent.prototype, "data", void 0);
TreeComponent = __decorate([
    Component({
        selector: 'app-tree',
        templateUrl: './tree.component.html',
        styleUrls: ['./tree.component.css']
    })
], TreeComponent);
export { TreeComponent };
//# sourceMappingURL=tree.component.js.map