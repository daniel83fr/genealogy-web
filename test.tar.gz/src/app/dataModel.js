export class DataModel {
    constructor() {
        this.currentPerson = {};
        this.father = {};
        this.mother = {};
        this.children = [];
        this.siblings = [];
        this.spouses = [];
        this.members = [];
        this.links = [];
    }
}
//# sourceMappingURL=dataModel.js.map