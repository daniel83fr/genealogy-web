export class TreeItem {
    constructor(x, y, data, type) {
        this.x = x;
        this.y = y;
        this.data = data;
        this.type = type;
    }
}
//# sourceMappingURL=treeItem.js.map