class LoggerClass {
    Debug(msg) {
        console.log(msg);
    }
}
const Logger = new LoggerClass();
export default Logger;
//# sourceMappingURL=logger.js.map